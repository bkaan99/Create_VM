"""MTree (BAAS) Report Discoverer"""
from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[2]))
import logging
import os
import datetime
import pandas as pd
from scp import SCPClient
from sqlalchemy import text
from sqlalchemy.orm import sessionmaker
from Discovery.CsvDiscover.ExcellDiscovererClass import SSHConnection, CommandProcess
from Discovery.utils.LogProcess import LogProcess
from Discovery.utils.GetCredential import GetCredential
from Discovery.utils.PostgresConnection import PostgresConnection

def baas_report_requirement_loader():
    """ BaaS raporları için gereksinimleri yükler """
    logging.info("------BaaS Report Dicovery işlemleri başlatılıyor.------")
    baas_report_remote_path = "/mnt/scheduled"
    baas_report_folder = "/home/gardiyan/Gardiyan/Server/pfms/apache-karaf-5005/GH-Plugins/Discovery/CsvDiscover/Reports/BaaS-Reports"
    os.makedirs(baas_report_folder, exist_ok=True)
    #read_backup_mapping_and_set_db()
    get_baas_files_from_remote(ssh_client, baas_report_remote_path, baas_report_folder)
    logging.info("BaaS Report işlemi tamamlandı.")
    logging.info(f"\n -------------------------------")

def get_baas_files_from_remote(ssh_client, remote_path, baas_report_folder):
    """Retrieve specific BaaS .csv file (EQX_Mtree.csv) from remote server and load it into a DataFrame."""
    files = CommandProcess.list_remote_files(ssh_client, remote_path)
    csv_files = [file for file in files if file == 'EQX_Mtree.csv']

    if not csv_files:
        logging.info("No EQX_Mtree.csv file found in the remote path.")
        return

    backup_customer_mapping_table = "kr_backup_customer_mapping"

    with SCPClient(ssh_client.get_transport()) as scp:
        for file in csv_files:
            local_path = os.path.join(baas_report_folder, file)
            try:
                scp.get(os.path.join(remote_path, file), local_path)
                logging.info(f"File {file} successfully retrieved to {local_path}")

                csv_data = pd.read_csv(local_path)
                logging.info(f"{file} loaded into DataFrame successfully.")

                #rename csv_data columns Hostname to hostname, Name to name, Pre Compression Size (PB) to precompressionsizepb, Post Global Compression Size (TB) to postglobalcompressionsizetb, Post Local Compression Size (TB) to postlocalcompressionsizetb, Measurement Time to measurementtime
                csv_data.rename(columns={'Hostname': 'hostname',
                                         'Name': 'name',
                                         'Pre Compression Size (PB)': 'precompressionsizepb',
                                         'Post Global Compression Size (TB)': 'postglobalcompressionsizetb',
                                         'Post Local Compression Size (TB)': 'postlocalcompressionsizetb',
                                         'Measurement Time': 'measurementtime'}, inplace=True)

                #backup_mapping tablosundan backupname ve customer_id alanlarını çek
                kr_backup_customer_mapping = pd.read_sql(f"SELECT backupname, customer_id "
                                                         f"FROM {backup_customer_mapping_table} "
                                                         f"WHERE is_deleted = False", engineForPostgres)

                csv_data = csv_data.merge(kr_backup_customer_mapping, left_on='name', right_on='backupname', how='left', suffixes=('', '_kr_backup_customer_mapping'))
                csv_data['customer_id'] = csv_data['customer_id'].apply(lambda x: None if pd.isnull(x) else x)

                now_time = datetime.datetime.now()
                csv_data['createdate'] = now_time
                csv_data['is_deleted'] = False
                csv_data['version'] = 1
                csv_data['updatedate'] = now_time
                csv_data.drop('backupname', axis=1, inplace=True)

                #check if the baas data is already in the database
                baas_table_name = "kr_mtree_backup"
                baas_check = pd.read_sql(f"SELECT * FROM {baas_table_name}", engineForPostgres)

                # baas_check tablosunda olmayan verileri ekle
                to_update = csv_data[csv_data['name'].isin(baas_check['name'])]
                to_insert = csv_data[~csv_data['name'].isin(to_update['name'])]
                to_soft_delete = baas_check[~baas_check['name'].isin(csv_data['name'])]

                Session = sessionmaker(bind=engineForPostgres)
                session = Session()

                if not to_update.empty:
                    try:
                        for index, row in to_update.iterrows():
                            sql = text(f"UPDATE {baas_table_name} "
                                       f"SET hostname = :hostname, "
                                       f"precompressionsizepb = :precompressionsizepb, "
                                       f"postglobalcompressionsizetb = :postglobalcompressionsizetb, "
                                       f"postlocalcompressionsizetb = :postlocalcompressionsizetb, "
                                       f"measurementtime = :measurementtime, "
                                       f"createdate = :createdate, "
                                       f"is_deleted = :is_deleted, "
                                       f"version = :version, "
                                       f"updatedate = :updatedate, "
                                       f"customer_id = :customer_id "
                                       f"WHERE name = :name")

                            session.execute(sql, {
                                'hostname': row['hostname'],
                                'precompressionsizepb': row['precompressionsizepb'],
                                'postglobalcompressionsizetb': row['postglobalcompressionsizetb'],
                                'postlocalcompressionsizetb': row['postlocalcompressionsizetb'],
                                'measurementtime': row['measurementtime'],
                                'createdate': row['createdate'],
                                'is_deleted': row['is_deleted'],
                                'version': row['version'],
                                'updatedate': row['updatedate'],
                                'name': row['name'],
                                'customer_id': row['customer_id']
                            })
                        session.commit()
                        logging.info("BaaS veritabanı güncellendi.")
                    except Exception as e:
                        logging.error(f"BaaS veritabanı güncellenirken hata oluştu: {e}")
                        session.rollback()

                if not to_insert.empty:
                    try:
                        to_insert.to_sql(baas_table_name, engineForPostgres, chunksize=5000, index=False, if_exists='append')
                        logging.info("BaaS veritabanına yazıldı.")
                    except Exception as e:
                        print(e)
                        logging.error(f"BaaS veritabanına yazılırken hata oluştu: {e}")

                if not to_soft_delete.empty:
                    try:
                        for index, row in to_soft_delete.iterrows():
                            session.execute(f"UPDATE {baas_table_name} "
                                            f"SET is_deleted = True "
                                            f"WHERE name = '{row['name']}'")
                        session.commit()
                        logging.info("BaaS veritabanı güncellendi.")
                    except Exception as e:
                        logging.error(f"BaaS veritabanı güncellenirken hata oluştu: {e}")
                        session.rollback()

                session.close()

            except Exception as e:
                logging.error(f"Failed to process {file}: {e}")

if __name__ == "__main__":
    print(f"{os.path.basename(__file__)} running...")
    try:
        LogProcess.create_logger_settings(log_prefix=os.path.basename(__file__).split(".")[0], script_dir=os.path.dirname(os.path.realpath(__file__)))
        filtered_credentials = GetCredential('CSV(SSH)').filtered_data_to_dataframe()
        row = filtered_credentials.iloc[0]
        engineForPostgres = PostgresConnection().get_db_instance()
        ssh_client = SSHConnection(row['endpoint'], row['port'], row['username'], row['password']).create_ssh_client()
        baas_report_requirement_loader()
        ssh_client.close()
        logging.info("SSH bağlantısı kapatıldı.")
        PostgresConnection().close_db_instance()
        logging.info("İşlem Tamamlandı.")
    except Exception as e:
        logging.error(f"İşlem sırasında hata oluştu: {e}")
        print(f"RUNNING_ERROR İşlem sırasında hata oluştu")