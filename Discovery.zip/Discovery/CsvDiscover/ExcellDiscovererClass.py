""" Daily Backup Reports and Replication Reports getter Script """
from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[2]))
import logging
import paramiko
import socket

class SSHConnection:
    def __init__(self, hostname, port, username, password):
        """Dinamik olarak SSH bağlantısı için yapılandırma sağlar"""
        self.hostname = hostname
        self.port = port
        self.username = username
        self.password = password

    def create_ssh_client(self):
        """SSH bağlantısı oluşturur"""
        try:
            client = paramiko.SSHClient()
            client.load_system_host_keys()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

            client.connect(self.hostname, port=self.port, username=self.username, password=self.password, timeout=10)

            logging.info(f"SSH bağlantısı oluşturuldu: {self.hostname}")
            logging.info("\n -------------------------------")
            return client
        except paramiko.ssh_exception.AuthenticationException:
            logging.error("Kimlik doğrulama hatası! Lütfen kullanıcı adı veya şifreyi kontrol edin.")
        except paramiko.ssh_exception.NoValidConnectionsError:
            logging.error(f"{self.hostname}:{self.port} için bağlantı kurulamadı. Sunucuya erişilemiyor.")
        except socket.timeout:
            logging.error(f"Bağlantı zaman aşımına uğradı! Sunucuya {self.hostname} erişilemiyor.")
        except Exception as e:
            logging.error(f"Beklenmeyen bir hata oluştu: {e}")
        return None

class CommandProcess:
    @staticmethod
    def list_remote_files(ssh_client, remote_path):
        """Uzak sunucudaki dosyaları listeler"""
        stdin, stdout, stderr = ssh_client.exec_command(f'ls {remote_path}')
        files = stdout.read().decode().splitlines()
        return files

    @staticmethod
    def cat_remote_file(ssh_client, remote_path, file):
        """Uzak sunucudaki dosyayı okur"""
        stdin, stdout, stderr = ssh_client.exec_command(f"cat {remote_path}/{file}")
        file_data = stdout.read()
        error_output = stderr.read().decode('utf-8')
        return file_data, error_output