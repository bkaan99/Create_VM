""" Daily Backup Reports"""
from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[2]))
import logging
import os
import re
import datetime
import pandas as pd
import io
from scp import SCPClient
from Discovery.CsvDiscover.ExcellDiscovererClass import SSHConnection, CommandProcess
from Discovery.utils.LogProcess import LogProcess
from Discovery.utils.GetCredential import GetCredential
from Discovery.utils.PostgresConnection import PostgresConnection

def daily_backup_report_requirement_loader():
    """ Günlük yedekleme raporları için gereksinimleri yükler """
    logging.info("------Daily Backup Report Dicovery işlemleri başlatılıyor.------")
    backup_report_remote_path = "/tmp/backup_reports"
    vcenter_report_folder = "/home/gardiyan/Gardiyan/Server/pfms/apache-karaf-5005/GH-Plugins/Discovery/CsvDiscover/Reports/AvailabilityReport/VCenter"
    proxmox_report_folder = "/home/gardiyan/Gardiyan/Server/pfms/apache-karaf-5005/GH-Plugins/Discovery/CsvDiscover/Reports/AvailabilityReport/Proxmox"
    os.makedirs(proxmox_report_folder, exist_ok=True)
    os.makedirs(vcenter_report_folder, exist_ok=True)
    get_daily_backup_csv_files_from_remote(ssh_client, backup_report_remote_path, proxmox_report_folder, vcenter_report_folder)
    logging.info("Daily Backup Report işlemi tamamlandı.")
    logging.info(f"\n -------------------------------")

def get_daily_backup_csv_files_from_remote(ssh_client, remote_path, proxmox_report_folder, vcenter_report_folder):
    """Uzak sunucudaki .csv dosyalarını doğru klasöre indirir"""
    logging.info(f"Uzak sunucudaki dosyaları kontrol ediliyor: {remote_path}")
    files = CommandProcess.list_remote_files(ssh_client, remote_path)

    # sonu .csv ile biten dosyaları al
    csv_files = [file for file in files if file.endswith('.csv')]

    if not csv_files:
        logging.info(".csv dosyası bulunamadı.")
        return

    report_description = "Daily Backup Report"
    report_table_name = "kr_report"

    with SCPClient(ssh_client.get_transport()) as scp:
        for file in csv_files:
            #Dosya isim kontrolü
            if file.startswith('proxmox'):
                local_path = os.path.join(proxmox_report_folder, file)
                report_type = 'Proxmox'
            elif file.startswith('vmware'):
                local_path = os.path.join(vcenter_report_folder, file)
                report_type = 'VMware'
            else:
                continue

            # Dosya varlığı kontrolü
            if os.path.exists(local_path):
                continue

            logging.info(f"{file} için işlemler yapılıyor.")

            # Dosya tarihi alma
            file_date = re.search(r'_(\d{2}-\d{2}-\d{4})\.csv', file)

            if file_date:
                file_date = file_date.group(1)
                file_date = datetime.datetime.strptime(file_date, "%d-%m-%Y").strftime("%Y-%m-%d")
                logging.info(f"{file} için tarih: {file_date}")
            else:
                logging.info(f"{file} için tarih çıkarılamadı.")
                continue


            kr_reports_check = pd.read_sql(f"SELECT * FROM {report_table_name} "
                                           f"WHERE logdate = '{file_date}' "
                                           f"AND reporttype = '{report_type}' "
                                           f"AND description = '{report_description}'", engineForPostgres)

            if not kr_reports_check.empty:
                logging.info(f"{file} zaten veritabanında var, atlanıyor.")
                continue

            try:
                file_data, error_output = CommandProcess.cat_remote_file(ssh_client, remote_path, file)

                if error_output:
                    logging.error(f"Uzaktan {file} okunurken hata oluştu: {error_output}")
                    continue

                csv_data = pd.read_csv(io.StringIO(file_data.decode('utf-8')))

                csv_data.rename(columns={
                    'VM Name': 'vmname',
                    'VM ID': 'vmidgh',
                    'Volume': 'volume',
                    'DataStore Name': 'datastorename',
                    'FE Disk Size (Byte)': 'disksize',
                    'Retention Time': 'retentiontime',
                    'Start Time': 'starttime',
                    'End Time': 'endtime',
                    'Current State': 'currentstate',
                    'Status': 'status',
                    'Backup Level': 'backuplevel'
                }, inplace=True)

                now_time = datetime.datetime.now()
                csv_data['createdate'] = now_time
                csv_data['createatdate'] = now_time
                csv_data['is_deleted'] = False
                csv_data['description'] = report_description
                csv_data['logdate'] = file_date
                csv_data['version'] = 1
                csv_data['reporttype'] = report_type

                table_name_vm_list = "kr_vm_list"
                kr_vm_list_df = pd.read_sql(f"SELECT id, vmname FROM {table_name_vm_list}", engineForPostgres)
                csv_data = csv_data.merge(kr_vm_list_df, on='vmname', how='left', suffixes=('', '_kr_vm'))
                csv_data.rename(columns={'id': 'vmlist_id'}, inplace=True)

                try:
                    csv_data.to_sql(report_table_name, engineForPostgres, chunksize=5000, index=False, if_exists='append')
                    logging.info(f"{file} başarıyla veritabanına yazıldı.")
                    try:
                        scp.get(f"{remote_path}/{file}", local_path)
                        logging.info(f'{file} indirildi.')
                    except Exception as e:
                        logging.error(f"{file} indirilirken hata oluştu: {e}")

                except Exception as e:
                    logging.error(f"Veritabanına {file} yazılırken hata oluştu: {e}")

            except Exception as e:
                logging.error(f"{file} okunurken veya işlenirken hata oluştu: {e}")

if __name__ == "__main__":
    print(f"{os.path.basename(__file__)} running...")
    try:
        LogProcess.create_logger_settings(log_prefix=os.path.basename(__file__).split(".")[0], script_dir=os.path.dirname(os.path.realpath(__file__)))
        filtered_credentials = GetCredential('CSV(SSH)').filtered_data_to_dataframe()
        row = filtered_credentials.iloc[0]
        engineForPostgres = PostgresConnection().get_db_instance()
        ssh_client = SSHConnection(row['endpoint'], row['port'], row['username'], row['password']).create_ssh_client()
        daily_backup_report_requirement_loader()
        ssh_client.close()
        logging.info("SSH bağlantısı kapatıldı.")
        PostgresConnection().close_db_instance()
        logging.info("İşlem Tamamlandı.")
    except Exception as e:
        logging.error(f"İşlem sırasında hata oluştu: {e}")
        print(f"RUNNING_ERROR İşlem sırasında hata oluştu")