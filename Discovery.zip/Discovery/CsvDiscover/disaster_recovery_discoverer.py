"""Hourly Disaster Recovery Report Discoverer"""
from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[2]))
import logging
import os
import re
import datetime
import pandas as pd
import io
from scp import SCPClient
from Discovery.CsvDiscover.ExcellDiscovererClass import SSHConnection, CommandProcess
from Discovery.utils.LogProcess import LogProcess
from Discovery.utils.GetCredential import GetCredential
from Discovery.utils.PostgresConnection import PostgresConnection


def hourly_dr_report_requirement_loader():
    """ Saatlik felaket kurtarma raporları için gereksinimleri yükler """
    logging.info("------Hourly Disaster Recovery Report Dicovery işlemleri başlatılıyor.------")
    replication_report_remote_path = "/tmp/replication_reports"
    replication_report_folder = "/home/gardiyan/Gardiyan/Server/pfms/apache-karaf-5005/GH-Plugins/Discovery/CsvDiscover/Reports/Replication-Reports"
    os.makedirs(replication_report_folder, exist_ok=True)
    get_replication_files_from_remote(ssh_client, replication_report_remote_path, replication_report_folder)
    logging.info("Hourly Disaster Recovery Report işlemi tamamlandı.")
    logging.info(f"\n -------------------------------")


def get_replication_files_from_remote(ssh_client, remote_path, replication_report_folder):
    """Retrieve replication .csv files from remote server and log separately"""
    files = CommandProcess.list_remote_files(ssh_client, remote_path)
    csv_files = [file for file in files if file.endswith('.csv')]

    report_description = "Hourly Disaster Recovery Report"
    report_table_name = "kr_report"

    with SCPClient(ssh_client.get_transport()) as scp:
        for file in csv_files:
            local_path = os.path.join(replication_report_folder, file)
            if os.path.exists(local_path):
                continue

            try:
                file_data, error_output = CommandProcess.cat_remote_file(ssh_client, remote_path, file)

                # Check if there was any error during file read
                if error_output:
                    logging.error(f"Error reading {file} from remote: {error_output}")
                    continue

                # Print the raw content of the file before converting to a DataFrame
                parsed_file_name_date = re.search(r'\d{4}-\d{2}-\d{2}-\d{2}:\d{2}:\d{2}', file)

                if parsed_file_name_date:
                    file_date_str = parsed_file_name_date.group(0)
                    file_date = datetime.datetime.strptime(file_date_str, "%Y-%m-%d-%H:%M:%S").strftime("%Y-%m-%d %H:%M:%S")
                else:
                    continue

                logging.info(f"{file} için işlemler yapılıyor.")

                kr_reports_check = pd.read_sql(f"SELECT * FROM {report_table_name} "
                                               f"WHERE logdate = '{file_date}' "
                                               f"AND description = '{report_description}'", engineForPostgres)

                if not kr_reports_check.empty:
                    logging.info(f"{file} zaten veritabanında var, atlanıyor.")
                    scp.get(f"{remote_path}/{file}", local_path)
                    logging.info(f'{file} indirildi.')
                    continue

                # Convert file data to a DataFrame
                csv_data = pd.read_csv(io.StringIO(file_data.decode('utf-8')))
                csv_data.rename(columns={
                    'LOCALRESNAME': 'localresname',
                    'STARTTIME': 'starttime',
                    'ENDTIME': 'endtime',
                    'SYNCLEFTTIME': 'synclefttime'
                }, inplace=True)
                csv_data.drop('REPLICATIONPROGRESS', axis=1, inplace=True)

                now_time = datetime.datetime.now()
                csv_data['createdate'] = now_time
                csv_data['createatdate'] = now_time
                csv_data['is_deleted'] = False
                csv_data['description'] = report_description
                csv_data['logdate'] = file_date
                csv_data['version'] = 1

                try:
                    csv_data.to_sql(report_table_name, engineForPostgres, chunksize=5000, index=False, if_exists='append')
                    logging.info(f"{file} başarıyla veritabanına yazıldı.")
                    scp.get(f"{remote_path}/{file}", local_path)
                    logging.info(f'{file} indirildi.')

                except Exception as e:
                    logging.error(f"Error writing {file} to the database: {e}")

            except Exception as e:
                logging.error(f"{file} okunurken veya işlenirken hata oluştu: {e}")

if __name__ == "__main__":
    print(f"{os.path.basename(__file__)} running...")
    try:
        LogProcess.create_logger_settings(log_prefix=os.path.basename(__file__).split(".")[0], script_dir=os.path.dirname(os.path.realpath(__file__)))
        filtered_credentials = GetCredential('CSV(SSH)').filtered_data_to_dataframe()
        row = filtered_credentials.iloc[0]
        engineForPostgres = PostgresConnection().get_db_instance()
        ssh_client = SSHConnection(row['endpoint'], row['port'], row['username'], row['password']).create_ssh_client()
        hourly_dr_report_requirement_loader()
        ssh_client.close()
        logging.info("SSH bağlantısı kapatıldı.")
        PostgresConnection().close_db_instance()
        logging.info("İşlem Tamamlandı.")
    except Exception as e:
        logging.error(f"İşlem sırasında hata oluştu: {e}")
        print(f"RUNNING_ERROR İşlem sırasında hata oluştu")