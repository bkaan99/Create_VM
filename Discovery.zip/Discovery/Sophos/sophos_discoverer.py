from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[2]))
import requests
from sqlalchemy import text
from sqlalchemy.orm import sessionmaker
import pandas as pd
from itertools import islice
import os
from Discovery.utils.GetCredential import GetCredential
from Discovery.utils.PostgresConnection import PostgresConnection
from Discovery.utils.LogProcess import LogProcess

print(f"{os.path.basename(__file__)} running...")

def get_access_token(client_id, client_secret):
    url = 'https://id.sophos.com/api/v2/oauth2/token'
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    data = {
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
        'scope': 'token'
    }

    response = requests.post(url, headers=headers, data=data)
    if response.status_code == 200:
        token_data = response.json()
        return token_data.get('access_token'), token_data.get('expires_in')
    else:
        print(f"Token Hatası {response.status_code}: {response.text}")
        return None, None

def get_tenant_and_proxy(access_token):
    url = "https://api.central.sophos.com/whoami/v1"
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }

    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        whoami_data = response.json()
        tenant_id = whoami_data.get('id')
        api_host = whoami_data.get('apiHosts', {}).get('dataRegion')
        return tenant_id, api_host
    else:
        print(f"Proxy/Tenant ID Hatası {response.status_code}: {response.text}")
        return None, None

def chunked_iterable(iterable, size):
    """Bir iterable'ı belirtilen boyutlarda parçalara böler."""
    it = iter(iterable)
    while True:
        chunk = list(islice(it, size))
        if not chunk:
            break
        yield chunk

def list_all_endpoints(access_token, tenant_id, proxy_url):
    all_endpoints = []
    next_key = None

    # VM IP adresleri
    vm_ip_is_true_regex, vm_ip_and_uuid_df = get_vm_ipaddresses_in_vmlist()
    ip_addresses = list(vm_ip_is_true_regex['ipaddress'])

    # IP adreslerini gruplara böl (örneğin, her grup 100 IP adresi içerir)
    chunk_size = 100
    ip_chunks = chunked_iterable(ip_addresses, chunk_size)

    # Sophos'tan dönen IP adreslerini tutacak bir set
    sophos_ip_addresses = set()

    for chunk in ip_chunks:
        while True:
            # İlk istek veya sonrakiler için nextKey parametresini ekleyin
            url = f"{proxy_url}/endpoint/v1/endpoints"
            headers = {
                'Authorization': f'Bearer {access_token}',
                'X-Tenant-ID': tenant_id,
                'Content-Type': 'application/json'
            }

            params = {
                'ipAddresses': chunk  # Sadece bu grubu gönderiyoruz
            }
            if next_key:
                params['nextKey'] = next_key  # Eğer bir sonraki sayfa varsa, nextKey parametresini kullan

            response = requests.get(url, headers=headers, params=params)

            if response.status_code == 200:
                data = response.json()
                # Endpoint verilerini all_endpoints listesine ekle
                for line in data['items']:
                    all_endpoints.append(line)

                    # Sophos'tan dönen IP adreslerini kaydet
                    if 'ipv4Addresses' in line and isinstance(line['ipv4Addresses'], list):
                        sophos_ip_addresses.update(line['ipv4Addresses'])

                # Eğer bir nextKey varsa, bir sonraki sayfayı al
                next_key = data.get('pages', {}).get('nextKey')

                # Eğer nextKey yoksa, tüm sayfalar alındı demektir
                if not next_key:
                    break
            else:
                print(f"Endpoint Hatası {response.status_code}: {response.text}")
                break

    # IP adreslerinin Sophos'ta bulunup bulunmadığının kontrolü
    vm_ip_is_true_regex.loc[:, 'antivirus'] = vm_ip_is_true_regex['ipaddress'].apply(
        lambda ip: 1 if ip in sophos_ip_addresses else 0
    )
    return vm_ip_is_true_regex, vm_ip_and_uuid_df

def get_vm_ipaddresses_in_vmlist():
    vm_list_table_name = "kr_vm_list"
    query = (f"SELECT ipaddress, uuid "
             f"FROM {vm_list_table_name} "
             f"WHERE is_deleted = False "
             f"AND ipaddress IS NOT NULL")
    vm_ip_and_uuid_df = pd.read_sql(query, db_instance)
    vm_ip_is_true_regex = vm_ip_and_uuid_df[vm_ip_and_uuid_df['ipaddress'].str.match(r'^([0-9]{1,3}\.){3}[0-9]{1,3}$')]

    return vm_ip_is_true_regex, vm_ip_and_uuid_df

def update_antivirus_column_vm_list(vm_ip_is_true_regex, vm_ip_and_uuid_df):
    vm_list_table_name = "kr_vm_list"

    Session = sessionmaker(bind=db_instance)
    session = Session()

    if not vm_ip_is_true_regex.empty:
        try:
            for index, row in vm_ip_is_true_regex.iterrows():
                sql = text(f"UPDATE {vm_list_table_name} "
                           f"SET antivirus = :antivirus "
                           f"WHERE uuid = :uuid ")
                session.execute(sql, {
                    'antivirus': row['antivirus'],
                    'uuid': row['uuid']
                })

            # vm_ip_and_uuid_df'deki uuid'lerden vm_ip_is_true_regex'deki uuid'leri çıkar
            remaining_uuids = set(vm_ip_and_uuid_df['uuid']) - set(vm_ip_is_true_regex['uuid'])

            # Kalan UUID'lerin antivirüs değerlerini 0 olarak güncelle
            for uuid in remaining_uuids:
                sql = text(f"UPDATE {vm_list_table_name} "
                           f"SET antivirus = 0 "
                           f"WHERE uuid = :uuid ")
                session.execute(sql, {'uuid': uuid})

            session.commit()
            print("VM Listesi Güncellendi")
        except Exception as e:
            session.rollback()
            print("VM Listesi Güncelleme Hatası:", e)
        finally:
            session.close()


if __name__ == "__main__":
    try:
        print(f"{os.path.basename(__file__)} running...")
        LogProcess.create_logger_settings(log_prefix=os.path.basename(__file__).split(".")[0], script_dir=os.path.dirname(os.path.realpath(__file__)))
        filtered_credentials = GetCredential("SOPHOS").filtered_data_to_dataframe()
        row = filtered_credentials.iloc[0]

        db_instance = PostgresConnection().get_db_instance()

        access_token, expires_in = get_access_token(row['clientId'], row['clientSecret'])
        if not access_token:
            exit()

        print("Access Token:", access_token)
        print("Expires In:", expires_in)

        tenant_id, proxy_url = get_tenant_and_proxy(access_token)
        if not tenant_id or not proxy_url:
            exit()

        print("")
        print("Tenant ID:", tenant_id)
        print("Proxy URL:", proxy_url)

        vm_ip_is_true_regex, vm_ip_and_uuid_df = list_all_endpoints(access_token, tenant_id, proxy_url)

        update_antivirus_column_vm_list(vm_ip_is_true_regex, vm_ip_and_uuid_df)
    except Exception as e:
        print(f"RUNNING_ERROR: Sophos işlemi sırasında hata oluştu")
        exit(1)