from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[2]))
import requests
import pandas as pd
import logging
from Discovery.utils.ConfigReader import ConfigReader


class GetCredential:
    def __init__(self, environment):
        self.config = ConfigReader().return_discovery_config()
        self.base_url = self.config.get(section='java-api', option='base_url')

        self.__URL = f"http://{self.base_url}/pfms/rest/karcin-pfms/python-api/sendRequest"
        self.environment = environment

        self.BODY = {
            "method": "getConnections",
            "processor": "parametricData",
            "data": {}
        }
        logging.info(f"Ortam Bağlantı Bilgileri Alınıyor... ---> {self.environment}")

    def get_credential_and_filter(self):
        try:
            # Timeout ekledik
            response = requests.post(
                self.__URL, headers=None, json=self.BODY, timeout=30  # 10 saniyelik timeout
            )
            response.raise_for_status()  # HTTP hatalarını yakala (örneğin, 4xx veya 5xx)
        except requests.exceptions.Timeout:
            logging.error(f"İstek zaman aşımına uğradı: {self.__URL}")
            return []
        except requests.exceptions.RequestException as e:
            logging.error(f"Ortam Bağlantı bilgileri alınırken hata oluştu: {e}")
            return []

        try:
            response_data = response.json()
        except ValueError as e:
            logging.error(f"Yanıt JSON formatında değil: {e}")
            return []

        # 'resultMap' içindeki 'data' listesini al ve filtrele
        result_map = response_data.get('resultMap', {})
        data_list = result_map.get('data', [])

        # 'environment' filtresine göre filtrele
        filtered_data = [
            entry for entry in data_list
            if entry.get('environment') == self.environment
        ]

        return filtered_data

    def filtered_data_to_dataframe(self):
        # Filtrelenmiş veriyi al
        filtered_data = self.get_credential_and_filter()

        if not filtered_data:
            error_message = f"{self.environment} ortamı için bağlantı bilgisi bulunamadı!"
            logging.error(error_message)
            raise ValueError(error_message)

        rows = []

        for entry in filtered_data:
            base_info = {
                "environment": entry.get("environment"),
                "endpoint": entry.get("endpoint"),
                "configuration_name": entry.get("configuration_name")
            }

            # Parameters'i dict olarak işlemek
            parameters = {param["name"]: param["value"] for param in entry.get("parameters", [])}

            # Base info ile parameters'i birleştir ve bir satır olarak ekle
            row = {**base_info, **parameters}
            rows.append(row)

        # DataFrame oluştur
        df = pd.DataFrame(rows)
        logging.info(f"Ortam Bağlantı bilgileri başarıyla alındı. ---> {self.environment}")
        return df
