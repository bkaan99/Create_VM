from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[2]))
import logging
import time
from typing import Optional
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql import text
import pandas as pd
from contextlib import contextmanager
from sqlalchemy.exc import OperationalError, DBAPIError
import socket
from Discovery.utils.ConfigReader import ConfigReader


class PostgresConnection:
    def __init__(self, retries: int = 3, delay: int = 5):
        """
        Args:
            config_file (str): Bağlantı bilgilerini içeren config dosyasının yolu (varsayılan olarak 'config/discovery_utils.conf').
            retries (int): Bağlantı deneme sayısı.
            delay (int): Başarısız bağlantılar arasında bekleme süresi (saniye).
        """
        self.config = ConfigReader().return_discovery_config()

        # PostgreSQL bilgilerini config dosyasından okuma
        self.db_url = self.config.get('postgresql', 'url')
        self.db_port = self.config.get('postgresql', 'port')
        self.db_name = self.config.get('postgresql', 'db_name')
        self.db_user = self.config.get('postgresql', 'user')
        self.db_password = self.config.get('postgresql', 'password')
        self.db_timeout = self.config.getint('postgresql', 'timeout')

        self.db_connection_string = (
            f"postgresql+psycopg2://{self.db_user}:{self.db_password}@{self.db_url}:{self.db_port}/{self.db_name}"
        )
        self.retries = retries
        self.delay = delay
        self.db_instance: Optional[Engine] = None

    def connect_to_postgres(self) -> Engine:
        """
        PostgreSQL veritabanına bağlantı kurar ve bir Engine nesnesi döner.
        Bağlantı başarısız olursa belirli sayıda yeniden deneme yapar.
        """
        attempt = 0
        while attempt < self.retries:
            try:
                logging.info(f"{self.db_url} adresinde --> PostgreSQL'e bağlanılıyor...")
                engine: Engine = create_engine(self.db_connection_string, pool_pre_ping=True, connect_args={"connect_timeout": self.db_timeout})
                # Test bağlantısı
                with engine.connect() as conn:
                    conn.execute(text("SELECT 1"))
                logging.info("PostgreSQL'e başarıyla bağlanıldı.")
                return engine
            except OperationalError as e:
                attempt += 1
                logging.error(f"PostgreSQL'e bağlanırken OperationalError oluştu: {e}. {attempt}/{self.retries} deneme yapılıyor.")
                if attempt < self.retries:
                    time.sleep(self.delay)
            except (socket.timeout, DBAPIError) as e:
                attempt += 1
                logging.error(f"PostgreSQL bağlantısı zaman aşımına uğradı: {e}. {attempt}/{self.retries} deneme yapılıyor.")
                if attempt < self.retries:
                    time.sleep(self.delay)
            except Exception as e:
                logging.error(f"PostgreSQL bağlantısı sırasında beklenmedik bir hata oluştu: {e}")
                raise("RUNNING_ERROR PostgreSQL bağlantısı sırasında beklenmedik bir hata oluştu.")
        logging.critical("PostgreSQL'e bağlanılamadı. Program sonlandırılıyor.")
        raise ConnectionError("RUNNING_ERRROR PostgreSQL'e bağlanılamadı.")

    def get_db_instance(self) -> Engine:
        """
        Singleton yaklaşımı ile bir veritabanı instance'ı döner.
        Eğer mevcut bir bağlantı yoksa, yeni bir bağlantı oluşturur.
        """
        if self.db_instance is None:
            logging.info("Yeni bir veritabanı bağlantısı oluşturuluyor.")
            self.db_instance = self.connect_to_postgres()
        else:
            logging.info("Mevcut veritabanı bağlantısı kullanılıyor.")
        return self.db_instance

    def close_db_instance(self) -> None:
        """
        Veritabanı bağlantısını kapatır ve instance'ı sıfırlar.
        """
        if self.db_instance is not None:
            logging.info("PostgreSQL bağlantısı kapatılıyor...")
            self.db_instance.dispose()
            self.db_instance = None
            logging.info("PostgreSQL bağlantısı başarıyla kapatıldı.")
        else:
            logging.info("Kapatılacak bir PostgreSQL bağlantısı bulunamadı.")

    def execute_query(self, query: str, params: dict = None) -> None:
        """
        Sorgu çalıştırmak için kullanılır.
        """
        session = self.get_session()
        try:
            session.execute(text(query), params or {})
            session.commit()
        except Exception as e:
            logging.error(f"Sorgu çalıştırılırken hata oluştu: {e}")
            session.rollback()
            raise(f"RUNNING_ERROR Sorgu çalıştırılırken hata oluştu.")
        finally:
            session.close()

    def fetch_dataframe(self, query: str) -> pd.DataFrame:
        """
        Sorgu sonucunu pandas DataFrame olarak döner.
        """
        try:
            df = pd.read_sql_query(query, self.get_db_instance())
            return df
        except Exception as e:
            logging.error(f"DataFrame çekilirken hata oluştu: {e}")
            raise(f"RUNNING_ERROR DataFrame çekilirken hata oluştu.")

    def get_session(self):
        """
        SQLAlchemy oturumu döner.
        """
        if not hasattr(self, '_Session'):
            self._Session = sessionmaker(bind=self.get_db_instance())
        return self._Session()

    @contextmanager
    def session_scope(self):
        """Bir oturum için context manager."""
        session = self.get_session()
        try:
            yield session
            session.commit()
        except Exception as e:
            logging.error(f"Oturum sırasında hata oluştu: {e}")
            session.rollback()
            raise(f"RUNNING_ERROR Oturum sırasında hata oluştu.")
        finally:
            session.close()