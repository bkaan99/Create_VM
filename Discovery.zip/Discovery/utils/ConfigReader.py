import configparser
import os

class ConfigReader:
    def __init__(self, config_file: str = "config/discovery_utils.conf"):
        """
        Args:
            config_file (str): Bağlantı bilgilerini içeren config dosyasının yolu (varsayılan olarak 'config/discovery_utils.conf').
            section (str): Config
        """
        self.config = configparser.ConfigParser()

        # Dosya yolunu dinamik olarak almak
        config_path = os.path.join(os.path.dirname(__file__), config_file)
        self.config.read(config_path)

    def return_discovery_config(self):
        return self.config