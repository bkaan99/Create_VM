import logging
from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[2]))
import pandas as pd
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine, text
import requests
import urllib3
import os
import logging
from Discovery.utils.LogProcess import LogProcess
from Discovery.utils.PostgresConnection import PostgresConnection
from Discovery.utils.GetCredential import GetCredential

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
print(f"{os.path.basename(__file__)} running...")


def get_vlan_ids_from_db(db_instance):
    """Database'den kr_vm_list tablosundan environment ve vlan_id kolonlarını alır."""
    vm_list_table_name = "kr_vm_list"

    query_vmlist_vm_vlans = f"SELECT vlanid, uuid FROM {vm_list_table_name} WHERE vlanid IS NOT NULL and is_deleted = false"
    vmlist_vm_vlans = pd.read_sql_query(query_vmlist_vm_vlans, db_instance)
    vmlist_vm_vlans = vmlist_vm_vlans[vmlist_vm_vlans['vlanid'].apply(lambda x: str(x).isdigit())]  # Yalnızca sayısal VLAN ID'leri al
    vmlist_vm_vlans['vlanid'] = vmlist_vm_vlans['vlanid'].astype(int)  # VLAN ID'leri int türüne dönüştür

    return vmlist_vm_vlans

def get_all_vlans_from_fortigate():
    """Tüm Fortigate ortamlarından VLAN ve VDOM bilgilerini alır."""
    logging.info("Fortigate ortamlarından tüm VLAN ve VDOM bilgileri alınıyor.")
    vlan_vdom_data = []
    for index, row in filtered_credentials.iterrows():
        try:
            logging.info(f"{row['dataCenter']} merkezinden VLAN bilgileri alınıyor.")
            headers = {"Authorization": f"Bearer {row['accessToken']}"}
            response = requests.get(f"https://{row['endpoint']}:{row['port']}/api/v2/cmdb/system/interface", headers=headers, verify=False)
            if response.status_code == 200:
                logging.info(f"{row['dataCenter']} merkezinden VLAN bilgileri alındı.")
                vlans = response.json().get('results', [])
                # Her VLAN için VLAN ID ve VDOM bilgilerini ekle
                for vlan in vlans:
                    vlan_id = vlan.get('vlanid')
                    vdom = vlan.get('vdom', 'Bilinmeyen VDOM')
                    center = row['dataCenter']
                    if vlan_id is not None:
                        vlan_vdom_data.append({'vlanid': int(vlan_id), 'vdom': vdom, 'center': center})
            else:
                print(f"Error fetching VLANs from {row['endpoint']}: {response.status_code}")
                logging.info(f"{row['dataCenter']} merkezinden VLAN bilgileri alınırken hata oluştu: {response.status_code}")
        except Exception as e:
            print(f"An error occurred while getting VLAN information: {e}")
            logging.error("VLAN bilgileri alınırken bir hata oluştu.")

    logging.info("Tüm VLAN ve VDOM bilgileri alındı.")
    return pd.DataFrame(vlan_vdom_data, columns=['vlanid', 'vdom', 'center'])

def get_bandwidth_info_for_vdom(distinct_vdoms):
    """Belirli bir VDOM için bant genişliği bilgilerini alır."""
    logging.info("----VDOM'lar için Bant genişliği bilgileri alınıyor.----")
    all_bandwidth_data = []
    exclude_names = ["guarantee-100kbps", "high-priority", "low-priority", "medium-priority", "shared-1M-pipe"]

    for vdom_name in distinct_vdoms:
        bandwidth_data = []
        for index, row in filtered_credentials.iterrows():
            try:
                headers = {"Authorization": f"Bearer {row['accessToken']}"}
                response = requests.get(f"https://{row['endpoint']}:{row['port']}/api/v2/cmdb/firewall.shaper/traffic-shaper", headers=headers, params={'vdom': vdom_name}, verify=False)

                if response.status_code == 200:
                    shapers_data = response.json().get('results', [])

                    # Filtrelenmiş shaper verilerini eklemek için geçici bir liste
                    valid_shapers_found = False
                    for shaper in shapers_data:
                        shaper_name = shaper.get('name', '').lower()
                        if shaper_name in exclude_names:
                            continue  # İstenmeyen girdileri atla

                        max_bandwidth = shaper.get('maximum-bandwidth', 0)
                        unit = shaper.get('bandwidth-unit', 'kbps')
                        max_bandwidth_mbps = (max_bandwidth if unit == 'mbps' else
                                              (max_bandwidth / 1000 if unit == 'kbps' else
                                               max_bandwidth * 1000 if unit == 'gbps' else 0))
                        bandwidth_data.append({
                            'VDOM Name': vdom_name,
                            'Center': row['dataCenter'],
                            'Maximum Bandwidth (Mbps)': max_bandwidth_mbps
                        })
                        valid_shapers_found = True
                        # Bulunan bant genişliği bilgisini yazdır
                        print(f"VDOM '{vdom_name}' için {row['dataCenter']} merkezinde bulunan bant genişliği: {max_bandwidth_mbps} Mbps")

                    # Eğer geçerli bir shaper bulunamazsa, 0 Mbps olarak varsayılan bir giriş ekle
                    if not valid_shapers_found:
                        bandwidth_data.append({
                            'VDOM Name': vdom_name,
                            'Center': row['dataCenter'],
                            'Maximum Bandwidth (Mbps)': 0
                        })
                        print(f"VDOM '{vdom_name}' için {row['dataCenter']} merkezinde geçerli bir shaper bulunamadı. Maksimum Bant Genişliği 0 Mbps olarak ayarlandı.")
                else:
                    print(f"VDOM '{vdom_name}' için {row['endpoint']}'den bant genişliği alınırken hata oluştu: {response.status_code}")

                    # API hatası durumunda da 0 Mbps olarak ekle
                    bandwidth_data.append({
                        'VDOM Name': vdom_name,
                        'Center': row['dataCenter'],
                        'Maximum Bandwidth (Mbps)': 0
                    })

            except Exception as e:
                print(f"VDOM '{vdom_name}' için bant genişliği bilgisi alınırken bir hata oluştu: {e}")

                # Exception durumunda da 0 Mbps olarak ekle
                bandwidth_data.append({
                    'VDOM Name': vdom_name,
                    'Center': row['dataCenter'],
                    'Maximum Bandwidth (Mbps)': 0
                })

        all_bandwidth_data.extend(bandwidth_data)

    logging.info("----VDOM'lar için Bant genişliği bilgileri alındı.----")

    return pd.DataFrame(all_bandwidth_data, columns=['VDOM Name', 'Center', 'Maximum Bandwidth (Mbps)'])

def get_ipsec_tunnel_info_by_vdom(distinct_vdoms):
    """Belirli VDOM'lar için IPsec tünel bilgilerini alır."""
    ipsec_data = {}

    for index, row in filtered_credentials.iterrows():
        for vdom_name in distinct_vdoms:
            try:
                headers = {"Authorization": f"Bearer {row['accessToken']}"}
                params = {"vdom": vdom_name}
                response = requests.get(f"https://{row['endpoint']}:{row['port']}/api/v2/monitor/vpn/ipsec", headers=headers, params=params, verify=False)

                if response.status_code == 200:
                    tunnels_data = response.json().get('results', [])
                    ipsec_count = len(tunnels_data)

                    if vdom_name in ipsec_data:
                        ipsec_data[vdom_name] += ipsec_count
                    else:
                        ipsec_data[vdom_name] = ipsec_count
                    print(f"Found {ipsec_count} IPsec tunnels for VDOM '{vdom_name}' in {row['dataCenter']}")
                else:
                    print(f"Error fetching IPsec tunnel information for VDOM '{vdom_name}': {response.status_code}")
            except Exception as e:
                print(f"An error occurred while getting IPsec tunnel information for VDOM '{vdom_name}': {e}")

    ipsec_df = pd.DataFrame(
        [{'vdom_name': vdom, 'ipsec_tunnel_count': count} for vdom, count in ipsec_data.items()]
    )
    return ipsec_df

def get_ssl_vpn_user_count_by_vdom(distinct_vdoms):
    """Belirli VDOM'lar için SSL VPN kullanıcı sayısını alır."""
    ssl_vpn_data = {}

    for index, row in filtered_credentials.iterrows():
        for vdom_name in distinct_vdoms:
            try:
                headers = {"Authorization": f"Bearer {row['accessToken']}"}
                params = {"vdom": vdom_name}
                response = requests.get(f"https://{row['endpoint']}:{row['port']}/api/v2/monitor/vpn/ssl", headers=headers, params=params, verify=False)

                if response.status_code == 200:
                    users_data = response.json().get('results', [])
                    ssl_user_count = len(users_data)

                    # Aggregate SSL VPN user count for the VDOM
                    if vdom_name in ssl_vpn_data:
                        ssl_vpn_data[vdom_name] += ssl_user_count
                    else:
                        ssl_vpn_data[vdom_name] = ssl_user_count

                    print(f"Found {ssl_user_count} SSL VPN users for VDOM '{vdom_name}' in {row['dataCenter']}")
                else:
                    print(f"Error fetching SSL VPN user information for VDOM '{vdom_name}': {response.status_code}")
            except Exception as e:
                print(f"An error occurred while getting SSL VPN user information for VDOM '{vdom_name}': {e}")

    # Convert to DataFrame
    ssl_vpn_df = pd.DataFrame(
        [{'vdom_name': vdom, 'ssl_vpn_user_count': count} for vdom, count in ssl_vpn_data.items()]
    )
    return ssl_vpn_df

def vlanname_and_vlanid():
    vlan_vdom_data = []
    logging.info("Fortigate ortamlarından tüm VLAN_IDve VLAN Name bilgileri alınıyor.")
    for index, row in filtered_credentials.iterrows():
        try:
            headers = {"Authorization": f"Bearer {row['accessToken']}"}
            response = requests.get(f"https://{row['endpoint']}:{row['port']}/api/v2/cmdb/system/interface", headers=headers, verify=False)
            if response.status_code == 200:
                vlans = response.json().get('results', [])
                # Her VLAN için VLAN ID ve VDOM bilgilerini ekle
                for vlan in vlans:
                    vlan_id = vlan.get('vlanid')
                    vlanname = vlan.get('name', 'Bilinmeyen VDOM')

                    vlan_vdom_data.append({'vlanid': int(vlan_id), 'vlanname': vlanname})
            else:
                print(f"Error fetching VLANs from {row['endpoint']}: {response.status_code}")
        except Exception as e:
            print(f"An error occurred while getting VLAN information: {e}")

    logging.info("Tüm VLAN ve VLAN Name bilgileri alındı.")
    return pd.DataFrame(vlan_vdom_data, columns=['vlanid', 'vlanname'])

def get_firewall_rules_for_vdom(distinct_vdoms):
    """Belirli VDOM'lar için firewall kurallarını alır."""
    logging.info("----Firewall kuralları alınıyor.----")
    firewall_rules_data = []

    vname_and_vid = vlanname_and_vlanid()

    logging.info("Fortigate ortamlarından tüm firewall kuralları alınıyor.")
    for index, row in filtered_credentials.iterrows():
        for vdom_name in distinct_vdoms:
            try:
                headers = {"Authorization": f"Bearer {row['accessToken']}"}
                params = {"vdom": vdom_name}
                response = requests.get(f"https://{row['endpoint']}:{row['port']}/api/v2/cmdb/firewall/policy", headers=headers, params=params, verify=False)

                if response.status_code == 200:
                    rules = response.json().get('results', [])
                    for rule in rules:
                        rule_id = rule.get('policyid', 'Belirtilmemiş')
                        src_addr = [addr.get('name', 'Bilinmiyor') for addr in rule.get('srcaddr', [])]
                        dst_addr = [addr.get('name', 'Bilinmiyor') for addr in rule.get('dstaddr', [])]
                        action = rule.get('action', 'Belirtilmemiş')
                        status = rule.get('status', 'Belirtilmemiş')
                        #center = config['center']
                        service = [srv.get('name', 'Bilinmiyor') for srv in rule.get('service', [])]
                        from_names = [frm.get('name', 'Bilinmiyor') for frm in rule.get('srcintf', [])]  # "from" alanını işleme
                        rule_name = rule.get('name', 'Belirtilmemiş')  # "name" alanını çekiyoruz
                        vlan_id = ",".join("{" + str(vname_and_vid[vname_and_vid['vlanname'] == vlan]['vlanid'].values[0]) + "}" for vlan in from_names)

                        firewall_rules_data.append({
                            'vdomname': vdom_name,
                            'sourceaddress': src_addr,
                            'destinationaddress': dst_addr,
                            'firewallvalue': action,
                            'status': status,
                            'servicedescription': service,
                            'vlanname': from_names,
                            'description': rule_name,
                            'vlanid': vlan_id
                        })

                        print(f"Found firewall rule for VDOM '{vdom_name}' in {row['dataCenter']}: Rule ID {rule_id}, Action: {action}, Status: {status}, Service: {service}, From: {from_names}")
                        print(f"Source Address: {src_addr}, Destination Address: {dst_addr}")
                else:
                    print(f"Error fetching firewall rules for VDOM '{vdom_name}' from {row['endpoint']}: {response.status_code}")
            except Exception as e:
                print(f"An error occurred while getting firewall rules for VDOM '{vdom_name}': {e}")

    # "firewallvalue" değerlerini güncellemes
    for rule in firewall_rules_data:
        rule['firewallvalue'] = True if rule['firewallvalue'].lower() == "accept" else False

    # Convert to DataFrame
    firewall_rules_df = pd.DataFrame(firewall_rules_data)
    logging.info("Tüm firewall kuralları alındı.")
    return firewall_rules_df

def update_vlans_in_db(vlan_vdom_map, db_instance):
    """Veritabanındaki VLAN bilgilerini günceller."""
    logging.info("--------- kr_vm_list tablosunda ki VDOM bilgileri Güncelleme işlmeleri başlıyor. ---------")
    df = get_vlan_ids_from_db(db_instance)

    # VLAN ID'ye göre grup yapıp, her VLAN için tüm VDOM'ları virgüllü formatta birleştiriyoruz
    vlan_vdom_map_grouped = (
        vlan_vdom_map
        .groupby('vlanid')['vdom']
        .apply(lambda x: ',' + ','.join(sorted(set(v.strip() for v in x if v.strip()))) + ',')
        .reset_index()
    )

    # Gruplanmış DataFrame'i veritabanından aldığımız DataFrame ile birleştiriyoruz
    merged_df = pd.merge(df, vlan_vdom_map_grouped, on='vlanid', how='left', suffixes=('', '_fortigate'))
    merged_df['vdom'] = merged_df['vdom'].fillna('N/A')

    # VLAN ID'si 0 olan satırları 'N/A' olarak güncelle
    merged_df.loc[merged_df['vlanid'] == 0, 'vdom'] = 'N/A'
    #merged_df.to_csv('merged_df.csv', index=False)

    vm_list_table_name = "kr_vm_list"
    print("Merged DataFrame:")
    print(merged_df)

    Session = sessionmaker(bind=db_instance)
    session = Session()
    try:
        for _, row in merged_df.iterrows():
            uuid = row['uuid']
            vdom = row['vdom']

            session.execute(
                text(f"UPDATE {vm_list_table_name} SET vdom = :vdom WHERE uuid = :uuid"),
                {'vdom': vdom, 'uuid': uuid}
            )
        session.commit()
        logging.info("VDOM bilgileri başarıyla güncellendi.")
    except Exception as e:
        print(f"An error occurred while updating VLAN information in the database: {e}")
        session.rollback()
        logging.error("VDOM bilgileri güncellenirken bir hata oluştu.")
    finally:
        session.close()
    print("VDOM bilgileri başarıyla güncellendi.")
    logging.info("kr_vm_list tablosunda ki VDOM bilgileri Güncelleme işlmeleri tamamlandı.")

def handle_vdom_bandwidth_for_customer(max_bandwidth_df_vdom_all_env, db_instance, distinct_vdoms):
    """Müşteri ve VDOM bilgilerini işler."""
    logging.info("-------- Müşteri ve VDOM bilgileri işleniyor.. --------")
    customer_table = "kr_customers"
    resource_account_mapping_table = "kr_resource_account_mapping"
    vm_list_table = "kr_vm_list"

    # Sorgu ile müşteri vdom bilgilerini alıyoruz
    query_vdom_for_customer_is_exist = f"""SELECT distinct(kc.id), kv.vdom
                                        FROM {customer_table} kc
                                        JOIN {resource_account_mapping_table} kram
                                        ON kc.accountid = kram.accountid
                                        JOIN {vm_list_table} kv
                                        ON kram.resourcepoolname = kv.resource_pool
                                        WHERE kv.vdom IS NOT NULL 
                                        AND kv.vdom <> ''
                                        AND kv.is_deleted = FALSE;"""

    # vdom bilgilerini dataframe olarak alıyoruz
    vdom_for_customer_is_exist_df = pd.read_sql_query(query_vdom_for_customer_is_exist, db_instance)
    #vdom_for_customer_is_exist_df.to_csv('vdom_for_customer_is_exist.csv', index=False)

    # VDOM verilerini ayır ve satırları genişlet
    vdom_for_customer_is_exist_df = vdom_for_customer_is_exist_df.assign(
        vdom=vdom_for_customer_is_exist_df['vdom'].str.split(',')
    ).explode('vdom')

    # Boşlukları temizle
    vdom_for_customer_is_exist_df['vdom'] = vdom_for_customer_is_exist_df['vdom'].str.strip()
    # Benzersiz satırları koru
    vdom_for_customer_is_exist_df = vdom_for_customer_is_exist_df.drop_duplicates(subset=['id', 'vdom']).reset_index(drop=True)
    # Boş 'vdom' değerlerini kaldır
    vdom_for_customer_is_exist_df = vdom_for_customer_is_exist_df[vdom_for_customer_is_exist_df['vdom'] != '']


    # 'center' türüne göre max_bandwidth_df_vdom_all_env veri çerçevesini pivot ediyoruz
    max_bandwidth_df_vdom_all_env_pivot = max_bandwidth_df_vdom_all_env.pivot_table(
        index='VDOM Name', columns='Center', values='Maximum Bandwidth (Mbps)', fill_value=0
    ).reset_index()

    # 'max_bandwidth_df_vdom_all_env_pivot' dataframe'ini, 'vdom_for_customer_is_exist_df' ile join ediyoruz
    result_df = pd.merge(vdom_for_customer_is_exist_df, max_bandwidth_df_vdom_all_env_pivot,left_on='vdom', right_on='VDOM Name', how='left')
    result_df = result_df.rename(columns={'equinix': 'bandwidth-2', 'kkb': 'bandwidth-1', 'turksat': 'bandwidth-3', 'id' : 'customer_id'})
    result_df = result_df[['customer_id', 'vdom', 'bandwidth-1', 'bandwidth-2', 'bandwidth-3']]
    print("VDOM ve Müşteri bilgileri:")
    print(result_df)

    all_ipsec_data = get_ipsec_tunnel_info_by_vdom(distinct_vdoms)
    print("\nIPsec Tunnel Information:")
    print(all_ipsec_data)

    all_ssl_vpn_data = get_ssl_vpn_user_count_by_vdom(distinct_vdoms)
    print("\nSSL VPN User Information:")
    print(all_ssl_vpn_data)

    # all_ipsec_data ve all_ssl_vpn_data veri çerçevelerini vdom_name'e göre birleştiriyoruz
    result_df = pd.merge(result_df, all_ipsec_data, left_on='vdom', right_on='vdom_name', how='left')
    result_df = pd.merge(result_df, all_ssl_vpn_data, left_on='vdom', right_on='vdom_name', how='left')
    print("\nall_ssl_vpn_data ve all_ipsec_data merged DF:")
    print(result_df)

    # Müşteri ID'ye göre gruplayarak her bir müşteri için en yüksek bant genişliğini ve toplam SSL VPN ve IPsec tünel sayısını seçiyoruz
    result_df_max_bandwidth = result_df.groupby('customer_id').agg({
        'bandwidth-1': 'max',
        'bandwidth-2': 'max',
        'bandwidth-3': 'max',
        'ssl_vpn_user_count': 'sum',
        'ipsec_tunnel_count': 'sum'
    }).reset_index()

    # 'customer_id'ye göre farklı 'vdom' sayısını hesaplıyoruz (FWaaS)
    vdom_count_df = result_df.groupby('customer_id')['vdom'].nunique().reset_index()
    vdom_count_df = vdom_count_df.rename(columns={'vdom': 'fwaassize'})

    # 'fwaas' sayısını 'result_df_max_bandwidth' ile birleştiriyoruz
    result_df_max_bandwidth = pd.merge(result_df_max_bandwidth, vdom_count_df, on='customer_id', how='left')
    result_df_max_bandwidth.rename(columns={
        'bandwidth-1': 'bandwidthsize',
        'bandwidth-2': 'bandwidthsize2',
        'bandwidth-3': 'bandwidthsize3',
        'ssl_vpn_user_count': 'sslvpnsize',
        'ipsec_tunnel_count': 's2svpnsize'
    }, inplace=True)

    logging.info("-------- Müşteri ve VDOM bilgileri işlendi. --------")
    return result_df_max_bandwidth

def upsert_vdom_bandwidth_for_product_usage(result_df_max_bandwidth, db_instance):
    """Product Usage tablosu için VDOM bant genişliğini günceller."""
    logging.info("-------- VDOM bant genişliği bilgileri için Product Usage tablosu güncelleme işlemleri başlıyor.. --------")
    product_usage_table = "kr_product_usage"

    query_all_customer_ids = f"""SELECT customer_id FROM {product_usage_table}"""
    all_customer_ids = pd.read_sql_query(query_all_customer_ids, db_instance)

    Session = sessionmaker(bind=db_instance)
    session = Session()

    try:
        logging.info("Product Usage tablosu güncelleniyor..")
        for _, row in result_df_max_bandwidth.iterrows():
            customer_id = row['customer_id']

            bandwidthsize = row['bandwidthsize'] if not pd.isna(row['bandwidthsize']) else 0
            bandwidthsize2 = row['bandwidthsize2'] if not pd.isna(row['bandwidthsize2']) else 0
            bandwidthsize3 = row['bandwidthsize3'] if not pd.isna(row['bandwidthsize3']) else 0
            fwaassize = row['fwaassize'] if not pd.isna(row['fwaassize']) else 0
            s2svpnsize = row['s2svpnsize'] if not pd.isna(row['s2svpnsize']) else 0
            sslvpnsize = row['sslvpnsize'] if not pd.isna(row['sslvpnsize']) else 0

            session.execute(
                text(f"UPDATE {product_usage_table} "
                     f"SET bandwidthsize = :bandwidthsize, bandwidthsize2 = :bandwidthsize2, "
                     f"bandwidthsize3 = :bandwidthsize3, fwaassize = :fwaassize,"
                     f"fi_fwaassize = :fi_fwaassize,"
                     f"s2svpnsize = :s2svpnsize, sslvpnsize = :sslvpnsize "
                     f"WHERE customer_id = :customer_id"),
                {
                    'bandwidthsize': bandwidthsize,
                    'bandwidthsize2': bandwidthsize2,
                    'bandwidthsize3': bandwidthsize3,
                    'fwaassize': fwaassize,
                    'fi_fwaassize': 0,
                    's2svpnsize': s2svpnsize,
                    'sslvpnsize': sslvpnsize,
                    'customer_id': customer_id
                }
            )

        customer_ids_to_zero = set(all_customer_ids['customer_id']) - set(result_df_max_bandwidth['customer_id'])
        for customer_id in customer_ids_to_zero:
            session.execute(
                text(f"UPDATE {product_usage_table} "
                     f"SET bandwidthsize = 0, bandwidthsize2 = 0, bandwidthsize3 = 0, fwaassize = 0 ,fi_fwaassize = 0, s2svpnsize = 0, sslvpnsize = 0 "
                     f"WHERE customer_id = :customer_id"),
                {'customer_id': customer_id}
            )

        session.commit()
        logging.info("Product Usage tablosu başarıyla güncellendi.")

    except Exception as e:
        print(f"An error occurred while updating VDOM bandwidth information for product usage: {e}")
        session.rollback()
        logging.error("Product Usage tablosu güncellenirken bir hata oluştu.")
    finally:
        session.close()

    logging.info("-------- VDOM bant genişliği bilgileri için Product Usage tablosu güncelleme işlemleri tamamlandı. --------")

def upsert_firewall_rules(distinct_vdoms, db_instance):
    """Firewall kurallarını günceller ve soft delete uygular."""
    logging.info("-------- Firewall kuralları Güncelleme İşlemleri Başlatılıyor.. --------")
    firewall_rules = get_firewall_rules_for_vdom(distinct_vdoms)
    firewall_rules_table = "kr_firewall_rules"

    check_firewall_rule_table = f"""SELECT vdomname, vlanid, vlanname, is_deleted, description FROM {firewall_rules_table}"""
    existing_firewall_rules_df = pd.read_sql_query(check_firewall_rule_table, db_instance)

    firewall_rules['vdomname'] = firewall_rules['vdomname'].astype(str)
    firewall_rules['vlanid'] = firewall_rules['vlanid'].astype(str)
    firewall_rules['vlanname'] = firewall_rules['vlanname'].astype(str)
    firewall_rules['composite_key'] = (
            firewall_rules['vdomname'] + "_" + firewall_rules['vlanid'] + "_" + firewall_rules['vlanname'] + "_" + firewall_rules['description']
    )

    existing_firewall_rules_df['vdomname'] = existing_firewall_rules_df['vdomname'].astype(str)
    existing_firewall_rules_df['vlanid'] = existing_firewall_rules_df['vlanid'].astype(str)
    existing_firewall_rules_df['vlanname'] = existing_firewall_rules_df['vlanname'].astype(str)
    existing_firewall_rules_df['composite_key'] = (
            existing_firewall_rules_df['vdomname'] + "_" + existing_firewall_rules_df['vlanid'] + "_" + existing_firewall_rules_df['vlanname'] + "_" + existing_firewall_rules_df['description']
    )

    to_insert = firewall_rules[~firewall_rules['composite_key'].isin(existing_firewall_rules_df['composite_key'])]
    to_update = firewall_rules[firewall_rules['composite_key'].isin(existing_firewall_rules_df['composite_key'])]
    to_delete = existing_firewall_rules_df[~existing_firewall_rules_df['composite_key'].isin(firewall_rules['composite_key'])]

    #drop composite_key column
    to_insert.drop(columns=['composite_key'], inplace=True)
    to_update.drop(columns=['composite_key'], inplace=True)
    to_delete.drop(columns=['composite_key'], inplace=True)

    Session = sessionmaker(bind=db_instance)
    session = Session()

    try:
        if not to_insert.empty:
            to_insert['is_deleted'] = False
            to_insert.to_sql(firewall_rules_table, db_instance, chunksize=5000, index=False, if_exists='append')
            print("Inserted new firewall rules:")
            logging.info(f"{len(to_insert.shape[0])} yeni firewall kuralı eklendi.")

        if not to_update.empty:
            for _, row in to_update.iterrows():
                session.execute(
                    text(f"UPDATE {firewall_rules_table} SET sourceaddress = :sourceaddress, destinationaddress = :destinationaddress, "
                         f"firewallvalue = :firewallvalue, status = :status, servicedescription = :servicedescription, "
                         f"vlanname = :vlanname, description = :description, is_deleted = False "
                         f"WHERE vdomname = :vdomname AND vlanname = :vlanname AND vlanid = :vlanid"),
                    {
                        'sourceaddress': row['sourceaddress'],
                        'destinationaddress': row['destinationaddress'],
                        'firewallvalue': row['firewallvalue'],
                        'status': row['status'],
                        'servicedescription': row['servicedescription'],
                        'vlanname': row['vlanname'],
                        'description': row['description'],
                        'vlanid': row['vlanid'],
                        'vdomname': row['vdomname']
                    }
                )
            print("Updated existing firewall rules:")
            logging.info(f"{len(to_update.shape[0])} firewall kuralı güncellendi.")

        if not to_delete.empty:
            for _, row in to_delete.iterrows():
                session.execute(
                    text(f"UPDATE {firewall_rules_table} SET is_deleted = True "
                         f"WHERE vdomname = :vdomname AND vlanname = :vlanname AND vlanid = :vlanid"),
                    {
                        'vdomname': row['vdomname'],
                        'vlanname': row['vlanname'],
                        'vlanid': row['vlanid']
                    }
                )
            print("Soft-deleted firewall rules:")
            logging.info(f"{len(to_delete.shape[0])} firewall kuralı silindi.")

        session.commit()
        logging.info("Firewall kuralları başarıyla güncellendi.")

    except Exception as e:
        print(f"An error occurred while upserting firewall rules: {e}")
        session.rollback()
        logging.error("Firewall kuralları güncellenirken bir hata oluştu.")


    finally:
        session.close()
    logging.info("-------- Firewall kuralları Güncelleme İşlemleri Tamamlandı. --------")


def main():
    print(f"{os.path.basename(__file__)} running...")
    LogProcess.create_logger_settings(log_prefix=os.path.basename(__file__).split(".")[0], script_dir=os.path.dirname(os.path.realpath(__file__)))
    db_instance = PostgresConnection().get_db_instance()
    logging.info("Fortigate Controller başlatıldı.")
    vlan_vdom_map = get_all_vlans_from_fortigate()
    print("VLAN ve VDOM bilgileri:")
    print(vlan_vdom_map)
    print("---------------------------")

    # Check if the DataFrame is not empty
    if not vlan_vdom_map.empty:
        logging.info("Vlan vdom bilgileri boş değil upsert işlemleri başlatılıyor.")
        update_vlans_in_db(vlan_vdom_map, db_instance)
    else:
        print("No VLAN data retrieved from Fortigate.")
        logging.warning("Fortigate'ten VLAN bilgisi alınamadı.")

    # Get distinct VDOMs
    distinct_vdoms = sorted(vlan_vdom_map['vdom'].unique())
    print("\nDistinct VDOMs:")
    print(distinct_vdoms)
    print("---------------------------")

    upsert_firewall_rules(distinct_vdoms, db_instance)

    bandwidth_df = get_bandwidth_info_for_vdom(distinct_vdoms)

    # Get maximum bandwidth per VDOM
    max_bandwidth_df_vdom_all_env = bandwidth_df.loc[bandwidth_df.groupby(['VDOM Name', 'Center'])['Maximum Bandwidth (Mbps)'].idxmax()]

    print("\nDataFrame of maximum bandwidth information per VDOM:\n")
    print(max_bandwidth_df_vdom_all_env)
    result_df_max_bandwidth = handle_vdom_bandwidth_for_customer(max_bandwidth_df_vdom_all_env, db_instance, distinct_vdoms)

    upsert_vdom_bandwidth_for_product_usage(result_df_max_bandwidth, db_instance)

    PostgresConnection().close_db_instance()


if __name__ == "__main__":
    try:
        filtered_credentials = GetCredential("FORTIGATE").filtered_data_to_dataframe()
        main()
    except Exception as e:
        print(f"RUNNING_ERROR: Script çalıştırılırken bir hata oluştu.")
        logging.error("Script çalıştırılırken bir hata oluştu.")