import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

fortigate_info = {
    'url': 'https://172.21.0.1:7949',
    'access_token': 'prgbnqytcmb1wN3mgjk8cghgGn31jn'
}

def get_interface_info_by_vlan(api_url, access_token, vlan_id):
    try:
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.get(f"{api_url}/api/v2/cmdb/system/interface", headers=headers, verify=False)

        if response.status_code == 200:
            interfaces = response.json()['results']
            # VLAN ID ile eşleşen arayüzü bul
            vlan_interface = next((interface for interface in interfaces if interface.get('vlanid') == vlan_id), None)
            if vlan_interface:
                return vlan_interface
            else:
                print(f"VLAN ID {vlan_id} için arayüz bulunamadı.")
                return None
        else:
            print(f"Arayüz bilgileri alınamadı, hata kodu: {response.status_code}")
            return None
    except Exception as e:
        print(f"Arayüz bilgileri alınırken bir hata oluştu: {e}")
        return None

def get_bandwidth_info(api_url, access_token, interface_name):
    try:
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.get(f"{api_url}/api/v2/cmdb/firewall.shaper/traffic-shaper", headers=headers, verify=False)

        if response.status_code == 200:
            bandwidth_data = response.json()['results']
            # Arayüz adıyla eşleşen bandwidth bilgilerini bul
            shaper_info = next((item for item in bandwidth_data if item.get('name') == interface_name), None)
            if shaper_info:
                return shaper_info
            else:
                print(f"Arayüz {interface_name} için bandwidth bilgisi bulunamadı.")
                return None
        else:
            print(f"Bandwidth bilgileri alınamadı, hata kodu: {response.status_code}")
            return None
    except Exception as e:
        print(f"Bandwidth bilgileri alınırken bir hata oluştu: {e}")
        return None


def get_vdom_info(api_url, access_token, vdom_name):
    try:
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.get(f"{api_url}/api/v2/cmdb/system/vdom", headers=headers, verify=False)

        if response.status_code == 200:
            vdom_data = response.json()['results']
            # VDOM adını bul
            vdom_info = next((vdom for vdom in vdom_data if vdom.get('name') == vdom_name), None)
            if vdom_info:
                return vdom_info
            else:
                print(f"VDOM adı {vdom_name} için VDOM bilgisi bulunamadı.")
                return None
        else:
            print(f"VDOM bilgileri alınamadı, hata kodu: {response.status_code}")
            return None
    except Exception as e:
        print(f"VDOM bilgileri alınırken bir hata oluştu: {e}")
        return None


def get_ipsec_vpn_info(api_url, access_token):
    try:
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.get(f"{api_url}/api/v2/monitor/vpn/ipsec", headers=headers, verify=False)

        if response.status_code == 200:
            return response.json()['results']
        else:
            print(f"IPSec VPN bilgileri alınamadı, hata kodu: {response.status_code}")
            return None
    except Exception as e:
        print(f"IPSec VPN bilgileri alınırken bir hata oluştu: {e}")
        return None


def get_ssl_vpn_info(api_url, access_token):
    try:
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.get(f"{api_url}/api/v2/monitor/vpn/ssl", headers=headers, verify=False)

        if response.status_code == 200:
            return response.json()['results']
        else:
            print(f"SSL VPN bilgileri alınamadı, hata kodu: {response.status_code}")
            return None
    except Exception as e:
        print(f"SSL VPN bilgileri alınırken bir hata oluştu: {e}")
        return None

def main_controller(vlan_id):
    try:
        config = fortigate_info

        # 1. VLAN ID'ye göre arayüz bilgilerini al
        vlan_interface = get_interface_info_by_vlan(config['url'], config['access_token'], vlan_id)

        if vlan_interface:
            print(f"Interface found for VLAN ID {vlan_id}: {vlan_interface.get('name')}")

            # 2. Bu arayüzün bandwidth bilgilerini al
            bandwidth_info = get_bandwidth_info(config['url'], config['access_token'], vlan_interface.get('name'))
            if bandwidth_info:
                print(f"Bandwidth Info: {bandwidth_info}")
            else:
                print("Bandwidth bilgisi alınamadı.")

            # 3. VDOM bilgilerini al
            vdom_info = get_vdom_info(config['url'], config['access_token'], vlan_interface.get('vdom', 'root'))
            if vdom_info:
                print(f"VDOM Info: {vdom_info}")
            else:
                print("VDOM bilgisi alınamadı.")

            # 4. IPSec VPN bilgilerini al
            ipsec_vpn_info = get_ipsec_vpn_info(config['url'], config['access_token'])
            if ipsec_vpn_info:
                print(f"IPSec VPN Info: {ipsec_vpn_info}")
            else:
                print("IPSec VPN bilgisi alınamadı.")

            # 5. SSL VPN bilgilerini al
            ssl_vpn_info = get_ssl_vpn_info(config['url'], config['access_token'])
            if ssl_vpn_info:
                print(f"SSL VPN Info: {ssl_vpn_info}")
            else:
                print("SSL VPN bilgisi alınamadı.")

        else:
            print(f"VLAN ID {vlan_id} için arayüz bulunamadı.")

    except Exception as e:
        print(f"Beklenmedik bir hata oluştu: {e}")


if __name__ == "__main__":
    vlan_id = 108
    main_controller(vlan_id)
