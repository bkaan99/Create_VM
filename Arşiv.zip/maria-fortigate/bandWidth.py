import requests
import configparser
import urllib3
import csv

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
fortigate_environments = [
    {
        'url': 'https://172.21.0.1:7949',
        'access_token': 'prgbnqytcmb1wN3mgjk8cghgGn31jn'
    },
    {
        'url': 'https://172.21.5.1:9993',
        'access_token': 'hb3G4f45ykNbfHmqjhtptcmngzdfw9'
    },
    {
        'url': 'https://10.197.221.1:7949',
        'access_token': 'wc4f9HzsN5yg91p0ttnq4xszt968QQ'
    }
]


def read_config(config_file_path):
    config = configparser.ConfigParser()
    config.read(config_file_path)
    if 'fortigate' not in config:
        raise KeyError("Fortigate section not found in config.ini")
    return {
        'url': config['fortigate']['url'],
        'access_token': config['fortigate']['access_token']
    }

def get_traffic_shapers(api_url, access_token):
    headers = {
        "Authorization": f"Bearer {access_token}"
    }
    response = requests.get(f"{api_url}/api/v2/cmdb/firewall.shaper/traffic-shaper", headers=headers, verify=False)

    if response.status_code == 200:
        return response.json()['results']
    else:
        print(f"Error fetching traffic shapers: {response.status_code}")
        print(response.content)
        return None


def save_traffic_shaper_to_csv(shapers_data, csv_file_path):
    if not shapers_data:
        print("No traffic shaper data available to save.")
        return

    fieldnames = ['Name', 'Guaranteed Bandwidth', 'Max Bandwidth', 'Priority']
    with open(csv_file_path, mode='w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()

        for shaper in shapers_data:
            writer.writerow({
                'Name': shaper.get('name', 'N/A'),
                'Guaranteed Bandwidth': f"{shaper.get('guaranteed-bandwidth', '0')} {shaper.get('bandwidth-unit', 'kbps')}",
                'Max Bandwidth': f"{shaper.get('maximum-bandwidth', '0')} {shaper.get('bandwidth-unit', ' kbps')}",
                'Priority': shaper.get('priority', 'Unknown')
            })

        print(f"Traffic shaper data saved to {csv_file_path}")


def main_controller():
    for config in fortigate_environments:
        shapers_data = get_traffic_shapers(config['url'], config['access_token'])
        save_traffic_shaper_to_csv(shapers_data, "traffic_shapers_bandwidth.csv")

if __name__ == "__main__":
    main_controller()
