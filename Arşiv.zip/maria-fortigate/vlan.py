import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

fortigate_envs = [
    {'url': "https://10.197.221.1:7949", 'access_token': "wc4f9HzsN5yg91p0ttnq4xszt968QQ"},
    {'url': "https://172.21.5.1:9993", 'access_token': "hb3G4f45ykNbfHmqjhtptcmngzdfw9"},
    {'url': "https://172.21.0.1:7949", 'access_token': "prgbnqytcmb1wN3mgjk8cghgGn31jn"}
]

def get_vlans(api_url, access_token):
    try:
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.get(f"{api_url}/api/v2/cmdb/system/interface", headers=headers, verify=False)

        if response.status_code == 200:
            return response.json()['results']
        else:
            print(f"VLAN bilgileri alınamadı: {response.status_code}")
            return None
    except Exception as e:
        print(f"VLAN bilgilerini alırken hata oluştu: {e}")
        return None

def get_firewall_policies(api_url, access_token, interface_name):
    try:
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.get(f"{api_url}/api/v2/cmdb/firewall/policy?filter=srcintf=={interface_name}",
                                headers=headers, verify=False)

        if response.status_code == 200:
            return response.json()['results']
        else:
            print(f"Firewall politikaları alınamadı: {response.status_code}")
            return None
    except Exception as e:
        print(f"Firewall politikalarını alırken hata oluştu: {e}")
        return None

def find_vm_related_to_vlan():
    for env in fortigate_envs:
        api_url = env['url']
        access_token = env['access_token']
        print(f"\nOrtam: {api_url}")
        print("=" * 50)

        # 1. VLAN bilgilerini al
        vlan_data = get_vlans(api_url, access_token)

        if vlan_data:
            for vlan in vlan_data:
                if vlan.get('type') == 'vlan':
                    vlan_id = vlan.get('vlanid', 'N/A')
                    interface_name = vlan.get('name', 'N/A')
                    print(f"VLAN ID: {vlan_id}, Arayüz: {interface_name}")

                    # 2. VLAN arayüzüne göre firewall politikalarını al
                    policies = get_firewall_policies(api_url, access_token, interface_name)

                    if policies:
                        for policy in policies:
                            print(f"Firewall Politikası: {policy.get('name')}")
                            print(f"Kaynak Arayüz: {policy.get('srcintf')}")
                            print(f"Hedef Arayüz: {policy.get('dstintf')}")
                            print(f"Servis: {policy.get('service')}")
                            print("-" * 50)

if __name__ == "__main__":
    find_vm_related_to_vlan()
