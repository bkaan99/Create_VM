import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
fortigate_info = {
    'url': 'https://10.14.26.1',
    'access_token': 'Hmw4690wsGm75pNg7m3g4ydmq6Np34'
}

def get_ssl_vpn_info(api_url, access_token):
    try:
        headers = {"Authorization": f"Bearer {access_token}"}
        print("Fetching SSL VPN information...")
        response = requests.get(f"{api_url}/api/v2/monitor/vpn/ssl", headers=headers, verify=False)

        if response.status_code == 200:
            print(f"SSL VPN information retrieved successfully.")
            return response.json()
        else:
            print(f"Error fetching SSL VPN information: {response.status_code}")
            return None
    except Exception as e:
        print(f"An error occurred while getting SSL VPN information: {e}")
        return None

def print_ssl_vpn_info(ssl_vpn_data):
    if not ssl_vpn_data:
        print("No SSL VPN data available.")
        return

    print("SSL VPN Information:")
    ssl_vpn_list = []

    for vpn in ssl_vpn_data.get('results', []):
        for subsession in vpn.get('subsessions', []):
            vpn_info = {
                'User': vpn.get('user_name', 'N/A'),
                'Source IP': vpn.get('remote_host', 'N/A'),
                'Destination IP': subsession.get('aip', 'N/A'),
                'Bytes In': subsession.get('in_bytes', 'N/A'),
                'Bytes Out': subsession.get('out_bytes', 'N/A'),
                'Duration': vpn.get('duration', 'N/A')
            }
            ssl_vpn_list.append(vpn_info)

    for vpn in ssl_vpn_list:
        print(f"User: {vpn['User']}, Source IP: {vpn['Source IP']}, "
              f"Destination IP: {vpn['Destination IP']}, Bytes In: {vpn['Bytes In']}, "
              f"Bytes Out: {vpn['Bytes Out']}, Duration: {vpn['Duration']} seconds")

    return ssl_vpn_list

def main_controller():
    try:
        config = fortigate_info
        ssl_vpn_data = get_ssl_vpn_info(config['url'], config['access_token'])

        if ssl_vpn_data:
            ssl_vpn_list = print_ssl_vpn_info(ssl_vpn_data)

    except Exception as e:
        print(f"An unexpected error occurred in main_controller: {e}")

if __name__ == "__main__":
    main_controller()
