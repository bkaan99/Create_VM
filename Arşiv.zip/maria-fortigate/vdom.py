import requests
import urllib3
import configparser
import json

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
fortigate_info = {
    'url': 'https://10.14.26.1',
    'access_token': 'Hmw4690wsGm75pNg7m3g4ydmq6Np34'
}

def get_vdoms(api_url, access_token):
    try:
        headers = {"Authorization": f"Bearer {access_token}"}

        response = requests.get(f"{api_url}/api/v2/cmdb/system/vdom/", headers=headers, verify=False)

        if response.status_code == 200:
            print(f"VDOMs retrieved successfully.")
            return response.json()['results']
        else:
            print(f"Error fetching VDOMs: {response.status_code}")
            return None
    except Exception as e:
        print(f"An error occurred while getting VDOMs: {e}")
        return None

def main_controller():
    try:
        config = fortigate_info
        vdom_data = get_vdoms(config['url'], config['access_token'])
        if vdom_data:
            print(f"\nToplam VDOM sayısı: {len(vdom_data)}")
            for vdom in vdom_data:
                print(f"Name: {vdom.get('name', 'N/A')}")

    except Exception as e:
        print(f"An unexpected error occurred in main_controller: {e}")


if __name__ == "__main__":
    main_controller()
