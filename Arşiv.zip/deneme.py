import time
import pydevd_pycharm  # PyCharm Remote Debugging kütüphanesi

# PyCharm Debug Server'a bağlan
pydevd_pycharm.settrace(
    '10.100.10.13',  # **PyCharm yüklü bilgisayarınızın IP adresi**
    port=12345,      # PyCharm Debug Server için belirlediğiniz port
    stdoutToServer=True,  # Konsol çıktısını PyCharm'a gönder
    stderrToServer=True,  # Hata çıktısını PyCharm'a gönder
    suspend=True           # Kodun PyCharm'da durmasını sağlar
)

# Basit bir işlem: Sayıları artır
for i in range(10):
    print(f"Current number: {i}")  # Buraya breakpoint koyabilirsiniz
    time.sleep(1)
