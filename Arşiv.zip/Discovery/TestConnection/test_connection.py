from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[2]))
import ssl
import socket
import sys
import base64
import json
import os
from pyVim import connect
from proxmoxer import ProxmoxAPI
import requests
from requests.auth import HTTPBasicAuth
from Discovery.utils.LogProcess import LogProcess

def test_vmware(host: str, user: str, password: str, timeout=10):
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE

    try:
        socket.create_connection((host, 443), timeout=timeout)
        service_instance = connect.SmartConnect(host=host,
                                                user=user,
                                                pwd=password,
                                                sslContext=ssl_context)

        print(f"vCenter sunucusuna bağlanıldı: {host}")
        print("Test connection successfully..")

    except Exception as e:
        print(f"{host} sunucusuna bağlanırken hata oluştu: {e}")

def test_proxmox(host: str, user: str, token_name: str, token_value: str, timeout=10):
    try:
        proxmox = ProxmoxAPI(host, user=user,
                             token_name=token_name,
                             token_value=token_value,
                             verify_ssl=False)

        if proxmox:
            print(f"Proxmox sunucusuna bağlanıldı: {host}")
            print("Test connection successfully..")
    except Exception as e:
        print(f"{host} sunucusuna bağlanırken hata oluştu: {e}")

def test_rapid7(base_url: str, username: str, password: str, port):
    test_url = f"https://{base_url}:{port}/api/3/sites"
    print(f"Bağlantıyı test etmek için istek yapılıyor: {test_url}")
    try:
        response = requests.get(
            test_url,
            auth=HTTPBasicAuth(username, password),
            verify=False,  # SSL doğrulama kapalı
            timeout=10     # 10 saniyelik zaman aşımı
        )
        if response.status_code == 200:
            print("Bağlantı başarılı!")
            print("Test connection successfully..")
        else:
            print(f"Bağlantı testi başarısız: {response.status_code} - {response.text}")
    except requests.exceptions.Timeout:
        print("Bağlantı testi sırasında zaman aşımı oldu.")
    except Exception as e:
        print(f"Bağlantı testi sırasında bir hata oluştu: {e}")

def test_sophos(base_url, client_id, client_secret):
    print("Sophos bağlantısı test ediliyor..")
    url = f'https://{base_url}/api/v2/oauth2/token'
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded'
    }
    data = {
        'grant_type': 'client_credentials',
        'client_id': client_id,
        'client_secret': client_secret,
        'scope': 'token'
    }

    response = requests.post(url, headers=headers, data=data)
    if response.status_code == 200:
        print("Sophos bağlantısı başarılı!")
        print("Test connection successfully..")
    else:
        print(f"Sophos bağlantısı başarısız: {response.status_code} - {response.text}")

def test_fortigate(access_token, url, port):
    try:
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.get(f"https://{url}:{port}/api/v2/cmdb/system/interface", headers=headers, verify=False)
        if response.status_code == 200:
            print("Fortigate bağlantısı başarılı!")
            print("Test connection successfully..")

    except Exception as e:
        print(f"Fortigate bağlantısı sırasında bir hata oluştu: {e}")

def test_citrix(base_url, username, password):
    HEADERS = {
        "Content-Type": "application/json"
    }

    url = f"https://{base_url}/vlan"
    try:
        response = requests.get(url, headers=HEADERS, auth=(username, password), verify=False)
        if response.status_code == 200:
            print("Test connection successfully..")
        else:
            print(f"Citrix bağlantısı başarısız: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"Citrix bağlantısı sırasında bir hata oluştu: {e}")

def process_request(encoded_json):
    try:
        # Base64 kodlu JSON'u çöz
        decoded_data = base64.b64decode(encoded_json).decode('utf-8')
        request_data = json.loads(decoded_data)

        # Gerekli alanları al
        environment = request_data.get("environment")
        endpoint = request_data.get("endpoint")
        parameters = {param["name"]: param["value"] for param in request_data.get("parameters", [])}

        # Environment'e göre yönlendirme yap
        if environment == "VMWARE":
            return test_vmware(endpoint, parameters.get("username"), parameters.get("password"))
        elif environment == "PROXMOX":
            return test_proxmox(endpoint, parameters.get("username"),
                                parameters.get("tokenName"), parameters.get("tokenValue"))
        elif environment == "RAPID7":
            return test_rapid7(endpoint, parameters.get("username"), parameters.get("password"), parameters.get("port"))
        elif environment == "SOPHOS":
            return test_sophos(endpoint, parameters.get("clientId"), parameters.get("clientSecret"))
        elif environment == "FORTIGATE":
            return test_fortigate(parameters.get("accessToken"), endpoint, parameters.get("port"))
        elif environment == "CITRIX":
            return test_citrix(f"{endpoint}", parameters.get("username"), parameters.get("password"))
        else:
            print("Desteklenmeyen environment türü:", environment)

    except Exception as e:
        print(f"Hata oluştu: {e}")

def get_sys_argvs():
    #sys arg 1 varsa return et yoksa yok de kapat
    if len(sys.argv) > 1:
        return sys.argv[1]
    else:
        print("Parametre bulunamadı.")
        sys.exit(1)

if __name__ == "__main__":
    LogProcess.create_logger_settings(log_prefix=os.path.basename(__file__).split(".")[0],
                                      script_dir=os.path.dirname(os.path.realpath(__file__)))
    encoded_json = get_sys_argvs()
    process_request(encoded_json)
    print("İşlem tamamlandı.")