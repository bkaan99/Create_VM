from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[2]))
import base64
import concurrent.futures
import logging
import os
from enum import Enum
from proxmoxer import ProxmoxAPI
import datetime
import pandas as pd
from sqlalchemy import text
import urllib3
from Discovery.utils.PostgresConnection import PostgresConnection
from Discovery.utils.LogProcess import LogProcess

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

proxmox_creds = {
    "equinix-proxmox": {
        "datacenter": "EQX",
        "usage_location": "Public",
        "product_type" : "PROXMOX",
        "host": "10.195.34.111",
        "user": "P9988.marvin.android@pam",
        "token_name": "P9988.marvin.android",
        "token_value": "14b04750-a4d3-4dd9-bb5b-86671cc3f94c",
        "verify_ssl": False
    },
    "equinix-fi-proxmox": {
        "datacenter": "EQX",
        "usage_location": "FI Cloud",
        "product_type" : "PROXMOX",
        "host": "10.100.7.13",
        "user": "P9988.marvin.android@pam",
        "token_name": "P9988.marvin.android",
        "token_value": "aed49721-5d9c-4998-aa6b-807e1ae4b145",
        "verify_ssl": False
    },
    "turksat-fi-proxmox": {
        "datacenter": "TURKSAT",
        "usage_location": "FI Cloud",
        "product_type" : "PROXMOX",
        "host": "10.0.150.13",
        "user": "P9988.marvin.android@pam",
        "token_name": "P9988.marvin.android",
        "token_value": "bdcb0cad-5d59-4e13-bbcc-c29a73438338",
        "verify_ssl": False
    },
    "kkb-proxmox": {
        "datacenter": "KKB",
        "usage_location": "Public",
        "product_type" : "PROXMOX",
        "host": "172.30.4.100",
        "user": "P9988.marvin.android@pam",
        "token_name": "P9988.marvin.android",
        "token_value": "766d05e2-b44a-44e8-b930-5bb7cdd1874a",
        "verify_ssl": False
    }
}

class VMInfo:
    class GuestFamily(Enum):
        WINDOWS = "Windows"
        MACOS = "Mac OS"
        LINUX = "Linux"
        OTHER = "Other"

    windows_keywords = [
        "Microsoft MS-DOS",
        "Microsoft Small Business Server 2003",
        "Microsoft Windows 10",
        "Microsoft Windows 10 (64-bit)",
        "Microsoft Windows 7 (32-bit)",
        "Microsoft Windows 7 (64-bit)",
        "Microsoft Windows 8 (64-bit)",
        "Microsoft Windows Server 2003 (32-bit)",
        "Microsoft Windows Server 2003 Standard (32-bit)",
        "Microsoft Windows Server 2003 Standard (64-bit)",
        "Microsoft Windows Server 2008 (32-bit)",
        "Microsoft Windows Server 2008 (64-bit)",
        "Microsoft Windows Server 2008 R2",
        "Microsoft Windows Server 2008 R2 (64-bit)",
        "Microsoft Windows Server 2012",
        "Microsoft Windows Server 2012 (64-bit)",
        "Microsoft Windows Server 2012 R2",
        "Microsoft Windows Server 2016",
        "Microsoft Windows Server 2016 (64-bit)",
        "Microsoft Windows Server 2019",
        "Microsoft Windows Server 2019 (64-bit)",
        "Microsoft Windows Server 2022",
        "Microsoft Windows Server 2022 (64-bit)",
        "Microsoft Windows XP Professional (32-bit)"
    ]

    other_keywords = [
        "FreeBSD (64-bit)",
        "FreeBSD 11",
        "FreeBSD 12",
        "FreeBSD 13",
        "FreeBSD Pre-11",
        "IBM OS/2",
        "Novell NetWare 5.1",
        "Novell NetWare 6.x",
        "Oracle Solaris 10",
        "Oracle Solaris 11",
        "Other",
        "SCO OpenServer 5",
        "SCO OpenServer 6",
        "SCO UnixWare 7",
        "Serenity Systems eComStation 1",
        "Serenity Systems eComStation 2",
        "Sun Microsystems Solaris 8",
        "Sun Microsystems Solaris 9",
        "VMware ESX 4.x",
        "VMware ESXi 5.x",
        "VMware ESXi 6.0",
        "VMware ESXi 6.x",
        "VMware ESXi 7.0",
        "VMware ESXi 6.5 or later"
    ]

    macos_keywords = [
        "Apple Mac OS X 10.10",
        "Apple Mac OS X 10.11",
        "Apple Mac OS X 10.5",
        "Apple Mac OS X 10.6",
        "Apple Mac OS X 10.7",
        "Apple Mac OS X 10.8",
        "Apple Mac OS X 10.9",
        "Apple macOS 10.12",
        "Apple macOS 10.13",
        "Apple macOS 10.14",
        "Apple macOS 10.15",
        "Apple macOS 11",
        "Apple macOS 12"
    ]

    linux_keywords = [
        "Amazon Linux 2",
        "Amazon Linux 3",
        "AlmaLinux 8.10 (Cerulean Leopard)",
        "CentOS 4/5 (64-bit)",
        "CentOS 4/5/6 (64-bit)",
        "CentOS 4/5/6/7 (64-bit)",
        "CentOS 6 (64-bit)",
        "CentOS 7 (64-bit)",
        "CentOS 8 (64-bit)",
        "CentOS Linux 7 (Core)",
        "CentOS Linux 8",
        "CentOS Stream 8",
        "CentOS Stream 9",
        "Debian GNU/Linux 10 (64-bit)",
        "Debian GNU/Linux 10 (buster)",
        "Debian GNU/Linux 11 (64-bit)",
        "Debian GNU/Linux 11 (bullseye)",
        "Debian GNU/Linux 4 (64-bit)",
        "Debian GNU/Linux 6 (64-bit)",
        "Debian GNU/Linux 8 (64-bit)",
        "Debian GNU/Linux trixie/sid",
        "Other Linux (64-bit)",
        "Other 2.6.x Linux (32-bit)",
        "Other 2.6.x Linux (64-bit)",
        "Other 3.x or later Linux (64-bit)",
        "Other 4.x Linux (64-bit)",
        "Other 4.x or later Linux (64-bit)",
        "Other 5.x or later Linux (64-bit)",
        "Oracle Linux 7 (64-bit)",
        "Oracle Linux 8 (64-bit)",
        "Oracle Linux Server 8.10",
        "Oracle Linux Server 8.8",
        "Oracle Linux Server 9.4",
        "Red Hat Enterprise Linux 5 (64-bit)",
        "Red Hat Enterprise Linux 6 (64-bit)",
        "Red Hat Enterprise Linux 7 (64-bit)",
        "Red Hat Enterprise Linux 8 (64-bit)",
        "Red Hat Enterprise Linux 8.4 (Ootpa)",
        "Red Hat Enterprise Linux 8.5 (Ootpa)",
        "Red Hat Enterprise Linux 8.6 (Ootpa)",
        "Red Hat Enterprise Linux 8.7 (Ootpa)",
        "Red Hat Enterprise Linux 8.8 (Ootpa)",
        "Red Hat Enterprise Linux 8.9 (Ootpa)",
        "Rocky Linux 8.10 (Green Obsidian)",
        "Rocky Linux 8.8 (Green Obsidian)",
        "Rocky Linux 8.9 (Green Obsidian)",
        "Rocky Linux 9.1 (Blue Onyx)",
        "Rocky Linux 9.2 (Blue Onyx)",
        "Rocky Linux 9.3 (Blue Onyx)",
        "Rocky Linux 9.4 (Blue Onyx)",
        "SUSE Linux Enterprise 10 (32-bit)",
        "SUSE Linux Enterprise 11 (64-bit)",
        "SUSE Linux Enterprise 12 (64-bit)",
        "SUSE Linux Enterprise 15 (64-bit)",
        "SUSE Linux Enterprise Server 12 SP4",
        "SUSE Linux Enterprise Server 15",
        "SUSE Linux Enterprise Server 15 SP1",
        "SUSE Linux Enterprise Server 15 SP2",
        "SUSE Linux Enterprise Server 15 SP3",
        "SUSE Linux Enterprise Server 15 SP4",
        "SUSE Linux Enterprise Server 15 SP5",
        "Ubuntu 18.04.6 LTS",
        "Ubuntu 20.04 LTS",
        "Ubuntu 22.04.1 LTS",
        "Ubuntu 22.04.2 LTS",
        "Ubuntu 20.04.3 LTS",
        "Ubuntu 20.04.4 LTS",
        "Ubuntu 20.04.5 LTS",
        "Ubuntu 20.04.6 LTS",
        "Ubuntu 22.04.2 LTS",
        "Ubuntu 22.04.3 LTS",
        "Ubuntu 22.04.4 LTS",
        "Ubuntu 22.04.5 LTS",
        "Ubuntu 23.04",
        "Ubuntu 24.04 LTS",
        "Ubuntu Linux (32-bit)",
        "Ubuntu Linux (64-bit)"
    ]

    os_types = {
        'other': GuestFamily.OTHER,  # Unspecified OS
        'wxp': GuestFamily.WINDOWS,  # Microsoft Windows XP
        'w2k': GuestFamily.WINDOWS,  # Microsoft Windows 2000
        'w2k3': GuestFamily.WINDOWS,  # Microsoft Windows 2003
        'w2k8': GuestFamily.WINDOWS,  # Microsoft Windows 2008
        'wvista': GuestFamily.WINDOWS,  # Microsoft Windows Vista
        'win7': GuestFamily.WINDOWS,  # Microsoft Windows 7
        'win8': GuestFamily.WINDOWS,  # Microsoft Windows 8/2012/2012r2
        'win10': GuestFamily.WINDOWS,  # Microsoft Windows 10/2016/2019
        'win11': GuestFamily.WINDOWS,  # Microsoft Windows 11/2022/2025
        'l24': GuestFamily.LINUX,  # Linux 2.4 Kernel
        'l26': GuestFamily.LINUX,  # Linux 2.6 - 6.X Kernel
        'solaris': GuestFamily.LINUX,  # Solaris/OpenSolaris/OpenIndiania Kernel

        # Eklenen diğer işletim sistemleri
        'freebsd': GuestFamily.LINUX,  # FreeBSD
        'ubuntu': GuestFamily.LINUX,  # Ubuntu
        'ubuntu20': GuestFamily.LINUX,  # Ubuntu 20.04
        'ubuntu22': GuestFamily.LINUX,  # Ubuntu 22.04
        'centos': GuestFamily.LINUX,  # CentOS
        'centos8': GuestFamily.LINUX,  # CentOS 8
        'centos7': GuestFamily.LINUX,  # CentOS 7
        'debian': GuestFamily.LINUX,  # Debian
        'debian10': GuestFamily.LINUX,  # Debian 10
        'debian11': GuestFamily.LINUX,  # Debian 11
        'oracle_linux': GuestFamily.LINUX,  # Oracle Linux
        'oracle_linux8': GuestFamily.LINUX,  # Oracle Linux 8
        'suse': GuestFamily.LINUX,  # SUSE Linux
        'suse12': GuestFamily.LINUX,  # SUSE Linux Enterprise 12
        'suse15': GuestFamily.LINUX,  # SUSE Linux Enterprise 15
        'redhat': GuestFamily.LINUX,  # Red Hat Enterprise Linux
        'redhat8': GuestFamily.LINUX,  # Red Hat Enterprise Linux 8
        'rocky_linux': GuestFamily.LINUX,  # Rocky Linux
        'rocky_linux9': GuestFamily.LINUX,  # Rocky Linux 9
        'almalinux': GuestFamily.LINUX,  # AlmaLinux
        'almalinux8': GuestFamily.LINUX,  # AlmaLinux 8
        'opensolaris': GuestFamily.LINUX,  # OpenSolaris
        'windows_server_2012': GuestFamily.WINDOWS,  # Windows Server 2012
        'windows_server_2016': GuestFamily.WINDOWS,  # Windows Server 2016
        'windows_server_2019': GuestFamily.WINDOWS,  # Windows Server 2019
        'windows_server_2022': GuestFamily.WINDOWS,  # Windows Server 2022
        'macos': GuestFamily.MACOS,  # Mac OS
        'macos_mojave': GuestFamily.MACOS,  # Mac OS Mojave
        'macos_catalina': GuestFamily.MACOS,  # Mac OS Catalina
        'macos_bigsur': GuestFamily.MACOS,  # Mac OS Big Sur
        'macos_monterey': GuestFamily.MACOS,  # Mac OS Monterey
        'macos_ventura': GuestFamily.MACOS,  # Mac OS Ventura
        'fedora': GuestFamily.LINUX,  # Fedora
        'gentoo': GuestFamily.LINUX,  # Gentoo
        'archlinux': GuestFamily.LINUX,  # Arch Linux
        'slackware': GuestFamily.LINUX,  # Slackware
        'mandriva': GuestFamily.LINUX,  # Mandriva
        'opensuse': GuestFamily.LINUX,  # openSUSE
        'elementary_os': GuestFamily.LINUX,  # Elementary OS
        'zorin_os': GuestFamily.LINUX,  # Zorin OS
        'pclinuxos': GuestFamily.LINUX,  # PCLinuxOS
        'raspbian': GuestFamily.LINUX,  # Raspbian
        'linspire': GuestFamily.LINUX,  # Linspire
        'ubuntu_mate': GuestFamily.LINUX,  # Ubuntu MATE
        'ubuntu_studio': GuestFamily.LINUX,  # Ubuntu Studio
        'kubuntu': GuestFamily.LINUX,  # Kubuntu
        'xubuntu': GuestFamily.LINUX,  # Xubuntu
        'clearlinux': GuestFamily.LINUX,  # Clear Linux
        'pop_os': GuestFamily.LINUX,  # Pop!_OS
        'deepin': GuestFamily.LINUX,  # Deepin
        'manjaro': GuestFamily.LINUX,  # Manjaro
        'nixos': GuestFamily.LINUX,  # NixOS
        'void_linux': GuestFamily.LINUX,  # Void Linux
        'sabayon': GuestFamily.LINUX,  # Sabayon
        'altlinux': GuestFamily.LINUX,  # ALT Linux
        'exherbo': GuestFamily.LINUX,  # Exherbo
        'bunsenlabs': GuestFamily.LINUX,  # BunsenLabs
        'artix_linux': GuestFamily.LINUX,  # Artix Linux
    }

    @classmethod
    def find_guest_family(cls, os_version_name):
        os_version_lower = os_version_name.lower()

        # Check for Windows keywords
        if any(keyword.lower() in os_version_lower for keyword in cls.windows_keywords):
            return cls.GuestFamily.WINDOWS

        # Check for macOS keywords
        if any(keyword.lower() in os_version_lower for keyword in cls.macos_keywords):
            return cls.GuestFamily.MACOS

        # Check for Linux keywords
        if any(keyword.lower() in os_version_lower for keyword in cls.linux_keywords):
            return cls.GuestFamily.LINUX

        # If none of the keywords match, check for other keywords
        if any(keyword.lower() in os_version_lower for keyword in cls.other_keywords):
            return cls.GuestFamily.OTHER

        if os_version_lower in cls.os_types:
            return cls.os_types[os_version_name]

        return cls.GuestFamily.OTHER
class ProxmoxEventCategory(Enum):
    START_AND_STOP = [
        "qmstart",  # VM başlatma
        "qmstop",   # VM durdurma
    ]
    CAPACITY_AND_CONFIGURATION = [
        "qmconfig",  # Kapasite ve konfigürasyon değişiklikleri
    ]
    REBOOT = [
        "qmreboot",  # Reboot
    ]
    CREATION_AND_DELETION = [
        "qmcreate",  # VM yaratma
        "qmdelete",  # VM silme
    ]
    BACKUP_AND_RESTORE = [
        "qmbackup",  # Yedekleme
        "qmrestore",  # Geri yükleme
    ]
    SOFTWARE_AND_PATCH_MANAGEMENT = [
        "qmupdate",  # Yazılım güncelleme
    ]

    @classmethod
    def get_event_category(cls, event_type):
        for category in cls:
            if event_type in category.value:
                return category.name
        return "UNKNOWN"

def login_proxmox(proxmox_creds):
    for proxmox_env, proxmox_cred in proxmox_creds.items():
        try:
            proxmox = ProxmoxAPI(proxmox_cred["host"], user=proxmox_cred["user"],
                                 token_name=proxmox_cred["token_name"],
                                 token_value=proxmox_cred["token_value"],
                                 verify_ssl=proxmox_cred["verify_ssl"])

            if proxmox:
                print(f"{proxmox_env} - Login successful ----->>>>>>")
                logging.info(f"{proxmox_env} - Login successful")
                all_vm_count = get_all_vm_count(proxmox)
                print(f"{proxmox_env} - Total VM Count: {all_vm_count}")
                logging.info(f"{proxmox_env} - Total VM Count: {all_vm_count}")
                get_vm_info(proxmox, proxmox_env, proxmox_cred["host"], proxmox_cred["datacenter"], proxmox_cred["usage_location"], proxmox_cred["product_type"])
                print("")

        except Exception as e:
            print(f"{proxmox_env} - Error: {e}")
            logging.error(f"{proxmox_env} - Error: {e}")

def get_all_vm_count(proxmox):
    all_vm_count = 0
    nodes = proxmox.nodes.get()

    for node in nodes:
        node_name = node['node']
        # Her node üzerindeki VM'leri al
        vms = proxmox.nodes(node_name).qemu.get()
        all_vm_count += len(vms)

    return all_vm_count

def get_vm_ip(proxmox, vmid, node_name, agent):
    if agent == 1:
        address_list = []
        try:
            # VM'nin ağ bilgilerini almak için guest-agent kullanıyoruz
            network_info = proxmox.nodes(node_name).qemu(vmid).agent("network-get-interfaces").get()

            # Network arayüzlerinde dolaşarak IP bilgilerini alıyoruz
            for interface in network_info['result']:
                if 'hardware-address' in interface and interface['hardware-address'].startswith("00:00:00"):
                    continue
                if 'ip-addresses' in interface:
                    for ip_info in interface['ip-addresses']:
                        if ip_info['ip-address-type'] == 'ipv4':
                            address_list.append(ip_info['ip-address'])
                            return address_list
            return "N/A"
        except Exception as e:
            error_message = str(e)
            if "VM is not running" in error_message:
                return f"VM {vmid} is not running"
            elif "QEMU guest agent is not running" in error_message:
                return f"QEMU guest agent is not running for VM {vmid}"
            else:
                return f"Error fetching IP for VM {vmid}: {error_message}"
    else:
        return "N/A"

def get_vm_resource_pool(proxmox, vmid):
    try:
        # Tüm pool'ları getir
        pools = proxmox.pools.get()

        # Pool'larda dolaş ve ilgili VM'yi bul
        for pool in pools:
            x = proxmox.pools.get(pool['poolid'])
            for vm in x['members']:
                if vm['vmid'] == vmid:
                    return pool['poolid']
        return 'Unknown'

    except Exception as e:
        return 'Unknown'

def get_disk_count_from_config(vm_config):
    try:
        disk_count = 0
        # Konfigürasyon anahtarları üzerinde döngü
        for key, value in vm_config.items():
            # Değerin bir string olup olmadığını kontrol et
            if isinstance(value, str) and 'disk' in value.lower():
                disk_count += 1
        return disk_count

    except Exception as e:
        return 'Unknown'

def get_vm_guest_version(proxmox, vmid, node_name, agent, vm_config_os_type):
    if vm_config_os_type is None:
        vm_config_os_type = "Unknown"

    if agent == 1:
        try:
            guest_info = proxmox.nodes(node_name).qemu(vmid).agent('get-osinfo').get()
            #guest_os = guest_info.get('name', 'Unknown')
            os_name = guest_info['result'].get('name', 'Unknown')

            if 'windows' not in os_name.lower():
                guest_version = guest_info['result'].get('pretty-name', 'Unknown version')
            else:
                guest_version = guest_info['result'].get('version', 'Unknown version')

            if guest_version != 'Unknown version' or 'Unknown':
                return guest_version
            else:
                return vm_config_os_type

        except Exception as e:
            return vm_config_os_type
    else:
        return vm_config_os_type

def get_vlan_id(vm_config):
    vlan_id = None
    try:
        for key, value in vm_config.items():
            if key.startswith('net'):
                # Örnek: net0: virtio=52:54:00:1b:3b:8b,bridge=vmbr1264,firewall=1
                if 'bridge' in value:
                    vlan_id = value.split(",")[1].split("bridge=")[1].replace("vmbr", "")
                    return vlan_id

    except Exception as e:
        vlan_id = 'N/A'

    return "N/A" if vlan_id is None else vlan_id

def get_proxmox_vm_disks(vmid, uuid, vm_config):
    try:
        sum_disk_size = 0.0
        # VM'in diskleri 'virtio' ya da 'scsi' olarak adlandırılabilir.
        disk_prefixes = ['virtio']

        def convert_to_gb(size_str):
            size, unit = float(size_str[:-1]), size_str[-1].upper()
            if unit == 'T':  # Terabytes to Gigabytes
                return size * 1024
            elif unit == 'M':  # Megabytes to Gigabytes
                return size / 1024
            else:  # Default case is Gigabytes
                return size

        for prefix in disk_prefixes:
            for key, value in vm_config.items():
                if key.startswith(prefix):
                    # Disk yapılandırması ör: "HW03EQCLOUDDS21:159/vm-159-disk-0.qcow2,size=1259G"
                    disk_config = value.split(",")[0]  # "HW03EQCLOUDDS21:159/vm-159-disk-0.qcow2"
                    datastore = disk_config.split(":")[0]  # Datastore adı: "HW03EQCLOUDDS21"
                    disk_unique_id = disk_config.split(":")[1] # "159/vm-159-disk-0.qcow2"

                    #size_str = value.split("size=")[-1].replace("G", "")  # "1259"
                    # Extract size and unit
                    size_str = value.split("size=")[-1]  # "1259G" or "500M", etc.
                    disk_size_gb = convert_to_gb(size_str)

                    sum_disk_size += float(disk_size_gb)

                    disk_provisioning = "thin" if "discard" in value else "thick"

                    disk_info = {
                        "uuid": uuid,
                        "disksize": float(disk_size_gb),  # GB cinsinden
                        "diskprovisioning": disk_provisioning,
                        "location": datastore,
                        "version": "1",
                        "sharedvalue": "-",
                        "limitiops": "-",
                        "createdate": datetime.datetime.now(),
                        "is_deleted": False,
                        "diskobjectid": uuid + "///" + disk_unique_id
                    }

                    disk_list.append(disk_info)

        return sum_disk_size

    except Exception as e:
        print(f"Error fetching disk info for VM {vmid}: {e}")
        return 0.0

def product_usage_calculator_for_kvm(vm_info, sum_disk_size, vm_ip):
    # VM'in online/offline durumunu al
    onlineOfflineStatus = vm_info['status']
    if onlineOfflineStatus == 'running':
        onlineOfflineStatus = True
    else:
        onlineOfflineStatus = False

    # Product Usage Section
    vCPU = float(0)
    vramsizegb = float(0)
    vdisk = float(0)
    Draas = float(0)

    ramsizegbvalue = round(vm_info['maxmem'] / 1024 / 1024 / 1024 ,2)

    #TODO: product usage daki rpa satırı eklenmemişti onlar eklenecekler.

    if onlineOfflineStatus:
        if vm_ip and (vm_info['name'].endswith(".copy") or vm_info['name'].endswith(".c0py24")):
            vCPU = vm_info['cpus'] if vm_info['cpus'] else '0'
            vramsizegb = ramsizegbvalue if vm_info['maxmem'] else '0'
            vdisk = sum_disk_size
        elif ("sil" in vm_info['name'] or "s1l24" in vm_info['name']) and not ("silme" in vm_info['name'] or "s1lme324" in vm_info['name']):
            pass
        else:
            vCPU = vm_info['cpus'] if vm_info['cpus'] else '0'
            vramsizegb = ramsizegbvalue if vm_info['maxmem'] else '0'
            vdisk = sum_disk_size

    elif not onlineOfflineStatus:
        if vm_ip and (vm_info['name'].endswith(".copy") or vm_info['name'].endswith(".c0py24")):
            vdisk = sum_disk_size
        elif ("sil" in vm_info['name'] or "s1l24" in vm_info['name']) and not ("silme" in vm_info['name'] or "s1lme324" in vm_info['name']):
            pass
        else:
            vdisk = sum_disk_size

    return vCPU, vramsizegb, vdisk, Draas, onlineOfflineStatus

def fs_info_getter(proxmox, node_name, vmid, uuid, resource_pool, vm_name, agent):
    if agent == 1:
        try:
            fs_info = proxmox.nodes(node_name).qemu(vmid).agent.get('get-fsinfo')
        except Exception as e:
            print(f"Error fetching disk guest info for VM {vmid}: {e}")
            return

        if fs_info:
            for fs in fs_info['result']:
                total_bytes = fs.get('total-bytes', 0)  # 'total-bytes' mevcut değilse varsayılan değer olarak 0 atar
                used_bytes = fs.get('used-bytes', 0)  # Aynı şekilde 'used-bytes' kontrolü de eklenebilir

                guest_disk_info = {
                    "uuid": uuid,
                    "diskname": fs['mountpoint'] if fs.get('mountpoint') else 'N/A',
                    "disksizegb": round(total_bytes / 1024 / 1024 / 1024, 2) if total_bytes else 0,
                    "freediskgb": round((total_bytes - used_bytes) / 1024 / 1024 / 1024, 2) if total_bytes and used_bytes else 0,
                    "createdate": datetime.datetime.now(),
                    "is_deleted": False,
                    "hostname": node_name,
                    "occupacyrate": round(used_bytes / total_bytes * 100, 2) if total_bytes and used_bytes else 0,
                    "resourcepoolname": resource_pool,
                    "vmname": vm_name,
                    "version": "1",
                    "virtualizationtechnology": "Proxmox",
                }
                guest_disk_info_list.append(guest_disk_info)

def get_task_details(proxmox, node_name, upid):
    try:
        # Task log'larını al
        task_details = proxmox.nodes(node_name).tasks(upid).log.get()
        # task detail içerisindeki her öğenin t değerini alt alta bir araya getir ve bunları dön
        task_details = '\n'.join([item['t'] for item in task_details])
        return task_details
    except Exception as e:
        print(f"Error retrieving task details: {e}")
        return "N/A"

def event_handler(proxmox, vmid, node_name, vm_uuid, vm_name):
    try:
        events = proxmox.nodes(node_name).tasks.get(vmid=vmid, limit=100)
        relevant_types = {
            'qmstart', 'qmstop', 'qmconfig',
            'qmreboot', 'qmcreate', 'qmdelete',
            'qmbackup', 'qmrestore', 'qmupdate'
        }

        vm_borndate = None
        for event in events:
            event_type = event.get('type')
            if event_type not in relevant_types:
                continue

            if event_type in {'qmcreate', 'qmclone'}:
                vm_borndate = datetime.datetime.fromtimestamp(event.get('starttime'))

            description = get_task_details(proxmox, node_name, event['upid'])
            event_dict = {
                "uuid": vm_uuid,
                "createdate": datetime.datetime.now(),
                "is_deleted": False,
                "description": f"{event_type};{description}",
                "logdate": datetime.datetime.fromtimestamp(event.get('starttime')),
                "logsource": "Proxmox" + "-" + event.get('upid'),
                "logtype": ProxmoxEventCategory.get_event_category(event.get('type')),
                "vmname" : vm_name,
                "version": 1,
                "tasktype": event_type
            }
            event_dict_list.append(event_dict)

        return vm_borndate

    except Exception as e:
        print(f"Error fetching events for VM {vmid}: {e}")
        return None

def get_vm_info(proxmox, proxmox_env, host_ip, datacenter, usage_location, product_type):
    nodes = proxmox.nodes.get()
    #nodes = [node for node in nodes if node['node'] == 'ghcloudistkvm002']

    for node in nodes:
        node_name = node['node']
        print(f"Yeni Node için İşlemlere Başlandı ---->>>: {node_name}")
        vms = proxmox.nodes(node_name).qemu.get()
        total_vms = len(vms)  # Toplam VM sayısını al
        #vms = [vm for vm in vms if vm['name'] == 'SQL-PROD-01' or vm['name'] == 'OrhanHolding-ORAHRPRDA' or vm['name'] =='Likom-Gordionnewbie']

        # Use ThreadPoolExecutor to process VMs concurrently
        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = []
            for index, vm in enumerate(vms):
                futures.append(executor.submit(process_vm, vm, proxmox_env, host_ip, proxmox, node_name, index + 1, total_vms, datacenter, usage_location, product_type))

            # Optionally, wait for all futures to complete (if needed)
            concurrent.futures.wait(futures)

def process_vm(vm, proxmox_env, host_ip, proxmox, node_name, current_index, total_vms, datacenter, usage_location, product_type):
    try:
        vmid = vm['vmid']
        vm_info = proxmox.nodes(node_name).qemu(vmid).status.current.get()
        vm_config = proxmox.nodes(node_name).qemu(vmid).config.get()

        if vm_config.get('ostype'):
            vm_config_os_type = vm_config['ostype']
        else:
            vm_config_os_type = None

        print(f"    Processing VM {current_index}/{total_vms} with ID: {vmid}")
        print(f"    VM Name: {vm_info['name']} ")
        print("")
        uuid = proxmox_env + "-" + node_name + "-" + str(vmid)

        agent = 1 if vm_info.get('agent') == 1 else 0

        vm_ip = get_vm_ip(proxmox, vmid, node_name, agent)

        #event_handle
        vm_borndate = event_handler(proxmox, vmid, node_name, uuid, vm_info['name'])

        #VLan ID
        vlan_id = get_vlan_id(vm_config)

        # VM'in guest OS bilgileri
        guest_os_version = get_vm_guest_version(proxmox, vmid, node_name, agent, vm_config_os_type)

        # VM'in resource pool bilgisi
        resource_pool = get_vm_resource_pool(proxmox, vmid)

        # VM'in disk sayısı
        disk_count = get_disk_count_from_config(vm_config)

        #Toplam disk size ve disk bilgilerinin list eklenmesi işlemlerini içeririr.
        sum_disk_size = get_proxmox_vm_disks(vmid, uuid, vm_config)

        #List dönüyorsa burada birden çok ip adresi varsa bunun için  , ile birleştiriyorum.
        if isinstance(vm_ip, list):
            vm_ip = ', '.join(vm_ip)

        print("")

        #product usage section
        vCPU, vramsizegb, vdisk, Draas, onlineofflinestatus = product_usage_calculator_for_kvm(vm_info, sum_disk_size, vm_ip)

        #fs-info-getter
        fs_info_getter(proxmox, node_name, vmid, uuid, resource_pool, vm_info['name'], agent)

        vm_info_dict = {
            "vmname": vm_info['name'],
            "uuid": uuid,
            "bandwidth": "0.0", #TODO: Bandwidth bilgisi alınacak
            "onlineofflinestatus": onlineofflinestatus,
            "ipaddress": vm_ip,
            "hostname": node_name,
            "ramsizegb": vramsizegb,
            "cpu": vCPU,
            "operatingsystemversion": guest_os_version,
            "operatingsysteminformation": VMInfo.find_guest_family(guest_os_version).value,
            "createdate": datetime.datetime.now(),
            "resource_pool": resource_pool,
            "total_disk_number": str(disk_count),
            "virtualizationtechnology": "Proxmox",
            "environment": proxmox_env,
            "ip": host_ip,
            "is_deleted": False,
            "disksize": vdisk,
            "draassize": Draas,
            "version" : "1",
            "vlanid": vlan_id,
            "vmidgh": vmid,
            "vmcreatedate": vm_borndate,
            "datacentertype" : datacenter,
            "producttype" : product_type,
            "usagetype" : usage_location
        }

        vm_info_list.append(vm_info_dict)

    except Exception as e:
        print(f"Error fetching VM info for VM {vm['vmid']}: {e}")

def upsert_vm_info_to_dataframe_new(vm_info_list):
    vm_info_df = pd.DataFrame(vm_info_list)

    existing_uuids = pd.read_sql(f"""
            SELECT id, uuid 
            FROM {VM_LIST_TABLE_NAME}
            WHERE virtualizationtechnology = 'Proxmox'
        """, engineForPostgres)

    existing_uuid_set = set(existing_uuids['uuid'])

    to_update = vm_info_df[vm_info_df['uuid'].isin(existing_uuid_set)]
    to_insert = vm_info_df[~vm_info_df['uuid'].isin(existing_uuid_set)]

    id_map = existing_uuids.set_index('uuid')['id'].to_dict()
    to_update['id'] = to_update['uuid'].map(id_map)

    # Silme işlemi: Veritabanındaki ancak vm_info_df'de olmayan kayıtların is_deleted kolonunu True yap
    vm_uuid_set = set(vm_info_df['uuid'])
    uuids_to_soft_delete = existing_uuid_set - vm_uuid_set

    if not to_update.empty:
        # Güncelleme işlemi
        logging.info(f"kr_vm_list Tablosunda {to_update.shape[0]} adet kayıt güncelleniyor...")
        with engineForPostgres.connect() as connection:
            for _, row in to_update.iterrows():
                sql = text(f"""
                        UPDATE {VM_LIST_TABLE_NAME}
                        SET vmname = :vmname,
                            onlineofflinestatus = :onlineofflinestatus,
                            ipaddress = :ipaddress,
                            hostname = :hostname,
                            ramsizegb = :ramsizegb,
                            cpu = :cpu,
                            operatingsystemversion = :operatingsystemversion,
                            operatingsysteminformation = :operatingsysteminformation,
                            resource_pool = :resource_pool,
                            total_disk_number = :total_disk_number,
                            virtualizationtechnology = :virtualizationtechnology,
                            environment = :environment,
                            ip = :ip,
                            is_deleted = :is_deleted,
                            disksize = :disksize,
                            draassize = :draassize,
                            bandwidth = :bandwidth,
                            vlanid = :vlanid,
                            vmidgh = :vmidgh,
                            vmcreatedate = :vmcreatedate,
                            datacentertype = :datacentertype,
                            producttype = :producttype,
                            usagetype = :usagetype   
                        WHERE id = :id
                    """)

                vmcreatedate = row['vmcreatedate']
                if pd.notna(vmcreatedate):
                    vmcreatedate = vmcreatedate.strftime('%Y-%m-%d %H:%M:%S')
                else:
                    vmcreatedate = None

                connection.execute(sql, {
                    'vmname': row['vmname'],
                    'onlineofflinestatus': row['onlineofflinestatus'],
                    'ipaddress': row['ipaddress'],
                    'hostname': row['hostname'],
                    'ramsizegb': row['ramsizegb'],
                    'cpu': row['cpu'],
                    'operatingsystemversion': row['operatingsystemversion'],
                    'operatingsysteminformation': row['operatingsysteminformation'],
                    'resource_pool': row['resource_pool'],
                    'total_disk_number': row['total_disk_number'],
                    'virtualizationtechnology': row['virtualizationtechnology'],
                    'environment': row['environment'],
                    'ip': row['ip'],
                    'is_deleted': row['is_deleted'],
                    'id': row['id'],
                    'disksize': row['disksize'],
                    'draassize': row['draassize'],
                    'bandwidth': row['bandwidth'],
                    'vlanid': row['vlanid'],
                    'vmidgh': row['vmidgh'],
                    'vmcreatedate': vmcreatedate,
                    'datacentertype': row['datacentertype'],
                    'producttype': row['producttype'],
                    'usagetype': row['usagetype']
                })

            connection.commit()
            connection.close()
            logging.info(f"kr_vm_list Tablosunda {to_update.shape[0]} adet kayıt güncellendi.")

    if not to_insert.empty:
        logging.info(f"kr_vm_list Tablosuna {to_insert.shape[0]} adet yeni kayıt ekleniyor...")
        to_insert = to_insert.drop(columns=['id'], errors='ignore')
        to_insert.to_sql(VM_LIST_TABLE_NAME, engineForPostgres, chunksize=5000, index=False, if_exists='append')
        logging.info(f"kr_vm_list Tablosuna {to_insert.shape[0]} adet yeni kayıt eklendi.")

    if uuids_to_soft_delete:
        logging.info(f"kr_vm_list Tablosunda {len(uuids_to_soft_delete)} adet kayıt siliniyor...")
        with engineForPostgres.connect() as connection:
            update_sql = text(f"""
                UPDATE {VM_LIST_TABLE_NAME}
                SET is_deleted = True
                WHERE uuid = :uuid
            """)
            for uuid in uuids_to_soft_delete:
                connection.execute(update_sql, {'uuid': uuid})
            connection.commit()
            connection.close()
            logging.info(f"kr_vm_list Tablosunda {len(uuids_to_soft_delete)} adet kayıt silindi.")

def upsert_disk_info_to_dataframe(disk_info_list):
    TO_TABLE_NAME = "kr_vm_first_disk"

    disk_df = pd.DataFrame(disk_info_list)

    query = f"SELECT id, uuid FROM {VM_LIST_TABLE_NAME} WHERE virtualizationtechnology = 'Proxmox'"
    kr_vm_list_df = pd.read_sql(query, engineForPostgres)

    # disk_df içindeki UUID'yi, kr_vm_list içindeki id ile eşleştir
    disk_df['vmlist_id'] = disk_df['uuid'].apply(
        lambda x: kr_vm_list_df.loc[kr_vm_list_df['uuid'] == x, 'id'].values[0] if not kr_vm_list_df.loc[
            kr_vm_list_df['uuid'] == x, 'id'].empty else None)

    disk_df = disk_df.drop(columns=['uuid'])
    disk_df = disk_df.rename(columns={'id': 'vmlist_id'})

    # Mevcut kr_vm_first_disk tablosundaki vmlist_id'leri çek
    existing_disk_entries = pd.read_sql(f"SELECT diskobjectid FROM {TO_TABLE_NAME} WHERE sharedvalue = '-'", engineForPostgres)
    existing_disks_set = set(existing_disk_entries['diskobjectid'])

    to_update = disk_df[disk_df['diskobjectid'].isin(existing_disks_set)]
    to_insert = disk_df[~disk_df['diskobjectid'].isin(existing_disks_set)]

    to_soft_delete = existing_disks_set - set(disk_df['diskobjectid'])

    if not to_update.empty:
        with engineForPostgres.connect() as connection:
            for _, row in to_update.iterrows():
                sql = text(f"""
                        UPDATE {TO_TABLE_NAME}
                        SET diskprovisioning = :diskprovisioning,
                            disksize = :disksize,
                            location = :location,
                            sharedvalue = :sharedvalue,
                            version = :version,
                            limitiops = :limitiops,
                            createdate = :createdate,
                            is_deleted = :is_deleted,
                            diskobjectid = :diskobjectid
                        WHERE diskobjectid = :diskobjectid
                    """)

                connection.execute(sql, {
                    'diskprovisioning': row['diskprovisioning'],
                    'disksize': row['disksize'],
                    'location': row['location'],
                    'sharedvalue': row['sharedvalue'],
                    'version': row['version'],
                    'limitiops': row['limitiops'],
                    'createdate': row['createdate'],
                    'is_deleted': row['is_deleted'],
                    'vmlist_id': row['vmlist_id'],
                    'diskobjectid': row['diskobjectid']
                })

            connection.commit()
            connection.close()
            logging.info(f"kr_vm_first_disk Tablosunda {to_update.shape[0]} adet kayıt güncellendi.")

    if not to_insert.empty:
        to_insert.to_sql("kr_vm_first_disk", engineForPostgres, chunksize=5000, index=False, if_exists='append')
        logging.info(f"kr_vm_first_disk Tablosuna {to_insert.shape[0]} adet yeni kayıt eklendi.")

    if to_soft_delete:
        with engineForPostgres.connect() as connection:
            update_sql = text(f"""
                UPDATE {TO_TABLE_NAME}
                SET is_deleted = True
                WHERE diskobjectid = :diskobjectid
            """)
            for diskobjectid in to_soft_delete:
                connection.execute(update_sql, {'diskobjectid': diskobjectid})
            connection.commit()
            connection.close()
            logging.info(f"kr_vm_first_disk Tablosunda {len(to_soft_delete)} adet kayıt silindi.")

def upsert_guest_disk_info_to_dataframe(vm_guest_disk_detail_list):
    TO_TABLE_NAME = "kr_vm_warnings"
    guest_disk_info_df = pd.DataFrame(vm_guest_disk_detail_list)

    query = f"SELECT id, uuid FROM {VM_LIST_TABLE_NAME} WHERE virtualizationtechnology = 'Proxmox'"
    kr_vm_list_df = pd.read_sql(query, engineForPostgres)

    guest_disk_info_df['vmlist_id'] = guest_disk_info_df['uuid'].apply(
        lambda x: kr_vm_list_df.loc[kr_vm_list_df['uuid'] == x, 'id'].values[0] if not kr_vm_list_df.loc[
            kr_vm_list_df['uuid'] == x, 'id'].empty else None)

    guest_disk_info_df = guest_disk_info_df.drop(columns=['uuid'])
    guest_disk_info_df = guest_disk_info_df.rename(columns={'id': 'vmlist_id'})

    existing_guest_disk_entries = pd.read_sql(f"SELECT diskname, vmlist_id FROM {TO_TABLE_NAME} WHERE virtualizationtechnology = 'Proxmox'", engineForPostgres)
    existing_guest_disks_set = set(
        zip(existing_guest_disk_entries['diskname'], existing_guest_disk_entries['vmlist_id']))

    to_update = guest_disk_info_df[guest_disk_info_df.set_index(['diskname', 'vmlist_id']).index.isin(existing_guest_disks_set)]
    to_insert = guest_disk_info_df[~guest_disk_info_df.set_index(['diskname', 'vmlist_id']).index.isin(existing_guest_disks_set)]

    to_soft_delete = existing_guest_disks_set - set(zip(guest_disk_info_df['diskname'], guest_disk_info_df['vmlist_id']))

    if not to_update.empty:
        with engineForPostgres.connect() as connection:
            for _, row in to_update.iterrows():
                sql = text(f"""
                        UPDATE {TO_TABLE_NAME}
                        SET createdate = :createdate,
                            is_deleted = :is_deleted,
                            diskname = :diskname,
                            disksizegb = :disksizegb,
                            freediskgb = :freediskgb,
                            hostname = :hostname,
                            occupacyrate = :occupacyrate,
                            resourcepoolname = :resourcepoolname,
                            vmname = :vmname,
                            version = :version
                        WHERE vmlist_id = :vmlist_id AND diskname = :diskname
                    """)

                connection.execute(sql, {
                    'createdate': row['createdate'],
                    'is_deleted': row['is_deleted'],
                    'diskname': row['diskname'],
                    'disksizegb': row['disksizegb'],
                    'freediskgb': row['freediskgb'],
                    'hostname': row['hostname'],
                    'occupacyrate': row['occupacyrate'],
                    'resourcepoolname': row['resourcepoolname'],
                    'vmname': row['vmname'],
                    'version': row['version'],
                    'vmlist_id': row['vmlist_id']
                })
            connection.commit()
            connection.close()
            logging.info(f"{TO_TABLE_NAME} Tablosunda {to_update.shape[0]} adet kayıt güncellendi.")

    if not to_insert.empty:
        to_insert.to_sql(TO_TABLE_NAME, engineForPostgres, chunksize=5000, index=False, if_exists='append')
        logging.info(f"{TO_TABLE_NAME} Tablosuna {to_insert.shape[0]} adet yeni kayıt eklendi.")

    if to_soft_delete:
        with engineForPostgres.connect() as connection:
            update_sql = text(f"""
                UPDATE {TO_TABLE_NAME}
                SET is_deleted = True
                WHERE vmlist_id = :vmlist_id AND diskname = :diskname
            """)
            for line in to_soft_delete:
                connection.execute(update_sql, {'diskname': line[0], 'vmlist_id': line[1]})
            connection.commit()
            connection.close()
            logging.info("{TO_TABLE_NAME} Tablosunda {len(to_soft_delete)} adet kayıt silindi.")

def append_vm_info_history_for_proxmox():
    TO_TABLE_NAME = "kr_vm_list_history"

    query_current_date = f"""SELECT CURRENT_DATE"""
    current_date = pd.read_sql(query_current_date, engineForPostgres)
    logging.info(f"DB CURRENT DATE: {current_date['current_date'][0]}")

    query = f"""SELECT id, bandwidth, cpu, createdate, is_deleted, disksize, draassize, ramsizegb, resource_pool, version 
                FROM {VM_LIST_TABLE_NAME} 
                WHERE virtualizationtechnology = 'Proxmox'
                AND is_deleted = False"""
    readed_vm_list_df = pd.read_sql(query, engineForPostgres)
    columns_to_convert = ['bandwidth', 'cpu', 'ramsizegb']
    readed_vm_list_df[columns_to_convert] = readed_vm_list_df[columns_to_convert].astype('float64')

    readed_vm_list_df = readed_vm_list_df.rename(columns={
        'id': 'vmlist_id',
        'bandwidth': 'bandwidthsize',
        'cpu': 'cpusize',
        'ramsizegb': 'ramsize',
        'disksize': 'disksize',
    })

    #updatedate, year, month, day
    current_datetime = pd.Timestamp.now().replace(hour=0, minute=0, second=0, microsecond=0)

    readed_vm_list_df['updatedate'] = current_datetime
    readed_vm_list_df['updateday'] = current_datetime.day
    readed_vm_list_df['updatemonth'] = current_datetime.month
    readed_vm_list_df['updateyear'] = current_datetime.year

    #check kr_vm_list_history existing day data
    query_history = f"""SELECT kvlh.vmlist_id, kvlh.updatedate , kvl.virtualizationtechnology
                FROM {TO_TABLE_NAME} kvlh  
                left join {VM_LIST_TABLE_NAME} kvl on kvl.id = kvlh.vmlist_id 
                WHERE kvlh.updatedate::date = CURRENT_DATE
                and kvl.virtualizationtechnology = 'Proxmox'
                """

    vm_list_history_df = pd.read_sql(query_history, engineForPostgres)

    #update, insert
    to_update = readed_vm_list_df[readed_vm_list_df['vmlist_id'].isin(vm_list_history_df['vmlist_id'])]
    to_insert = readed_vm_list_df[~readed_vm_list_df['vmlist_id'].isin(vm_list_history_df['vmlist_id'])]

    to_insert['createdate'] = pd.Timestamp.now()

    #soft delete
    to_soft_delete = set(vm_list_history_df['vmlist_id']) - set(readed_vm_list_df['vmlist_id'])

    if not to_insert.empty:
        logging.info(f"{TO_TABLE_NAME} tablosunda {to_insert.shape[0]} adet VM bilgisi ekleniyor...")
        to_insert.to_sql(TO_TABLE_NAME, engineForPostgres, chunksize=5000, index=False, if_exists='append')
        logging.info(f"{TO_TABLE_NAME} tablosuna {to_insert.shape[0]} adet VM bilgisi eklendi.")

    if not to_update.empty:
        logging.info(f"{TO_TABLE_NAME} tablosunda {to_update.shape[0]} adet VM bilgisi güncelleniyor...")
        with engineForPostgres.connect() as connection:
            for _, row in to_update.iterrows():
                sql = text(f"""
                        UPDATE {TO_TABLE_NAME}
                        SET bandwidthsize = :bandwidthsize,
                            cpusize = :cpusize,
                            is_deleted = :is_deleted,
                            disksize = :disksize,
                            draassize = :draassize,
                            ramsize = :ramsize,
                            resource_pool = :resource_pool
                        WHERE vmlist_id = :vmlist_id 
                        AND updatedate::date = CURRENT_DATE
                    """)

                connection.execute(sql, {
                    'bandwidthsize': row['bandwidthsize'],
                    'cpusize': row['cpusize'],
                    'is_deleted': row['is_deleted'],
                    'disksize': row['disksize'],
                    'draassize': row['draassize'],
                    'ramsize': row['ramsize'],
                    'resource_pool': row['resource_pool'],
                    'vmlist_id': row['vmlist_id']
                })
            connection.commit()
            connection.close()
            logging.info(f"{TO_TABLE_NAME} tablosunda {to_update.shape[0]} adet VM bilgisi güncellendi.")

    if to_soft_delete:
        with engineForPostgres.connect() as connection:
            logging.info(f"{TO_TABLE_NAME} tablosunda {len(to_soft_delete)} adet VM bilgisi siliniyor...")
            update_sql = text(f"""
                UPDATE {TO_TABLE_NAME}
                SET is_deleted = True
                WHERE vmlist_id = :vmlist_id
                AND updatedate::date = CURRENT_DATE
            """)
            for vmlist_id in to_soft_delete:
                connection.execute(update_sql, {'vmlist_id': vmlist_id})
            connection.commit()
            connection.close()
            logging.info(f"{TO_TABLE_NAME} tablosunda {len(to_soft_delete)} adet VM bilgisi silindi.")

    print(f"VM bilgileri {TO_TABLE_NAME} tablosuna ekleniyor...")

def upsert_vm_events_for_transaction_proxmox(event_dict_list):
    TO_TABLE_NAME = "kr_transaction_history"

    events_df = pd.DataFrame(event_dict_list)

    kr_vm_list_df = pd.read_sql(f"""
            SELECT id, uuid 
            FROM {VM_LIST_TABLE_NAME}
            WHERE virtualizationtechnology = 'Proxmox'
        """, engineForPostgres)

    events_df['vmlist_id'] = events_df['uuid'].apply(
        lambda x: kr_vm_list_df.loc[kr_vm_list_df['uuid'] == x, 'id'].values[0] if not kr_vm_list_df.loc[
            kr_vm_list_df['uuid'] == x, 'id'].empty else None)

    events_df = events_df.dropna(subset=['vmlist_id'])

    events_df = events_df.drop(columns=['uuid'])

    if 'id' in events_df.columns:
        events_df = events_df.drop(columns=['id'])

    existing_events = pd.read_sql(f"SELECT logsource, vmlist_id FROM {TO_TABLE_NAME};", engineForPostgres)

    existing_events_set = set(
        zip(existing_events['logsource'], existing_events['vmlist_id']))

    to_insert = events_df[~events_df.set_index(['logsource', 'vmlist_id']).index.isin(existing_events_set)]
    to_update = events_df[events_df.set_index(['logsource', 'vmlist_id']).index.isin(existing_events_set)]

    if not to_insert.empty:
        to_insert.to_sql(TO_TABLE_NAME, engineForPostgres, chunksize=5000, index=False, if_exists='append')
        logging.info(f"{TO_TABLE_NAME} tablosuna {to_insert.shape[0]} adet kayıt eklendi.")

    if not to_update.empty:
        with engineForPostgres.connect() as connection:
            for _, row in to_update.iterrows():
                sql = text(f"""
                            UPDATE {TO_TABLE_NAME}
                            SET description = :description,
                                logdate = :logdate,
                                logsource = :logsource,
                                logtype = :logtype,
                                vmname = :vmname,
                                version = :version,
                                tasktype = :tasktype
                            WHERE vmlist_id = :vmlist_id AND logsource = :logsource
                        """)

                connection.execute(sql, {
                    'description': row['description'],
                    'logdate': row['logdate'],
                    'logsource': row['logsource'],
                    'logtype': row['logtype'],
                    'vmname': row['vmname'],
                    'version': row['version'],
                    'tasktype': row['tasktype'],
                    'vmlist_id': row['vmlist_id']
                })
            connection.commit()
            connection.close()
            logging.info(f"{TO_TABLE_NAME} tablosunda {to_update.shape[0]} adet kayıt güncellendi.")

if __name__ == "__main__":
    LogProcess.create_logger_settings(log_prefix=os.path.basename(__file__).split(".")[0], script_dir=os.path.dirname(os.path.realpath(__file__)))
    engineForPostgres = PostgresConnection().get_db_instance()

    VM_LIST_TABLE_NAME = "kr_vm_list"

    logging.info("İşlemler başlatılıyor bilgileri alınıyor...")

    logging.info("Postgres veritabanı bağlantısı başlatılıyor...")


    vm_info_list = []
    disk_list = []
    guest_disk_info_list = []
    event_dict_list = []

    login_proxmox(proxmox_creds)

    logging.info("Proxmox bilgileri alındı. Veritabanına ekleniyor...")

    if vm_info_list:
        upsert_vm_info_to_dataframe_new(vm_info_list)
        logging.info(f"VM'ler {VM_LIST_TABLE_NAME} eklendi")
        upsert_vm_events_for_transaction_proxmox(event_dict_list)
        logging.info(f"VM eventleri kr_transaction_history eklendi")

    if sys.argv[1]:
        try:
            # Decode the Base64 argument
            decoded_arg = base64.b64decode(sys.argv[1]).decode('utf-8')
            logging.info(f"Decoded Arg: {decoded_arg}")
            if decoded_arg == "mode=addHistory":
                append_vm_info_history_for_proxmox()
                logging.info("VM bilgileri history tablosuna eklendi")
            else:
                logging.error("Geçersiz argüman")
        except Exception as e:
            logging.error(f"VM bilgileri history tablosuna eklenirken hata oluştu: {e}")
    else:
        logging.error("Argüman alınamadı. VM bilgileri history tablosuna eklenmedi.")

    if disk_list:
        upsert_disk_info_to_dataframe(disk_list)
        logging.info(f"Diskler kr_vm_first_disk'e eklendi")
    if guest_disk_info_list:
        upsert_guest_disk_info_to_dataframe(guest_disk_info_list)
        logging.info(f"Guest disk bilgileri kr_vm_warnings'e eklendi")

    PostgresConnection().close_db_instance()

    logging.info("İşlem tamamlandı.")