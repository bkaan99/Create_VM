import logging
import os
import datetime
import pyfiglet

class LogProcess:
    logger_initialized = False  # Singleton

    @staticmethod
    def create_logger_settings(log_prefix, script_dir = None):
        if LogProcess.logger_initialized:
            return

        LogProcess.logger_initialized = True

        # Scriptin bulunduğu dizini al ve logs dizini oluştur
        log_dir = os.path.join(script_dir, "logs")

        # Eğer dizin yoksa oluştur
        try:
            if not os.path.exists(log_dir):
                os.makedirs(log_dir)
        except OSError as e:
            print(f"Log dizini oluşturulurken bir hata oluştu: {e}")
            return

        # Log dosyasının yolu
        log_file_path = os.path.join(log_dir, f'{log_prefix}_{datetime.datetime.today().strftime("%Y-%m-%d")}.log')

        # Logging yapılandırması
        logging.basicConfig(
            filename=log_file_path,
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
        )

        capitalize_log_prefix = " ".join([word.capitalize() for word in log_prefix.split("_")])

        # ASCII banner
        try:
            ascii_banner = pyfiglet.figlet_format(capitalize_log_prefix, font="slant")
            logging.info("\n" + ascii_banner)
        except Exception as e:
            logging.warning(f"ASCII banner oluşturulamadı: {e}")

        logging.info(f"{capitalize_log_prefix} işlemi başlatıldı.")

    @staticmethod
    def close_logger():
        logging.shutdown()
        LogProcess.logger_initialized = False