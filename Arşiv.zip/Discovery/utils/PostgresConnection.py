import logging
import time
from typing import Optional
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql import text
import pandas as pd
from contextlib import contextmanager
from sqlalchemy.exc import OperationalError


class PostgresConnection:
    # Varsayılan bağlantı URL'si
    DEFAULT_URL = '10.14.45.69'
    DEFAULT_PORT = '7100'
    DEFAULT_DB_NAME = 'karcin_pfms'
    DEFAULT_USER = 'postgres'
    DEFAULT_PWD = 'Cekino.123!'
    DEFAULT_DB_STRING = f"postgresql+psycopg2://{DEFAULT_USER}:{DEFAULT_PWD}@{DEFAULT_URL}:{DEFAULT_PORT}/{DEFAULT_DB_NAME}"

    def __init__(self, db_url: str = None, retries: int = 3, delay: int = 5):
        """
        Args:
            db_url (str): Veritabanı bağlantı URL'si. Eğer verilmezse varsayılan URL kullanılır.
            retries (int): Bağlantı deneme sayısı (varsayılan 3).
            delay (int): Başarısız bağlantılar arasında bekleme süresi (saniye, varsayılan 5).
        """
        self.db_url = db_url or self.DEFAULT_DB_STRING  # Kullanıcı URL vermezse varsayılan URL'yi kullan
        self.retries = retries
        self.delay = delay
        self.db_instance: Optional[Engine] = None

    def connect_to_postgres(self) -> Engine:
        """
        PostgreSQL veritabanına bağlantı kurar ve bir Engine nesnesi döner.
        Bağlantı başarısız olursa belirli sayıda yeniden deneme yapar.
        """
        attempt = 0
        while attempt < self.retries:
            try:
                logging.info("PostgreSQL'e bağlanılıyor...")
                engine: Engine = create_engine(self.db_url, pool_pre_ping=True)
                # Test bağlantısı
                with engine.connect() as conn:
                    conn.execute(text("SELECT 1"))
                logging.info("PostgreSQL'e başarıyla bağlanıldı.")
                return engine
            except OperationalError as e:
                # Bu hata genellikle ağ sorunları veya erişim hatalarından kaynaklanır.
                attempt += 1
                logging.error(f"PostgreSQL'e bağlanırken hata oluştu: {e}. {attempt}/{self.retries} deneme yapılıyor.")
                if attempt < self.retries:
                    time.sleep(self.delay)
            except Exception as e:
                # Diğer hatalar için retry yapma
                logging.error(f"PostgreSQL bağlantısı sırasında beklenmedik bir hata oluştu: {e}")
                raise
        logging.critical("PostgreSQL'e bağlanılamadı. Program sonlandırılıyor.")
        raise ConnectionError("PostgreSQL'e bağlanılamadı.")

    def get_db_instance(self) -> Engine:
        """
        Singleton yaklaşımı ile bir veritabanı instance'ı döner.
        Eğer mevcut bir bağlantı yoksa, yeni bir bağlantı oluşturur.
        """
        if self.db_instance is None:
            logging.info("Yeni bir veritabanı bağlantısı oluşturuluyor.")
            self.db_instance = self.connect_to_postgres()
        else:
            logging.info("Mevcut veritabanı bağlantısı kullanılıyor.")
        return self.db_instance

    def close_db_instance(self) -> None:
        """
        Veritabanı bağlantısını kapatır ve instance'ı sıfırlar.
        """
        if self.db_instance is not None:
            logging.info("PostgreSQL bağlantısı kapatılıyor...")
            self.db_instance.dispose()
            self.db_instance = None
            logging.info("PostgreSQL bağlantısı başarıyla kapatıldı.")
        else:
            logging.info("Kapatılacak bir PostgreSQL bağlantısı bulunamadı.")

    def execute_query(self, query: str, params: dict = None) -> None:
        """
        Sorgu çalıştırmak için kullanılır.
        """
        session = self.get_session()
        try:
            session.execute(text(query), params or {})
            session.commit()
        except Exception as e:
            logging.error(f"Sorgu çalıştırılırken hata oluştu: {e}")
            session.rollback()
            raise e
        finally:
            session.close()

    def fetch_dataframe(self, query: str) -> pd.DataFrame:
        """
        Sorgu sonucunu pandas DataFrame olarak döner.
        """
        try:
            df = pd.read_sql_query(query, self.get_db_instance())
            return df
        except Exception as e:
            logging.error(f"DataFrame çekilirken hata oluştu: {e}")
            raise e

    def get_session(self):
        """
        SQLAlchemy oturumu döner.
        """
        if not hasattr(self, '_Session'):
            self._Session = sessionmaker(bind=self.get_db_instance())
        return self._Session()

    @contextmanager
    def session_scope(self):
        """Bir oturum için context manager."""
        session = self.get_session()
        try:
            yield session
            session.commit()
        except Exception as e:
            logging.error(f"Oturum sırasında hata oluştu: {e}")
            session.rollback()
            raise
        finally:
            session.close()