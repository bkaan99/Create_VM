import requests

class GetCredential:
    def __init__(self):
        self.BASE_URL = "http://172.16.21.222/pfms/rest/karcin-pfms/rest-api/"
        self.BEARER_TOKEN = (
            "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIiwiY2xpZW50SWQiOiIiLCJuYm"
            "YiOjE3MzI2OTgwMDEsImlzcyI6IjEiLCJleHAiOjE3MzI2OTg2MDEsImlhd"
            "CI6MTczMjY5ODAwMSwianRpIjoiZDI1Zjk2NDktYTNjYy00MDZlLTk2NzUt"
            "MTZiMGQyYTFmOGU1In0.OpdsPSOHxpwLE16Mt-btW_dE-uZi0Wh8sK6kbvlIzhQ"
        )
        self.COOKIE = f"access_token={self.BEARER_TOKEN}"
        self.HEADERS = {"Cookie": self.COOKIE}
        self.BODY = {
            "method": "getConnections",
            "processor": "parametricData"
        }

    def get_credential(self):
        response = requests.post(
            self.BASE_URL, headers=self.COOKIE, json=self.BODY
        )
        return response.json()


if __name__ == "__main__":
    get_credential = GetCredential()
    print(get_credential.get_credential())