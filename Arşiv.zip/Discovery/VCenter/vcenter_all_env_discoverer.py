from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[2]))
import base64
import datetime
import logging
import os
import socket
import ssl
import sys
from enum import Enum
from pyVmomi import vim
import pandas as pd
from pyVim import connect
from sqlalchemy import text
import concurrent.futures
from Discovery.utils.PostgresConnection import PostgresConnection
from Discovery.utils.LogProcess import LogProcess

vcenter_hosts = {
    "turksat-vmware": {
        "datacenter": "TURKSAT",
        "usage_location": "turksat-vmware ansible",
        "product_type" : "VMWARE",
        "host": "10.184.1.10",
        "username": "P9988.marvin.android@vsphere.local",
        "password": "T7z8nSVChzmzw3zUjK9."
    },
    "equinix-vmware": {
        "datacenter": "EQX",
        "usage_location": "equinix-vmware ansible",
        "product_type" : "VMWARE",
        "host": "10.197.214.10",
        "username": "P9988.marvin.android@vsphere.local",
        "password": "T7z8nSVChzmzw3zUjK9."
    },
    "kkb-vmware": {
        "datacenter": "KKB",
        "usage_location": "kkb-vmware ansible",
        "product_type" : "VMWARE",
        "host": "172.22.0.8",
        "username": "P9988.marvin.android@vsphere.local",
        "password": "T7z8nSVChzmzw3zUjK9."
    },
    "kkb-uno": {
        "datacenter": "KKB",
        "usage_location": "kkb-uno ansible",
        "product_type" : "VMWARE",
        "host": "10.180.112.6",
        "username": "P9988.marvin.android@vsphere.local",
        "password": "ALg<*]3BBYFqRbsz"
    },
    "kkb-alotech": {
        "datacenter": "KKB",
        "usage_location": "kkb-alotech ansible",
        "product_type" : "VMWARE",
        "host": "10.1.120.10",
        "username": "P9988.marvin.android@vsphere.local",
        "password": "ALg<*]3BBYFqRbsz"
    },
    "turksat-starpay": {
        "datacenter": "TURKSAT",
        "usage_location": "turksat-starpay ansible",
        "product_type" : "VMWARE",
        "host": "10.6.130.25",
        "username": "P9988.marvin.android@vsphere.local",
        "password": "ALg<*]3BBYFqRbsz"
    },
    "equinix-starpay": {
        "datacenter": "EQX",
        "usage_location": "equinix-starpay ansible",
        "product_type" : "VMWARE",
        "host": "10.34.30.20",
        "username": "P9988.marvin.android@vsphere.local",
        "password": "ALg<*]3BBYFqRbsz"
    },
    "kkb-datassist": {
        "datacenter": "KKB",
        "usage_location": "kkb-datassist ansible",
        "product_type" : "VMWARE",
        "host": "10.156.0.2",
        "username": "P9988.marvin.android@vsphere.local",
        "password": "ALg<*]3BBYFqRbsz"
    },
    "kkb-parakolay": {
        "datacenter": "KKB",
        "usage_location": "ParaKolay Vcenter",
        "product_type" : "VCENTER",
        "host": "10.11.32.20",
        "username": "P9988.marvin.android@vsphere.local",
        "password": "ALg<*]3BBYFqRbsz"
    },
    "eqx-parakolay": {
        "datacenter": "EQX",
        "usage_location": "Çok yaşar Vcenter",
        "product_type" : "VCENTER",
        "host": "10.6.8.10",
        "username": "P9988.marvin.android@vsphere.local",
        "password": "ALg<*]3BBYFqRbsz"
    },
    "equinix-parakolay": {
        "datacenter": "EQX",
        "usage_location": "ParaKolay Vcenter",
        "product_type" : "VCENTER",
        "host": "10.37.58.20",
        "username": "P9988.marvin.android@vsphere.local",
        "password": "ALg<*]3BBYFqRbsz"
    },
    "equinix-smart": {
        "datacenter": "EQX",
        "usage_location": "equinix-smart ansible",
        "product_type" : "VMWARE",
        "host": "10.134.150.10",
        "username": "P9988.marvin.android@smrt.cloud",
        "password": "ALg<*]3BBYFqRbsz"
    }
}

class VMInfo:
    class GuestFamily(Enum):
        WINDOWS = "Windows"
        MACOS = "Mac OS"
        LINUX = "Linux"
        OTHER = "Other"

    windows_keywords = [
        "Microsoft MS-DOS",
        "Microsoft Small Business Server 2003",
        "Microsoft Windows 10",
        "Microsoft Windows 10 (64-bit)",
        "Microsoft Windows 7 (32-bit)",
        "Microsoft Windows 7 (64-bit)",
        "Microsoft Windows 8 (64-bit)",
        "Microsoft Windows Server 2003 (32-bit)",
        "Microsoft Windows Server 2003 Standard (32-bit)",
        "Microsoft Windows Server 2003 Standard (64-bit)",
        "Microsoft Windows Server 2008 (32-bit)",
        "Microsoft Windows Server 2008 (64-bit)",
        "Microsoft Windows Server 2008 R2",
        "Microsoft Windows Server 2008 R2 (64-bit)",
        "Microsoft Windows Server 2012",
        "Microsoft Windows Server 2012 (64-bit)",
        "Microsoft Windows Server 2012 R2",
        "Microsoft Windows Server 2016",
        "Microsoft Windows Server 2016 (64-bit)",
        "Microsoft Windows Server 2019",
        "Microsoft Windows Server 2019 (64-bit)",
        "Microsoft Windows Server 2022",
        "Microsoft Windows Server 2022 (64-bit)",
        "Microsoft Windows XP Professional (32-bit)"
    ]

    other_keywords = [
        "FreeBSD (64-bit)",
        "FreeBSD 11",
        "FreeBSD 12",
        "FreeBSD 13",
        "FreeBSD Pre-11",
        "IBM OS/2",
        "Novell NetWare 5.1",
        "Novell NetWare 6.x",
        "Oracle Solaris 10",
        "Oracle Solaris 11",
        "Other",
        "SCO OpenServer 5",
        "SCO OpenServer 6",
        "SCO UnixWare 7",
        "Serenity Systems eComStation 1",
        "Serenity Systems eComStation 2",
        "Sun Microsystems Solaris 8",
        "Sun Microsystems Solaris 9",
        "VMware ESX 4.x",
        "VMware ESXi 5.x",
        "VMware ESXi 6.0",
        "VMware ESXi 6.x",
        "VMware ESXi 7.0",
        "VMware ESXi 6.5 or later"
    ]

    macos_keywords = [
        "Apple Mac OS X 10.10",
        "Apple Mac OS X 10.11",
        "Apple Mac OS X 10.5",
        "Apple Mac OS X 10.6",
        "Apple Mac OS X 10.7",
        "Apple Mac OS X 10.8",
        "Apple Mac OS X 10.9",
        "Apple macOS 10.12",
        "Apple macOS 10.13",
        "Apple macOS 10.14",
        "Apple macOS 10.15",
        "Apple macOS 11",
        "Apple macOS 12"
    ]

    linux_keywords = [
        "Amazon Linux 2",
        "Amazon Linux 3",
        "AlmaLinux 8.10 (Cerulean Leopard)",
        "CentOS 4/5 (64-bit)",
        "CentOS 4/5/6 (64-bit)",
        "CentOS 4/5/6/7 (64-bit)",
        "CentOS 6 (64-bit)",
        "CentOS 7 (64-bit)",
        "CentOS 8 (64-bit)",
        "CentOS Linux 7 (Core)",
        "CentOS Linux 8",
        "CentOS Stream 8",
        "CentOS Stream 9",
        "Debian GNU/Linux 10 (64-bit)",
        "Debian GNU/Linux 10 (buster)",
        "Debian GNU/Linux 11 (64-bit)",
        "Debian GNU/Linux 11 (bullseye)",
        "Debian GNU/Linux 4 (64-bit)",
        "Debian GNU/Linux 6 (64-bit)",
        "Debian GNU/Linux 8 (64-bit)",
        "Debian GNU/Linux trixie/sid",
        "Other Linux (64-bit)",
        "Other 2.6.x Linux (32-bit)",
        "Other 2.6.x Linux (64-bit)",
        "Other 3.x or later Linux (64-bit)",
        "Other 4.x Linux (64-bit)",
        "Other 4.x or later Linux (64-bit)",
        "Other 5.x or later Linux (64-bit)",
        "Oracle Linux 7 (64-bit)",
        "Oracle Linux 8 (64-bit)",
        "Oracle Linux Server 8.10",
        "Oracle Linux Server 8.8",
        "Oracle Linux Server 9.4",
        "Red Hat Enterprise Linux 5 (64-bit)",
        "Red Hat Enterprise Linux 6 (64-bit)",
        "Red Hat Enterprise Linux 7 (64-bit)",
        "Red Hat Enterprise Linux 8 (64-bit)",
        "Red Hat Enterprise Linux 8.4 (Ootpa)",
        "Red Hat Enterprise Linux 8.5 (Ootpa)",
        "Red Hat Enterprise Linux 8.6 (Ootpa)",
        "Red Hat Enterprise Linux 8.7 (Ootpa)",
        "Red Hat Enterprise Linux 8.8 (Ootpa)",
        "Red Hat Enterprise Linux 8.9 (Ootpa)",
        "Rocky Linux 8.10 (Green Obsidian)",
        "Rocky Linux 8.8 (Green Obsidian)",
        "Rocky Linux 8.9 (Green Obsidian)",
        "Rocky Linux 9.1 (Blue Onyx)",
        "Rocky Linux 9.2 (Blue Onyx)",
        "Rocky Linux 9.3 (Blue Onyx)",
        "Rocky Linux 9.4 (Blue Onyx)",
        "SUSE Linux Enterprise 10 (32-bit)",
        "SUSE Linux Enterprise 11 (64-bit)",
        "SUSE Linux Enterprise 12 (64-bit)",
        "SUSE Linux Enterprise 15 (64-bit)",
        "SUSE Linux Enterprise Server 12 SP4",
        "SUSE Linux Enterprise Server 15",
        "SUSE Linux Enterprise Server 15 SP1",
        "SUSE Linux Enterprise Server 15 SP2",
        "SUSE Linux Enterprise Server 15 SP3",
        "SUSE Linux Enterprise Server 15 SP4",
        "SUSE Linux Enterprise Server 15 SP5",
        "Ubuntu 18.04.6 LTS",
        "Ubuntu 20.04 LTS",
        "Ubuntu 20.04.3 LTS",
        "Ubuntu 20.04.4 LTS",
        "Ubuntu 20.04.5 LTS",
        "Ubuntu 20.04.6 LTS",
        "Ubuntu 22.04.2 LTS",
        "Ubuntu 22.04.3 LTS",
        "Ubuntu 22.04.4 LTS",
        "Ubuntu 22.04.5 LTS",
        "Ubuntu 23.04",
        "Ubuntu 24.04 LTS",
        "Ubuntu Linux (32-bit)",
        "Ubuntu Linux (64-bit)"
    ]

    @classmethod
    def find_guest_family(cls, os_version_name):
        os_version_lower = os_version_name.lower()

        # Check for Windows keywords
        if any(keyword.lower() in os_version_lower for keyword in cls.windows_keywords):
            return cls.GuestFamily.WINDOWS

        # Check for macOS keywords
        if any(keyword.lower() in os_version_lower for keyword in cls.macos_keywords):
            return cls.GuestFamily.MACOS

        # Check for Linux keywords
        if any(keyword.lower() in os_version_lower for keyword in cls.linux_keywords):
            return cls.GuestFamily.LINUX

        # If none of the keywords match, check for other keywords
        if any(keyword.lower() in os_version_lower for keyword in cls.other_keywords):
            return cls.GuestFamily.OTHER

        return cls.GuestFamily.OTHER

class DiskProvisioning(Enum):
    THIN = 'Thin Provisioned'
    THICK_EAGER = 'Thick Provision Eager Zeroed'
    THICK_LAZY = 'Thick Provision Lazy Zeroed'
    THICK_UNKNOWN = 'Thick Provision (Unknown Zeroing Type)'
    UNKNOWN = 'Unknown Provisioning'

class DiskSharing(Enum):
    SHARING_MULTI_WRITER = 'Multi-Writer'
    SHARING_HIGH = 'High'
    SHARING_NORMAL = 'Normal'
    SHARING_NONE = 'None'
    UNKNOWN = 'Unknown'

class VMEventCategory(Enum):
    START_AND_STOP = [
        "vim.event.VmPoweredOnEvent",  # VM başlatma
        "vim.event.VmPoweredOffEvent",  # VM durdurma
    ]
    CAPACITY_AND_CONFIGURATION = [
        "vim.event.VmReconfiguredEvent",  # Kapasite ve konfigürasyon değişiklikleri
    ]
    REBOOT = [
        "vim.event.VmGuestRebootEvent",  # Reboot
    ]
    CREATION_AND_DELETION = [
        "vim.event.VmBeingCreatedEvent",  # VM yaratma
        "vim.event.VmRemovedEvent",  # VM silme
    ]
    BACKUP_AND_RESTORE = [
        "vim.event.VmBackupSucceededEvent",  # Yedekleme başarılı
        "vim.event.VmBackupFailedEvent",  # Yedekleme başarısız
        "vim.event.VmRestoredEvent",  # Yedekten geri yükleme
    ]
    SOFTWARE_AND_PATCH_MANAGEMENT = [
        "vim.event.VmSoftwareUpdatedEvent",  # Yazılım güncelleme
        "vim.event.VmPatchSucceededEvent",  # Yama başarılı
        "vim.event.VmPatchFailedEvent",  # Yama başarısız
    ]

    @classmethod
    def get_event_category(cls, event_name):
        for category in cls:
            if event_name in category.value:
                return category.name
        return "UNKNOWN"

def create_vsphere_connection(host: str, user: str, password: str, timeout=10):
    ssl_context = ssl.create_default_context()
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE

    try:
        socket.create_connection((host, 443), timeout=timeout)
        service_instance = connect.SmartConnect(host=host,
                                                user=user,
                                                pwd=password,
                                                sslContext=ssl_context)

        content = service_instance.RetrieveContent()
        print(f"vCenter sunucusuna bağlanıldı: {host}")
        return service_instance, content

    except Exception as e:
        print(f"{host} sunucusuna bağlanırken hata oluştu: {e}")
        return None, None

def get_controller_type(device_list, controller_key):
    """Kontrolörün türünü belirle."""
    for device in device_list:
        if isinstance(device, vim.vm.device.VirtualController):
            if device.key == controller_key:
                if isinstance(device, vim.vm.device.VirtualSCSIController):
                    return 'SCSI'
                elif isinstance(device, vim.vm.device.VirtualIDEController):
                    return 'IDE'
                elif isinstance(device, vim.vm.device.VirtualSATAController):
                    return 'SATA'
                else:
                    return 'Other'
    return 'Unknown'

def get_controller_location_value(device_list, controller_key):
    """Kontrolörün konum değerini belirle."""
    for device in device_list:
        if isinstance(device, vim.vm.device.VirtualController):
            if device.key == controller_key:
                if isinstance(device, vim.vm.device.VirtualSCSIController):
                    return device.busNumber
                elif isinstance(device, vim.vm.device.VirtualIDEController):
                    return device.busNumber
                elif isinstance(device, vim.vm.device.VirtualSATAController):
                    return device.busNumber
                else:
                    return 'Unknown'
    return 'Unknown'

def product_usage_calculator_for_vmware(sum_disk_size, onlineofflinestatus, vm_name, vm_summary_config, vm_summary_guest):
    # Convert power state to boolean if needed
    if onlineofflinestatus == 'poweredOn':
        onlineofflinestatus = True
    elif onlineofflinestatus == 'poweredOff':
        onlineofflinestatus = False
    else:
        onlineofflinestatus = False

    # Product Usage Section
    vCPU = float(0)
    vramsizegb = float(0)
    vdisk = float(0)
    Draas = float(0)

    if onlineofflinestatus:
        if vm_name.startswith("rp.") and (vm_name.endswith("shadow") or vm_name.endswith("shad0w24")):
            Draas = sum_disk_size
        elif not vm_summary_guest.ipAddress and (vm_name.endswith(".copy") or vm_name.endswith(".c0py24")):
            pass
        elif vm_summary_guest.ipAddress and (vm_name.endswith(".copy") or vm_name.endswith(".c0py24")):
            vCPU = vm_summary_config.numCpu if vm_summary_config.numCpu else '0'
            vramsizegb = vm_summary_config.memorySizeMB / 1024 if vm_summary_config.memorySizeMB else '0'
            vdisk = sum_disk_size
        elif ("sil" in vm_name or "s1l24" in vm_name) and not ("silme" in vm_name or "s1lme324" in vm_name):
            pass
        else:
            vCPU = vm_summary_config.numCpu if vm_summary_config.numCpu else '0'
            vramsizegb = vm_summary_config.memorySizeMB / 1024 if vm_summary_config.memorySizeMB else '0'
            vdisk = sum_disk_size


    elif not onlineofflinestatus:
        if vm_name.startswith("rp.") and (vm_name.endswith("shadow") or vm_name.endswith("shad0w24")):
            Draas = sum_disk_size
        elif not vm_summary_guest.ipAddress and (vm_name.endswith(".copy") or vm_name.endswith(".c0py24")):
            pass
        elif vm_summary_guest.ipAddress and (vm_name.endswith(".copy") or vm_name.endswith(".c0py24")):
            vdisk = sum_disk_size
        elif ("sil" in vm_name or "s1l24" in vm_name) and not ("silme" in vm_name or "s1lme324" in vm_name):
            pass
        else:
            vdisk = sum_disk_size

    return vCPU, vramsizegb, vdisk, Draas, onlineofflinestatus

def test_vsphere_connections():
    for host_name, creds in vcenter_hosts.items():
        logging.info(f"{host_name} sunucusuna bağlanmayı deniyor...")
        service_instance, content = create_vsphere_connection(creds['host'], creds['username'], creds['password'])
        if service_instance:
            logging.info(f"{host_name} sunucusuna başarıyla bağlandı.")
            get_vm_info(content, host_name, creds['host'], creds['datacenter'], creds['usage_location'], creds['product_type'])
            logging.info(f"{host_name} sunucusundaki VM bilgileri başarıyla alındı.")
        else:
            print(f"{host_name} bağlantı başarısız.")
            logging.error(f"{host_name} bağlantı başarısız.")

def upsert_disk_info_to_dataframe(disk_info_list):
    print("Disk bilgileri veritabanına ekleniyor...")
    disk_df = pd.DataFrame(disk_info_list)

    query = "SELECT id, uuid FROM kr_vm_list WHERE virtualizationtechnology = 'VMware'"
    kr_vm_list_df = pd.read_sql(query, engineForPostgres)

    # disk_df içindeki UUID'yi, kr_vm_list içindeki id ile eşleştir
    disk_df['vmlist_id'] = disk_df['uuid'].apply(
        lambda x: kr_vm_list_df.loc[kr_vm_list_df['uuid'] == x, 'id'].values[0] if not kr_vm_list_df.loc[
            kr_vm_list_df['uuid'] == x, 'id'].empty else None)

    disk_df = disk_df.drop(columns=['uuid'])
    disk_df = disk_df.rename(columns={'id': 'vmlist_id'})

    # Mevcut kr_vm_first_disk tablosundaki vmlist_id'leri çek
    existing_disk_entries = pd.read_sql("SELECT diskobjectid FROM kr_vm_first_disk WHERE controllerlocationvalue is not null", engineForPostgres)
    existing_disks_set = set(existing_disk_entries['diskobjectid'])

    to_update = disk_df[disk_df['diskobjectid'].isin(existing_disks_set)]
    to_insert = disk_df[~disk_df['diskobjectid'].isin(existing_disks_set)]

    to_soft_delete = existing_disks_set - set(disk_df['diskobjectid'])

    if not to_update.empty:
        with engineForPostgres.connect() as connection:
            for _, row in to_update.iterrows():
                sql = text("""
                        UPDATE kr_vm_first_disk
                        SET diskprovisioning = :diskprovisioning,
                            disksize = :disksize,
                            location = :location,
                            sharedvalue = :sharedvalue,
                            version = :version,
                            limitiops = :limitiops,
                            createdate = :createdate,
                            controllerlocationvalue = :controllerlocationvalue,
                            is_deleted = :is_deleted,
                            diskobjectid = :diskobjectid
                        WHERE diskobjectid = :diskobjectid
                    """)
                connection.execute(sql, {
                    'diskprovisioning': row['diskprovisioning'],
                    'disksize': row['disksize'],
                    'location': row['location'],
                    'sharedvalue': row['sharedvalue'],
                    'version': row['version'],
                    'limitiops': row['limitiops'],
                    'createdate': row['createdate'],
                    'controllerlocationvalue': row['controllerlocationvalue'],
                    'is_deleted': row['is_deleted'],
                    'vmlist_id': row['vmlist_id'],
                    'diskobjectid': row['diskobjectid']
                })
            connection.commit()
            connection.close()
            logging.info(f"kr_vm_first_disk Tablosunda {to_update.shape[0]} adet kayıt güncellendi.")

    if not to_insert.empty:
        to_insert.to_sql("kr_vm_first_disk", engineForPostgres, chunksize=5000, index=False, if_exists='append')

    if to_soft_delete:
        with engineForPostgres.connect() as connection:
            update_sql = text("""
                UPDATE kr_vm_first_disk
                SET is_deleted = True
                WHERE diskobjectid = :diskobjectid
            """)
            for diskobjectid in to_soft_delete:
                connection.execute(update_sql, {'diskobjectid': diskobjectid})
            connection.commit()
            connection.close()
            logging.info(f"kr_vm_first_disk Tablosunda {len(to_soft_delete)} adet kayıt silindi.")

def upsert_vm_info_to_dataframe(vm_info_list):
    print("VM bilgileri veritabanına ekleniyor...")
    vm_info_df = pd.DataFrame(vm_info_list)

    existing_uuids = pd.read_sql("""
            SELECT id, uuid 
            FROM kr_vm_list 
            WHERE virtualizationtechnology = 'VMware'
        """, engineForPostgres)

    existing_uuid_set = set(existing_uuids['uuid'])

    to_update = vm_info_df[vm_info_df['uuid'].isin(existing_uuid_set)]
    to_insert = vm_info_df[~vm_info_df['uuid'].isin(existing_uuid_set)]

    id_map = existing_uuids.set_index('uuid')['id'].to_dict()
    to_update['id'] = to_update['uuid'].map(id_map)

    # Silme işlemi: Veritabanındaki ancak vm_info_df'de olmayan kayıtların is_deleted kolonunu True yapar.
    vm_uuid_set = set(vm_info_df['uuid'])
    uuids_to_soft_delete = existing_uuid_set - vm_uuid_set

    if not to_update.empty:
        # Güncelleme işlemi
        logging.info(f"kr_vm_list Tablosunda {to_update.shape[0]} adet kayıt güncelleniyor...")
        with engineForPostgres.connect() as connection:
            for _, row in to_update.iterrows():
                sql = text("""
                        UPDATE kr_vm_list
                        SET vmname = :vmname,
                            onlineofflinestatus = :onlineofflinestatus,
                            ipaddress = :ipaddress,
                            hostname = :hostname,
                            ramsizegb = :ramsizegb,
                            cpu = :cpu,
                            operatingsystemversion = :operatingsystemversion,
                            operatingsysteminformation = :operatingsysteminformation,
                            resource_pool = :resource_pool,
                            total_disk_number = :total_disk_number,
                            virtualizationtechnology = :virtualizationtechnology,
                            environment = :environment,
                            ip = :ip,
                            is_deleted = :is_deleted,
                            disksize = :disksize,
                            draassize = :draassize,
                            bandwidth = :bandwidth,
                            vlanid = :vlanid,
                            vmidgh = :vmidgh,
                            vmcreatedate = :vmcreatedate,
                            datacentertype = :datacentertype,
                            producttype = :producttype,
                            usagetype = :usagetype             
                        WHERE id = :id
                    """)

                connection.execute(sql, {
                    'vmname': row['vmname'],
                    'onlineofflinestatus': row['onlineofflinestatus'],
                    'ipaddress': row['ipaddress'],
                    'hostname': row['hostname'],
                    'ramsizegb': row['ramsizegb'],
                    'cpu': row['cpu'],
                    'operatingsystemversion': row['operatingsystemversion'],
                    'operatingsysteminformation': row['operatingsysteminformation'],
                    'resource_pool': row['resource_pool'],
                    'total_disk_number': row['total_disk_number'],
                    'virtualizationtechnology': row['virtualizationtechnology'],
                    'environment': row['environment'],
                    'ip': row['ip'],
                    'is_deleted': row['is_deleted'],
                    'id': row['id'],
                    'disksize': row['disksize'],
                    'draassize': row['draassize'],
                    'bandwidth': row['bandwidth'],
                    'vlanid': row['vlanid'],
                    'vmidgh': row['vmidgh'],
                    'vmcreatedate': row['vmcreatedate'],
                    'datacentertype': row['datacentertype'],
                    'producttype': row['producttype'],
                    'usagetype': row['usagetype']
                })
            connection.commit()
            connection.close()
            logging.info(f"kr_vm_list Tablosunda {to_update.shape[0]} adet kayıt güncellendi.")

    if not to_insert.empty:
        logging.info(f"kr_vm_list Tablosuna {to_insert.shape[0]} adet yeni kayıt ekleniyor...")
        to_insert = to_insert.drop(columns=['id'], errors='ignore')
        to_insert.to_sql("kr_vm_list", engineForPostgres, chunksize=5000, index=False, if_exists='append')
        logging.info(f"kr_vm_list Tablosuna {to_insert.shape[0]} adet yeni kayıt eklendi.")

    if uuids_to_soft_delete:
        logging.info(f"kr_vm_list Tablosunda {len(uuids_to_soft_delete)} adet kayıt siliniyor...")
        with engineForPostgres.connect() as connection:
            update_sql = text("""
                UPDATE kr_vm_list
                SET is_deleted = True
                WHERE uuid = :uuid
            """)
            for uuid in uuids_to_soft_delete:
                connection.execute(update_sql, {'uuid': uuid})
            connection.commit()
            connection.close()
            logging.info(f"kr_vm_list Tablosunda {len(uuids_to_soft_delete)} adet kayıt silindi.")

def upsert_guest_disk_info_to_dataframe(vm_guest_disk_detail_list):
    print("VM Guest Disk bilgileri veritabanına ekleniyor...")
    TO_TABLE_NAME = "kr_vm_warnings"
    guest_disk_info_df = pd.DataFrame(vm_guest_disk_detail_list)

    query = "SELECT id, uuid FROM kr_vm_list WHERE virtualizationtechnology = 'VMware'"
    kr_vm_list_df = pd.read_sql(query, engineForPostgres)

    guest_disk_info_df['vmlist_id'] = guest_disk_info_df['uuid'].apply(
        lambda x: kr_vm_list_df.loc[kr_vm_list_df['uuid'] == x, 'id'].values[0] if not kr_vm_list_df.loc[
            kr_vm_list_df['uuid'] == x, 'id'].empty else None)

    guest_disk_info_df = guest_disk_info_df.drop(columns=['uuid'])
    guest_disk_info_df = guest_disk_info_df.rename(columns={'id': 'vmlist_id'})

    existing_guest_disk_entries = pd.read_sql(f"SELECT diskname, vmlist_id FROM {TO_TABLE_NAME} WHERE virtualizationtechnology = 'VMware'", engineForPostgres)
    existing_guest_disks_set = set(
        zip(existing_guest_disk_entries['diskname'], existing_guest_disk_entries['vmlist_id']))

    to_update = guest_disk_info_df[guest_disk_info_df.set_index(['diskname', 'vmlist_id']).index.isin(existing_guest_disks_set)]
    to_insert = guest_disk_info_df[~guest_disk_info_df.set_index(['diskname', 'vmlist_id']).index.isin(existing_guest_disks_set)]

    to_soft_delete = existing_guest_disks_set - set(zip(guest_disk_info_df['diskname'], guest_disk_info_df['vmlist_id']))

    if not to_update.empty:
        with engineForPostgres.connect() as connection:
            for _, row in to_update.iterrows():
                sql = text(f"""
                        UPDATE {TO_TABLE_NAME}
                        SET createdate = :createdate,
                            is_deleted = :is_deleted,
                            diskname = :diskname,
                            disksizegb = :disksizegb,
                            freediskgb = :freediskgb,
                            hostname = :hostname,
                            occupacyrate = :occupacyrate,
                            resourcepoolname = :resourcepoolname,
                            vmname = :vmname,
                            version = :version
                        WHERE vmlist_id = :vmlist_id AND diskname = :diskname
                    """)
                connection.execute(sql, {
                    'createdate': row['createdate'],
                    'is_deleted': row['is_deleted'],
                    'diskname': row['diskname'],
                    'disksizegb': row['disksizegb'],
                    'freediskgb': row['freediskgb'],
                    'hostname': row['hostname'],
                    'occupacyrate': row['occupacyrate'],
                    'resourcepoolname': row['resourcepoolname'],
                    'vmname': row['vmname'],
                    'version': row['version'],
                    'vmlist_id': row['vmlist_id']
                })
            connection.commit()
            connection.close()
        logging.info(f"{TO_TABLE_NAME} tablosunda {to_update.shape[0]} adet kayıt güncellendi.")

    if not to_insert.empty:
        to_insert.to_sql(TO_TABLE_NAME, engineForPostgres, chunksize=5000, index=False, if_exists='append')
        logging.info(f"{TO_TABLE_NAME} tablosuna {to_insert.shape[0]} adet yeni kayıt eklendi.")

    if to_soft_delete:
        with engineForPostgres.connect() as connection:
            update_sql = text(f"""
                UPDATE {TO_TABLE_NAME}
                SET is_deleted = True
                WHERE vmlist_id = :vmlist_id AND diskname = :diskname
            """)
            for line in to_soft_delete:
                connection.execute(update_sql, {'diskname': line[0], 'vmlist_id': line[1]})
            connection.commit()
            connection.close()
        logging.info(f"{TO_TABLE_NAME} tablosunda {len(to_soft_delete)} adet kayıt silindi.")

def upsert_vm_events_for_transaction_vmware(event_dict_list):
    logging.info("---------- VM Olayları İşleniyor ----------")
    TO_TABLE_NAME = "kr_transaction_history"

    logging.info("VM Olayları listesi DF'ye dönüştürülüyor...")
    events_df = pd.DataFrame(event_dict_list)
    logging.info("VM Olayları listesi DF'ye dönüştürüldü.")

    kr_vm_list_df = pd.read_sql("""
            SELECT id, uuid 
            FROM kr_vm_list 
            WHERE virtualizationtechnology = 'VMware'
        """, engineForPostgres)

    logging.info("VM Olayları listesi içindeki UUID'leri, kr_vm_list içindeki id ile eşleştiriliyor...")

    events_df['vmlist_id'] = events_df['uuid'].apply(
        lambda x: kr_vm_list_df.loc[kr_vm_list_df['uuid'] == x, 'id'].values[0] if not kr_vm_list_df.loc[
            kr_vm_list_df['uuid'] == x, 'id'].empty else None)

    logging.info("VM Olayları listesi içindeki UUID'leri, kr_vm_list içindeki id ile eşleştirildi.")

    events_df = events_df.dropna(subset=['vmlist_id'])

    events_df = events_df.drop(columns=['uuid'])

    if 'id' in events_df.columns:
        events_df = events_df.drop(columns=['id'])

    existing_events = pd.read_sql(f"SELECT logsource, vmlist_id FROM {TO_TABLE_NAME};", engineForPostgres)
    logging.info("Mevcut olaylar listesi veritabanından alınıyor.")

    existing_events_set = set(
        zip(existing_events['logsource'], existing_events['vmlist_id']))
    logging.info("Mevcut olaylar listesi veritabanından alındı. Boyutu : " + str(len(existing_events_set)))

    to_insert = events_df[~events_df.set_index(['logsource', 'vmlist_id']).index.isin(existing_events_set)]
    to_update = events_df[events_df.set_index(['logsource', 'vmlist_id']).index.isin(existing_events_set)]

    if not to_insert.empty:
        to_insert.to_sql(TO_TABLE_NAME, engineForPostgres, chunksize=5000, index=False, if_exists='append')
        logging.info(f"{TO_TABLE_NAME} tablosuna {to_insert.shape[0]} adet yeni kayıt eklendi.")

    if not to_update.empty:
        with engineForPostgres.connect() as connection:
            for _, row in to_update.iterrows():
                sql = text(f"""
                        UPDATE {TO_TABLE_NAME}
                        SET description = :description,
                            logdate = :logdate,
                            logsource = :logsource,
                            logtype = :logtype,
                            vmname = :vmname,
                            version = :version,
                            tasktype = :tasktype
                        WHERE vmlist_id = :vmlist_id AND logsource = :logsource
                    """)
                connection.execute(sql, {
                    'description': row['description'],
                    'logdate': row['logdate'],
                    'logsource': row['logsource'],
                    'logtype': row['logtype'],
                    'vmname': row['vmname'],
                    'version': row['version'],
                    'tasktype': row['tasktype'],
                    'vmlist_id': row['vmlist_id']
                })
            connection.commit()
            connection.close()
        logging.info(f"{TO_TABLE_NAME} tablosunda {to_update.shape[0]} adet kayıt güncellendi.")

def get_vm_events_and_handle(event_manager, vm, vm_uuid, host_name):
    try:
        event_filter_spec = vim.event.EventFilterSpec()
        #event_filter_spec.eventTypeId = ["vim.event.VmReconfiguredEvent"]
        event_filter_spec.eventTypeId = [
            "vim.event.VmReconfiguredEvent",  # Kapasite değişiklikleri ve konfigürasyon değişiklikleri
            "vim.event.VmGuestRebootEvent",  # Reboot
            "vim.event.VmBeingCreatedEvent",  # VM yaratma
            "vim.event.VmRemovedEvent",  # VM silme
            "vim.event.VmPoweredOnEvent",  # VM başlatma
            "vim.event.VmPoweredOffEvent",  # VM durdurma
            "vim.event.VmBackupSucceededEvent",  # Yedekleme başarılı
            "vim.event.VmBackupFailedEvent",  # Yedekleme başarısız
            "vim.event.VmRestoredEvent",  # Yedekten geri yükleme
            # Software ve patch management event'lerini ekle
            "vim.event.VmSoftwareUpdatedEvent",  # Yazılım güncelleme
            "vim.event.VmPatchSucceededEvent",  # Yama başarılı
            "vim.event.VmPatchFailedEvent",  # Yama başarısız
        ]

        event_filter_spec.entity = vim.event.EventFilterSpec.ByEntity(entity=vm, recursion="self")
        events = event_manager.QueryEvents(event_filter_spec)
        for event in events:
            event_class_name = event.__class__.__name__
            task_type = event_class_name.replace("vim.event.", "")
            event_dict = {
                "uuid": vm_uuid,
                "createdate": datetime.datetime.now(),
                "is_deleted": False,
                "description": f"{task_type};{event.fullFormattedMessage}",
                "logdate": event.createdTime,
                "logsource": f"VMware-{host_name}-" + str(event.key),
                "logtype": VMEventCategory.get_event_category(event_class_name),
                "vmname" : vm.name,
                "version": 1,
                "tasktype": task_type
            }
            event_dict_list.append(event_dict)

    except Exception as e:
        print(f"VM : {vm_uuid} olayları alınırken hata oluştu: {e}")

def process_vm(vm, host_name, host_ip, event_manager, datacenter, usage_location, product_type):
    print(f"Processing VM: {vm.name}")

    #set_usable_variables for vm
    sum_disk_size = 0.0
    vm_config = vm.config
    vm_uuid = vm_config.instanceUuid if vm_config.instanceUuid else 'N/A'
    vm_name = vm.name if vm.name else 'N/A'
    vm_runtime = vm.runtime
    vm_runtime_host = vm_runtime.host
    vm_summary = vm.summary
    vm_summary_config = vm_summary.config
    vm_summary_guest = vm_summary.guest
    vm_network = vm.network
    vm_create_date = vm_config.createDate
    onlineofflinestatus = vm_runtime.powerState
    vm_resource_pool = vm.resourcePool.name if vm.resourcePool else 'N/A'
    vm_vlan_id = (getattr(vm_network[0], 'config', None)
                    and getattr(vm_network[0].config, 'defaultPortConfig', None)
                    and getattr(vm_network[0].config.defaultPortConfig, 'vlan', None)
                    and getattr(vm_network[0].config.defaultPortConfig.vlan, 'vlanId', 'N/A')
                 ) or 'N/A'

    get_vm_events_and_handle(event_manager, vm, vm_uuid, host_name)
    # VM Guest Disk Section
    vm_guest_disks = vm.guest.disk
    if vm_guest_disks:
        for disk in vm_guest_disks:
            disk_info = {
                "uuid": vm_uuid,
                "diskname": disk.diskPath if disk.diskPath else 'N/A',
                "disksizegb": round(disk.capacity / 1024 / 1024 / 1024, 2) if disk.capacity else 0,
                "freediskgb": round(disk.freeSpace / 1024 / 1024 / 1024, 2) if disk.freeSpace else 0,
                "createdate": datetime.datetime.now(),
                "is_deleted": False,
                "hostname": vm_runtime_host.name if vm_runtime_host else 'N/A',
                "occupacyrate": round((disk.capacity - disk.freeSpace) / disk.capacity * 100, 2) if disk.capacity else 0,
                "resourcepoolname": vm_resource_pool,
                "vmname": vm_name,
                "version": "1",
                "virtualizationtechnology": "VMware",
            }
            vm_guest_disk_detail_list.append(disk_info)

    # Disk Info Section
    for device in vm_config.hardware.device:
        if isinstance(device, vim.vm.device.VirtualDisk):
            disk_spec = vim.vm.device.VirtualDeviceSpec()
            disk_spec.operation = vim.vm.device.VirtualDeviceSpec.Operation.edit
            disk_spec.device = device

            # Disk provisioning türünü belirlemek
            if hasattr(disk_spec.device.backing, 'thinProvisioned'):
                if disk_spec.device.backing.thinProvisioned:
                    disk_provisioning = DiskProvisioning.THIN.value
                else:
                    # Kalın provizyonlama durumu
                    if hasattr(disk_spec.device.backing, 'eagerlyScrub'):
                        if disk_spec.device.backing.eagerlyScrub:
                            disk_provisioning = DiskProvisioning.THICK_EAGER.value
                        else:
                            disk_provisioning = DiskProvisioning.THICK_LAZY.value
                    else:
                        disk_provisioning = DiskProvisioning.THICK_UNKNOWN.value
            else:
                disk_provisioning = DiskProvisioning.UNKNOWN.value

            # limitIOPS değerini kontrol etme
            if hasattr(disk_spec.device, 'storageIOAllocation') and hasattr(disk_spec.device.storageIOAllocation,
                                                                            'limit'):
                limit_iops = disk_spec.device.storageIOAllocation.limit
                if limit_iops == -1:
                    limit_iops_value = 'Unlimited'
                else:
                    limit_iops_value = limit_iops
            else:
                limit_iops_value = 'Unknown'


            if hasattr(disk_spec.device.backing, 'sharing'):
                sharing_mode = disk_spec.device.backing.sharing
                if sharing_mode == 'sharingMultiWriter':
                    shared_value = DiskSharing.SHARING_MULTI_WRITER.value
                elif sharing_mode == 'sharingHigh':
                    shared_value = DiskSharing.SHARING_HIGH.value
                elif sharing_mode == 'sharingNormal':
                    shared_value = DiskSharing.SHARING_NORMAL.value
                elif sharing_mode == 'sharingNone':
                    shared_value = DiskSharing.SHARING_NONE.value
                else:
                    shared_value = DiskSharing.UNKNOWN.value
            else:
                shared_value = DiskSharing.UNKNOWN.value


            # Controller location bilgisi
            controller_key = disk_spec.device.controllerKey
            #controller_location = get_controller_type(vm_config.hardware.device, controller_key)
            #controller_location_value = get_controller_location_value(vm_config.hardware.device, controller_key)


            sum_disk_size += float(f"{disk_spec.device.capacityInKB / 1024 / 1024:.2f}") if hasattr(disk_spec.device, 'capacityInKB') else 0.0

            disk_info = {
                "uuid": vm_uuid,
                "diskprovisioning": disk_provisioning,
                "disksize": float(f"{disk_spec.device.capacityInKB / 1024 / 1024:.2f}") if hasattr(disk_spec.device, 'capacityInKB') else 'N/A',
                "location": disk_spec.device.backing.datastore.name if hasattr(disk_spec.device.backing, 'datastore') else 'N/A',
                "sharedvalue" : shared_value,
                "version": "1",
                "limitiops": limit_iops_value,
                "createdate": datetime.datetime.now(),
                "controllerlocationvalue": disk_spec.device.controllerKey,
                "is_deleted": False,
                "diskobjectid": device.diskObjectId
            }
            disk_info_list.append(disk_info)

    # Product Usage Section
    vCPU, vramsizegb, vdisk, Draas , onlineofflinestatusReturn = product_usage_calculator_for_vmware(sum_disk_size, onlineofflinestatus, vm_name, vm_summary_config, vm_summary_guest)

    vm_info = {
        "vmname": vm_name,
        "uuid": vm_uuid,
        "onlineofflinestatus": onlineofflinestatusReturn,
        "ipaddress": vm_summary_guest.ipAddress if vm_summary_guest.ipAddress else 'N/A',
        "hostname": vm_runtime_host.name if vm_runtime_host else 'N/A',
        "ramsizegb": str(vramsizegb),
        "cpu": str(vCPU),
        "operatingsystemversion": vm_summary_config.guestFullName if vm_summary_config.guestFullName else 'N/A',
        "operatingsysteminformation": VMInfo.find_guest_family(vm_summary_config.guestFullName).value,
        "createdate": datetime.datetime.now(),
        "resource_pool": vm_resource_pool,
        "total_disk_number": vm_summary_config.numVirtualDisks if vm_summary_config.numVirtualDisks else '0',
        "virtualizationtechnology": "VMware",
        "environment": host_name,
        "ip": host_ip,
        "is_deleted": False,
        "disksize": float(vdisk),
        "draassize": float(Draas),
        "version": "1",
        "bandwidth": '0.0',
        "vlanid": str(vm_vlan_id),
        "vmidgh": vm_uuid,
        "vmcreatedate" :vm_create_date,
        "datacentertype" : datacenter,
        "producttype" : product_type,
        "usagetype" : usage_location
    }

    # Append directly to the global vm_info_list
    vm_info_list.append(vm_info)

def get_vm_info(content, host_name, host_ip, datacenter, usage_location, product_type):
    container = content.viewManager.CreateContainerView(content.rootFolder, [vim.VirtualMachine], True)
    event_manager = content.eventManager
    vms = container.view
    print("VM bilgileri alınıyor...")
    logging.info(f"{host_name} sunucusundaki VM bilgileri alınıyor...")
    print("Toplam VM sayısı: ", len(vms), "\n")
    logging.info(f"{host_name} sunucusundaki VM sayısı: {len(vms)}")

    # Use ThreadPoolExecutor to process VMs concurrently
    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = [executor.submit(process_vm, vm, host_name, host_ip, event_manager, datacenter, usage_location, product_type) for vm in vms]

        # Optionally, wait for all futures to complete (if needed)
        concurrent.futures.wait(futures)

def append_vm_info_history_for_vmware():
    TO_TABLE_NAME = "kr_vm_list_history"

    query_current_date = f"""SELECT CURRENT_DATE"""
    current_date = pd.read_sql(query_current_date, engineForPostgres)
    logging.info(f"DB CURRENT DATE: {current_date['current_date'][0]}")

    query_vm_list = """SELECT id, bandwidth, cpu, createdate, is_deleted, disksize, draassize, ramsizegb, resource_pool, version 
                FROM kr_vm_list 
                WHERE virtualizationtechnology = 'VMware'
                AND is_deleted = False"""
    readed_vm_list_df = pd.read_sql(query_vm_list, engineForPostgres)

    columns_to_convert = ['bandwidth', 'cpu', 'ramsizegb']
    readed_vm_list_df[columns_to_convert] = readed_vm_list_df[columns_to_convert].astype('float64')

    readed_vm_list_df = readed_vm_list_df.rename(columns={
        'id': 'vmlist_id',
        'bandwidth': 'bandwidthsize',
        'cpu': 'cpusize',
        'ramsizegb': 'ramsize',
        'disksize': 'disksize',
    })

    #updatedate, year, month, day
    current_datetime = pd.Timestamp.now().replace(hour=0, minute=0, second=0, microsecond=0)

    readed_vm_list_df['updatedate'] = current_datetime
    readed_vm_list_df['updateday'] = current_datetime.day
    readed_vm_list_df['updatemonth'] = current_datetime.month
    readed_vm_list_df['updateyear'] = current_datetime.year

    #check kr_vm_list_history existing day data
    query_history = f"""SELECT kvlh.vmlist_id, kvlh.updatedate , kvl.virtualizationtechnology
                FROM {TO_TABLE_NAME} kvlh  
                left join {TABLE_NAME} kvl on kvl.id = kvlh.vmlist_id 
                WHERE kvlh.updatedate::date = CURRENT_DATE
                and kvl.virtualizationtechnology = 'VMware'
                """

    vm_list_history_df = pd.read_sql(query_history, engineForPostgres)

    to_update = readed_vm_list_df[readed_vm_list_df['vmlist_id'].isin(vm_list_history_df['vmlist_id'])]
    to_insert = readed_vm_list_df[~readed_vm_list_df['vmlist_id'].isin(vm_list_history_df['vmlist_id'])]

    to_insert['createdate'] = pd.Timestamp.now()

    #soft delete
    to_soft_delete = set(vm_list_history_df['vmlist_id']) - set(readed_vm_list_df['vmlist_id'])

    if not to_insert.empty:
        logging.info(f"{TO_TABLE_NAME} tablosunda {to_insert.shape[0]} adet VM bilgisi ekleniyor...")
        to_insert.to_sql(TO_TABLE_NAME, engineForPostgres, chunksize=5000, index=False, if_exists='append')
        logging.info(f"{TO_TABLE_NAME} tablosuna {to_insert.shape[0]} adet VM bilgisi eklendi.")

    if not to_update.empty:
        logging.info(f"{TO_TABLE_NAME} tablosunda {to_update.shape[0]} adet VM bilgisi güncelleniyor...")
        with engineForPostgres.connect() as connection:
            for _, row in to_update.iterrows():
                sql = text(f"""
                        UPDATE {TO_TABLE_NAME}
                        SET bandwidthsize = :bandwidthsize,
                            cpusize = :cpusize,
                            is_deleted = :is_deleted,
                            disksize = :disksize,
                            draassize = :draassize,
                            ramsize = :ramsize,
                            resource_pool = :resource_pool
                        WHERE vmlist_id = :vmlist_id 
                        AND updatedate::date = CURRENT_DATE
                    """)
                connection.execute(sql, {
                    'bandwidthsize': row['bandwidthsize'],
                    'cpusize': row['cpusize'],
                    'is_deleted': row['is_deleted'],
                    'disksize': row['disksize'],
                    'draassize': row['draassize'],
                    'ramsize': row['ramsize'],
                    'resource_pool': row['resource_pool'],
                    'vmlist_id': row['vmlist_id']
                })
            connection.commit()
            connection.close()
            logging.info(f"{TO_TABLE_NAME} tablosunda {to_update.shape[0]} adet VM bilgisi güncellendi.")

    if to_soft_delete:
        with engineForPostgres.connect() as connection:
            logging.info(f"{TO_TABLE_NAME} tablosunda {len(to_soft_delete)} adet VM bilgisi siliniyor...")
            update_sql = text(f"""
                UPDATE {TO_TABLE_NAME}
                SET is_deleted = True
                WHERE vmlist_id = :vmlist_id
                AND updatedate::date = CURRENT_DATE
            """)
            for vmlist_id in to_soft_delete:
                connection.execute(update_sql, {'vmlist_id': vmlist_id})
            connection.commit()
            connection.close()
            logging.info(f"{TO_TABLE_NAME} tablosunda {len(to_soft_delete)} adet VM bilgisi silindi.")

    print("VM bilgileri history tablosuna ekleniyor...")

if __name__ == "__main__":
    LogProcess.create_logger_settings(log_prefix=os.path.basename(__file__).split(".")[0], script_dir=os.path.dirname(os.path.realpath(__file__)))
    engineForPostgres = PostgresConnection().get_db_instance()

    TABLE_NAME = "kr_vm_list"

    logging.info("VMware veri çekme işlemi başlatılıyor...")

    if sys.argv[1]:
        try:
            # Decode the Base64 argument
            decoded_arg = base64.b64decode(sys.argv[1]).decode('utf-8')
            if decoded_arg == "mode=addHistory":
                logging.info("mode=addHistory argümanı ile çalıştırılıyor.")
            else:
                logging.warning(f"Argüman: {decoded_arg} ile çalıştırılıyor.")
        except Exception as e:
            logging.error(f"Argüman alınırken hata oluştu: {e}")
    else:
        logging.warning("Argüman Gönderilmedi. VM bilgileri history tablosuna eklenmeyecek.")

    disk_info_list = []
    vm_info_list = []
    vm_guest_disk_detail_list = []
    event_dict_list = []

    test_vsphere_connections()

    logging.info("Vcenter bilgileri alındı. Veritabanına ekleniyor...")

    if vm_info_list:
        upsert_vm_info_to_dataframe(vm_info_list)
        logging.info(f"{TABLE_NAME} tablosuna veriler eklendi.")
        upsert_vm_events_for_transaction_vmware(event_dict_list)
        logging.info("VM olayları kr_transaction_history tablosuna eklendi.")

    if sys.argv[1]:
        try:
            # Decode the Base64 argument
            decoded_arg = base64.b64decode(sys.argv[1]).decode('utf-8')
            logging.info(f"Decoded Arg: {decoded_arg}")
            if decoded_arg == "mode=addHistory":
                append_vm_info_history_for_vmware()
                logging.info("VM bilgileri history tablosuna eklendi")
            else:
                logging.error("Geçersiz argüman")
        except Exception as e:
            logging.error(f"VM bilgileri history tablosuna eklenirken hata oluştu: {e}")
    else:
        logging.error("Argüman alınamadı. VM bilgileri history tablosuna eklenmeden devam edecek.")

    if disk_info_list:
        upsert_disk_info_to_dataframe(disk_info_list)
        logging.info(f"Diskler kr_vm_first_disk'e eklendi")

    if vm_guest_disk_detail_list:
        upsert_guest_disk_info_to_dataframe(vm_guest_disk_detail_list)
        logging.info(f"Guest disk bilgileri kr_vm_warnings'e eklendi")

    PostgresConnection().close_db_instance()
    logging.info("İşlem tamamlandı.")
