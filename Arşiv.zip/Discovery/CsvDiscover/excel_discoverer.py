""" Daily Backup Reports and Replication Reports getter Script """
from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[2]))
import logging
import io
import pandas as pd
import paramiko
from scp import SCPClient
import os
import datetime
from sqlalchemy import text
from sqlalchemy.orm import sessionmaker
import re
from Discovery.utils.PostgresConnection import PostgresConnection
from Discovery.utils.LogProcess import LogProcess

class SSHConnection:
    HOSTNAME = "10.197.226.11"
    PORT = 22
    USERNAME = "cekino"
    PASSWORD = "123456!!"

    @classmethod
    def create_ssh_client(cls):
        """SSH bağlantısı oluşturur"""
        client = paramiko.SSHClient()
        client.load_system_host_keys()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        client.connect(cls.HOSTNAME, port=cls.PORT, username=cls.USERNAME, password=cls.PASSWORD)

        logging.info(f"SSH bağlantısı oluşturuldu: {cls.HOSTNAME}")
        logging.info(f"\n -------------------------------")
        return client


class CommandProcess:
    @staticmethod
    def list_remote_files(ssh_client, remote_path):
        """Uzak sunucudaki dosyaları listeler"""
        stdin, stdout, stderr = ssh_client.exec_command(f'ls {remote_path}')
        files = stdout.read().decode().splitlines()
        return files

    @staticmethod
    def cat_remote_file(ssh_client, remote_path, file):
        """Uzak sunucudaki dosyayı okur"""
        stdin, stdout, stderr = ssh_client.exec_command(f"cat {remote_path}/{file}")
        file_data = stdout.read()
        error_output = stderr.read().decode('utf-8')
        return file_data, error_output


def get_daily_backup_csv_files_from_remote(ssh_client, remote_path, proxmox_report_folder, vcenter_report_folder):
    """Uzak sunucudaki .csv dosyalarını doğru klasöre indirir"""
    logging.info(f"Uzak sunucudaki dosyaları kontrol ediliyor: {remote_path}")
    files = CommandProcess.list_remote_files(ssh_client, remote_path)

    # sonu .csv ile biten dosyaları al
    csv_files = [file for file in files if file.endswith('.csv')]

    if not csv_files:
        logging.info(".csv dosyası bulunamadı.")
        return

    report_description = "Daily Backup Report"
    report_table_name = "kr_report"

    with SCPClient(ssh_client.get_transport()) as scp:
        for file in csv_files:
            #Dosya isim kontrolü
            if file.startswith('proxmox'):
                local_path = os.path.join(proxmox_report_folder, file)
                report_type = 'Proxmox'
            elif file.startswith('vmware'):
                local_path = os.path.join(vcenter_report_folder, file)
                report_type = 'VMware'
            else:
                continue

            # Dosya varlığı kontrolü
            if os.path.exists(local_path):
                continue

            logging.info(f"{file} için işlemler yapılıyor.")

            # Dosya tarihi alma
            file_date = re.search(r'_(\d{2}-\d{2}-\d{4})\.csv', file)

            if file_date:
                file_date = file_date.group(1)
                file_date = datetime.datetime.strptime(file_date, "%d-%m-%Y").strftime("%Y-%m-%d")
                logging.info(f"{file} için tarih: {file_date}")
            else:
                logging.info(f"{file} için tarih çıkarılamadı.")
                continue


            kr_reports_check = pd.read_sql(f"SELECT * FROM {report_table_name} "
                                           f"WHERE logdate = '{file_date}' "
                                           f"AND reporttype = '{report_type}' "
                                           f"AND description = '{report_description}'", engineForPostgres)

            if not kr_reports_check.empty:
                logging.info(f"{file} zaten veritabanında var, atlanıyor.")
                continue

            try:
                file_data, error_output = CommandProcess.cat_remote_file(ssh_client, remote_path, file)

                if error_output:
                    logging.error(f"Uzaktan {file} okunurken hata oluştu: {error_output}")
                    continue

                csv_data = pd.read_csv(io.StringIO(file_data.decode('utf-8')))

                csv_data.rename(columns={
                    'VM Name': 'vmname',
                    'VM ID': 'vmidgh',
                    'Volume': 'volume',
                    'DataStore Name': 'datastorename',
                    'FE Disk Size (Byte)': 'disksize',
                    'Retention Time': 'retentiontime',
                    'Start Time': 'starttime',
                    'End Time': 'endtime',
                    'Current State': 'currentstate',
                    'Status': 'status',
                    'Backup Level': 'backuplevel'
                }, inplace=True)

                now_time = datetime.datetime.now()
                csv_data['createdate'] = now_time
                csv_data['createatdate'] = now_time
                csv_data['is_deleted'] = False
                csv_data['description'] = report_description
                csv_data['logdate'] = file_date
                csv_data['version'] = 1
                csv_data['reporttype'] = report_type

                table_name_vm_list = "kr_vm_list"
                kr_vm_list_df = pd.read_sql(f"SELECT id, vmname FROM {table_name_vm_list}", engineForPostgres)
                csv_data = csv_data.merge(kr_vm_list_df, on='vmname', how='left', suffixes=('', '_kr_vm'))
                csv_data.rename(columns={'id': 'vmlist_id'}, inplace=True)

                try:
                    csv_data.to_sql(report_table_name, engineForPostgres, chunksize=5000, index=False, if_exists='append')
                    logging.info(f"{file} başarıyla veritabanına yazıldı.")
                    try:
                        scp.get(f"{remote_path}/{file}", local_path)
                        logging.info(f'{file} indirildi.')
                    except Exception as e:
                        logging.error(f"{file} indirilirken hata oluştu: {e}")

                except Exception as e:
                    logging.error(f"Veritabanına {file} yazılırken hata oluştu: {e}")

            except Exception as e:
                logging.error(f"{file} okunurken veya işlenirken hata oluştu: {e}")

def get_replication_files_from_remote(ssh_client, remote_path, replication_report_folder):
    """Retrieve replication .csv files from remote server and log separately"""
    files = CommandProcess.list_remote_files(ssh_client, remote_path)
    csv_files = [file for file in files if file.endswith('.csv')]

    report_description = "Hourly Disaster Recovery Report"
    report_table_name = "kr_report"

    with SCPClient(ssh_client.get_transport()) as scp:
        for file in csv_files:
            local_path = os.path.join(replication_report_folder, file)
            if os.path.exists(local_path):
                continue

            try:
                file_data, error_output = CommandProcess.cat_remote_file(ssh_client, remote_path, file)

                # Check if there was any error during file read
                if error_output:
                    logging.error(f"Error reading {file} from remote: {error_output}")
                    continue

                # Print the raw content of the file before converting to a DataFrame
                parsed_file_name_date = re.search(r'\d{4}-\d{2}-\d{2}-\d{2}:\d{2}:\d{2}', file)

                if parsed_file_name_date:
                    file_date_str = parsed_file_name_date.group(0)
                    file_date = datetime.datetime.strptime(file_date_str, "%Y-%m-%d-%H:%M:%S").strftime("%Y-%m-%d %H:%M:%S")
                else:
                    continue

                logging.info(f"{file} için işlemler yapılıyor.")

                kr_reports_check = pd.read_sql(f"SELECT * FROM {report_table_name} "
                                               f"WHERE logdate = '{file_date}' "
                                               f"AND description = '{report_description}'", engineForPostgres)

                if not kr_reports_check.empty:
                    logging.info(f"{file} zaten veritabanında var, atlanıyor.")
                    scp.get(f"{remote_path}/{file}", local_path)
                    logging.info(f'{file} indirildi.')
                    continue

                # Convert file data to a DataFrame
                csv_data = pd.read_csv(io.StringIO(file_data.decode('utf-8')))
                csv_data.rename(columns={
                    'LOCALRESNAME': 'localresname',
                    'STARTTIME': 'starttime',
                    'ENDTIME': 'endtime',
                    'SYNCLEFTTIME': 'synclefttime'
                }, inplace=True)
                csv_data.drop('REPLICATIONPROGRESS', axis=1, inplace=True)

                now_time = datetime.datetime.now()
                csv_data['createdate'] = now_time
                csv_data['createatdate'] = now_time
                csv_data['is_deleted'] = False
                csv_data['description'] = report_description
                csv_data['logdate'] = file_date
                csv_data['version'] = 1

                try:
                    csv_data.to_sql(report_table_name, engineForPostgres, chunksize=5000, index=False, if_exists='append')
                    logging.info(f"{file} başarıyla veritabanına yazıldı.")
                    scp.get(f"{remote_path}/{file}", local_path)
                    logging.info(f'{file} indirildi.')

                except Exception as e:
                    logging.error(f"Error writing {file} to the database: {e}")

            except Exception as e:
                logging.error(f"{file} okunurken veya işlenirken hata oluştu: {e}")

def get_baas_files_from_remote(ssh_client, remote_path, baas_report_folder):
    """Retrieve specific BaaS .csv file (EQX_Mtree.csv) from remote server and load it into a DataFrame."""
    files = CommandProcess.list_remote_files(ssh_client, remote_path)
    csv_files = [file for file in files if file == 'EQX_Mtree.csv']

    if not csv_files:
        logging.info("No EQX_Mtree.csv file found in the remote path.")
        return

    backup_customer_mapping_table = "kr_backup_customer_mapping"

    with SCPClient(ssh_client.get_transport()) as scp:
        for file in csv_files:
            local_path = os.path.join(baas_report_folder, file)
            try:
                scp.get(os.path.join(remote_path, file), local_path)
                logging.info(f"File {file} successfully retrieved to {local_path}")

                csv_data = pd.read_csv(local_path)
                logging.info(f"{file} loaded into DataFrame successfully.")

                #rename csv_data columns Hostname to hostname, Name to name, Pre Compression Size (PB) to precompressionsizepb, Post Global Compression Size (TB) to postglobalcompressionsizetb, Post Local Compression Size (TB) to postlocalcompressionsizetb, Measurement Time to measurementtime
                csv_data.rename(columns={'Hostname': 'hostname',
                                         'Name': 'name',
                                         'Pre Compression Size (PB)': 'precompressionsizepb',
                                         'Post Global Compression Size (TB)': 'postglobalcompressionsizetb',
                                         'Post Local Compression Size (TB)': 'postlocalcompressionsizetb',
                                         'Measurement Time': 'measurementtime'}, inplace=True)

                #backup_mapping tablosundan backupname ve customer_id alanlarını çek
                kr_backup_customer_mapping = pd.read_sql(f"SELECT backupname, customer_id "
                                                         f"FROM {backup_customer_mapping_table} "
                                                         f"WHERE is_deleted = False", engineForPostgres)

                csv_data = csv_data.merge(kr_backup_customer_mapping, left_on='name', right_on='backupname', how='left', suffixes=('', '_kr_backup_customer_mapping'))
                csv_data['customer_id'] = csv_data['customer_id'].apply(lambda x: None if pd.isnull(x) else x)

                now_time = datetime.datetime.now()
                csv_data['createdate'] = now_time
                csv_data['is_deleted'] = False
                csv_data['version'] = 1
                csv_data['updatedate'] = now_time
                csv_data.drop('backupname', axis=1, inplace=True)

                #check if the baas data is already in the database
                baas_table_name = "kr_mtree_backup"
                baas_check = pd.read_sql(f"SELECT * FROM {baas_table_name}", engineForPostgres)

                # baas_check tablosunda olmayan verileri ekle
                to_update = csv_data[csv_data['name'].isin(baas_check['name'])]
                to_insert = csv_data[~csv_data['name'].isin(to_update['name'])]
                to_soft_delete = baas_check[~baas_check['name'].isin(csv_data['name'])]

                Session = sessionmaker(bind=engineForPostgres)
                session = Session()

                if not to_update.empty:
                    try:
                        for index, row in to_update.iterrows():
                            sql = text(f"UPDATE {baas_table_name} "
                                       f"SET hostname = :hostname, "
                                       f"precompressionsizepb = :precompressionsizepb, "
                                       f"postglobalcompressionsizetb = :postglobalcompressionsizetb, "
                                       f"postlocalcompressionsizetb = :postlocalcompressionsizetb, "
                                       f"measurementtime = :measurementtime, "
                                       f"createdate = :createdate, "
                                       f"is_deleted = :is_deleted, "
                                       f"version = :version, "
                                       f"updatedate = :updatedate, "
                                       f"customer_id = :customer_id "
                                       f"WHERE name = :name")

                            session.execute(sql, {
                                'hostname': row['hostname'],
                                'precompressionsizepb': row['precompressionsizepb'],
                                'postglobalcompressionsizetb': row['postglobalcompressionsizetb'],
                                'postlocalcompressionsizetb': row['postlocalcompressionsizetb'],
                                'measurementtime': row['measurementtime'],
                                'createdate': row['createdate'],
                                'is_deleted': row['is_deleted'],
                                'version': row['version'],
                                'updatedate': row['updatedate'],
                                'name': row['name'],
                                'customer_id': row['customer_id']
                            })
                        session.commit()
                        logging.info("BaaS veritabanı güncellendi.")
                    except Exception as e:
                        logging.error(f"BaaS veritabanı güncellenirken hata oluştu: {e}")
                        session.rollback()

                if not to_insert.empty:
                    try:
                        to_insert.to_sql(baas_table_name, engineForPostgres, chunksize=5000, index=False, if_exists='append')
                        logging.info("BaaS veritabanına yazıldı.")
                    except Exception as e:
                        print(e)
                        logging.error(f"BaaS veritabanına yazılırken hata oluştu: {e}")

                if not to_soft_delete.empty:
                    try:
                        for index, row in to_soft_delete.iterrows():
                            session.execute(f"UPDATE {baas_table_name} "
                                            f"SET is_deleted = True "
                                            f"WHERE name = '{row['name']}'")
                        session.commit()
                        logging.info("BaaS veritabanı güncellendi.")
                    except Exception as e:
                        logging.error(f"BaaS veritabanı güncellenirken hata oluştu: {e}")
                        session.rollback()

                session.close()

            except Exception as e:
                logging.error(f"Failed to process {file}: {e}")

def daily_backup_report_requirement_loader():
    """ Günlük yedekleme raporları için gereksinimleri yükler """
    logging.info("------Daily Backup Report Dicovery işlemleri başlatılıyor.------")
    backup_report_remote_path = "/tmp/backup_reports"
    vcenter_report_folder = "/home/gardiyan/Gardiyan/Server/pfms/apache-karaf-5005/GH-Plugins/Discovery/CsvDiscover/Reports/AvailabilityReport/VCenter"
    proxmox_report_folder = "/home/gardiyan/Gardiyan/Server/pfms/apache-karaf-5005/GH-Plugins/Discovery/CsvDiscover/Reports/AvailabilityReport/Proxmox"
    os.makedirs(proxmox_report_folder, exist_ok=True)
    os.makedirs(vcenter_report_folder, exist_ok=True)
    get_daily_backup_csv_files_from_remote(ssh_client, backup_report_remote_path, proxmox_report_folder, vcenter_report_folder)
    logging.info("Daily Backup Report işlemi tamamlandı.")
    logging.info(f"\n -------------------------------")

def hourly_dr_report_requirement_loader():
    """ Saatlik felaket kurtarma raporları için gereksinimleri yükler """
    logging.info("------Hourly Disaster Recovery Report Dicovery işlemleri başlatılıyor.------")
    replication_report_remote_path = "/tmp/replication_reports"
    replication_report_folder = "/home/gardiyan/Gardiyan/Server/pfms/apache-karaf-5005/GH-Plugins/Discovery/CsvDiscover/Reports/Replication-Reports"
    os.makedirs(replication_report_folder, exist_ok=True)
    get_replication_files_from_remote(ssh_client, replication_report_remote_path, replication_report_folder)
    logging.info("Hourly Disaster Recovery Report işlemi tamamlandı.")
    logging.info(f"\n -------------------------------")


def baas_report_requirement_loader():
    """ BaaS raporları için gereksinimleri yükler """
    logging.info("------BaaS Report Dicovery işlemleri başlatılıyor.------")
    baas_report_remote_path = "/mnt/scheduled"
    baas_report_folder = "/home/gardiyan/Gardiyan/Server/pfms/apache-karaf-5005/GH-Plugins/Discovery/CsvDiscover/Reports/BaaS-Reports"
    os.makedirs(baas_report_folder, exist_ok=True)
    #read_backup_mapping_and_set_db()
    get_baas_files_from_remote(ssh_client, baas_report_remote_path, baas_report_folder)
    logging.info("BaaS Report işlemi tamamlandı.")
    logging.info(f"\n -------------------------------")


def read_backup_mapping_and_set_db():
    backup_mapping_file = "/home/gardiyan/Gardiyan/Server/pfms/apache-karaf-5005/GH-Plugins/Discovery/CsvDiscover/mapping_files/backup_mapping.xlsx"
    backup_mapping_df = pd.read_excel(backup_mapping_file)

    backup_mapping_df.rename(columns={'Name': 'backupname', 'Müşteri İsmi': 'customername'}, inplace=True)

    customers_table_name = "kr_customers"
    kr_customers_df = pd.read_sql(f"SELECT id, name FROM {customers_table_name}", engineForPostgres)

    #backup_mapiing_df deki customername ile kr_customers_df deki name alanlarını birleştir
    backup_mapping_df = backup_mapping_df.merge(kr_customers_df, left_on='customername', right_on='name', how='left', suffixes=('', '_kr_customers'))
    backup_mapping_df.rename(columns={'id': 'customer_id'}, inplace=True)
    backup_mapping_df.drop('name', axis=1, inplace=True)

    now_time = datetime.datetime.now()
    backup_mapping_df['createdate'] = now_time
    backup_mapping_df['is_deleted'] = False
    backup_mapping_df['version'] = 1

    #check if the backup mapping data is already in the database
    backup_mapping_table_name = "kr_backup_customer_mapping"
    backup_mapping_check = pd.read_sql(f"SELECT * FROM {backup_mapping_table_name}", engineForPostgres)
    # backup_mapping_check tablosunda olmayan verileri ekle
    to_update = backup_mapping_df[backup_mapping_df['backupname'].isin(backup_mapping_check['backupname'])]
    to_insert = backup_mapping_df[~backup_mapping_df['backupname'].isin(to_update['backupname'])]
    to_soft_delete = backup_mapping_check[~backup_mapping_check['backupname'].isin(backup_mapping_df['backupname'])]

    Session = sessionmaker(bind=engineForPostgres)
    session = Session()

    if not to_update.empty:
        try:
            for index, row in to_update.iterrows():
                sql = text(f"UPDATE {backup_mapping_table_name} "
                           f"SET customer_id = :customer_id, "
                           f"customername = :customername, "
                           f"createdate = :createdate, "
                           f"is_deleted = :is_deleted, "
                           f"version = :version "
                           f"WHERE backupname = :backupname")
                session.execute(sql, {
                    'customer_id': row['customer_id'] if not pd.isnull(row['customer_id']) else None,
                    'customername': row['customername'],
                    'createdate': row['createdate'],
                    'is_deleted': row['is_deleted'],
                    'version': row['version'],
                    'backupname': row['backupname']
                })
            session.commit()
            logging.info("Backup Mapping veritabanı güncellendi.")
        except Exception as e:
            logging.error(f"Backup Mapping veritabanı güncellenirken hata oluştu: {e}")
            session.rollback()

    if not to_insert.empty:
        try:
            to_insert.to_sql(backup_mapping_table_name, engineForPostgres, chunksize=5000, index=False, if_exists='append')
            logging.info("Backup Mapping veritabanına yazıldı.")
        except Exception as e:
            logging.error(f"Backup Mapping veritabanına yazılırken hata oluştu: {e}")

    if not to_soft_delete.empty:
        try:
            for index, row in to_soft_delete.iterrows():
                sql = text(f"UPDATE {backup_mapping_table_name} "
                           f"SET is_deleted = True "
                           f"WHERE backupname = :backupname")
                session.execute(sql, {'backupname': row['backupname']})
            session.commit()
            logging.info("Backup Mapping veritabanı güncellendi.")
        except Exception as e:
            logging.error(f"Backup Mapping veritabanı güncellenirken hata oluştu: {e}")
            session.rollback()

    session.close()


if __name__ == "__main__":
    LogProcess.create_logger_settings(log_prefix=os.path.basename(__file__).split(".")[0], script_dir=os.path.dirname(os.path.realpath(__file__)))
    engineForPostgres = PostgresConnection().get_db_instance()

    ssh_client = SSHConnection.create_ssh_client()
    daily_backup_report_requirement_loader()
    hourly_dr_report_requirement_loader()
    baas_report_requirement_loader()

    ssh_client.close()
    logging.info("SSH bağlantısı kapatıldı.")
    PostgresConnection().close_db_instance()
    logging.info("Excel discover işlemi tamamlandı.")