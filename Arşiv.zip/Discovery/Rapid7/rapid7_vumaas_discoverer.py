from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[2]))
import requests
from requests.auth import HTTPBasicAuth
import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
import os
import logging
from Discovery.utils.LogProcess import LogProcess
from Discovery.utils.PostgresConnection import PostgresConnection

base_url = "https://172.28.32.18:3780/api/3"
username = "savasyildirim"
password = "5PgNTBMccyt99nW!"

def get_sites():
    url = f"{base_url}/sites?size=200"
    print(f"Site listesini almak için istek yapılıyor: {url}")
    try:
        response = requests.get(
            url,
            auth=HTTPBasicAuth(username, password),
            verify=False,  # SSL doğrulama kapalı
            timeout=10     # 10 saniyelik zaman aşımı
        )
        print(f"HTTP Status Code: {response.status_code}")
        if response.status_code == 200:
            print("Site listesi başarıyla alındı.")
            return response.json().get("resources", [])
        else:
            print(f"Site listesini alırken hata oluştu: {response.status_code} - {response.text}")
    except requests.exceptions.Timeout:
        print("Site listesini alırken zaman aşımı oldu. Sunucu yanıt vermedi.")
    except Exception as e:
        print(f"Site listesi alınırken bir hata oluştu: {e}")
    return []

def get_assets_by_site(site_id):
    url = f"{base_url}/sites/{site_id}/assets"
    print(f"Asset listesini almak için istek yapılıyor (Site ID: {site_id}): {url}")
    try:
        response = requests.get(
            url,
            auth=HTTPBasicAuth(username, password),
            verify=False,
            timeout=10
        )
        print(f"HTTP Status Code: {response.status_code}")
        if response.status_code == 200:
            print(f"Asset listesi başarıyla alındı (Site ID: {site_id}).")
            return response.json().get("resources", [])
        else:
            print(f"Asset listesi alınırken hata oluştu (Site ID: {site_id}): {response.status_code} - {response.text}")
    except requests.exceptions.Timeout:
        print(f"Asset listesi alırken zaman aşımı oldu (Site ID: {site_id}).")
    except Exception as e:
        print(f"Asset listesi alınırken bir hata oluştu (Site ID: {site_id}): {e}")
    return []

def fetch_data():
    print("Veri çekme işlemi başlatılıyor...")
    sites = get_sites()
    if not sites:
        print("Hiç site bilgisi alınamadı, işlemi sonlandırıyorum.")
        return

    print(f"Toplam {len(sites)} site bulundu.")

    data = []

    for site in sites:
        site_id = site.get("id")
        site_name = site.get("name", "Bilinmiyor")
        print(f"\n=== Site: {site_name} (ID: {site_id}) ===")

        assets = get_assets_by_site(site_id)
        if not assets:
            print(f"Site altında hiç asset bulunamadı (Site ID: {site_id}).")
            continue

        print(f"{len(assets)} asset bulundu.")
        for asset in assets:
            hostname = asset.get("hostName", "Bilinmiyor")
            ip_addresses = [addr["ip"] for addr in asset.get("addresses", []) if "ip" in addr]
            last_scan_time = asset.get("lastScanDate", "Bilinmiyor")

            for ip in ip_addresses:
                data.append({
                    "Site Name": site_name,
                    "Site ID": site_id,
                    "Hostname": hostname,
                    "IP Address": ip,
                    "Last Scan Date": last_scan_time
                })

    df = pd.DataFrame(data)
    print("\n=== IP Adresleri DataFrame ===")
    print(df)

    return df

def get_vm_ipaddresses_in_vmlist_for_customer():
    kr_customer = "kr_customers"
    kr_resource_account_mapping = "kr_resource_account_mapping"
    kr_vm_list = "kr_vm_list"
    query_vm_ip_for_customer =f"""
            SELECT kc.id, kvl.ipaddress
            FROM {kr_customer} kc 
            JOIN {kr_resource_account_mapping} kram 
            ON kc.accountid = kram.accountid 
            JOIN {kr_vm_list} kvl 
            ON kram.resourcepoolname = kvl.resource_pool 
            """

    try:
        pd_vm_ip_for_customer = pd.read_sql_query(query_vm_ip_for_customer, db_instance)
        return pd_vm_ip_for_customer
    except Exception as e:
        print("Veritabanından IP Adresleri Çekilirken Hata Oluştu:", e)
        exit(1)

def create_connection_database():
    try:
        engineForPostgres = create_engine('postgresql+psycopg2://postgres:Cekino.123!@10.14.45.69:7100/karcin_pfms')
        return engineForPostgres
    except Exception as e:
        print("Postgres Bağlantı Hatası:", e)
        exit(1)

def compare_and_recognize_vumaas():
    """ Rapid7'den çekilen veriler ile veritabanındaki verileri karşılaştırır ve sonucu ekrana yazdırır. """
    rapid_df = fetch_data()
    customer_vm_df = get_vm_ipaddresses_in_vmlist_for_customer()

    print("=== Rapid7 Verileri ===")
    print(rapid_df)

    print("=== Veritabanı Verileri ===")
    print(customer_vm_df)

    print("=== Rapid7 Verileri ile Veritabanı Verileri Karşılaştırılıyor ===")
    customer_vm_df["vumaas"] = customer_vm_df["ipaddress"].isin(rapid_df["IP Address"]).astype(int)
    print(customer_vm_df)

    #id ye göre gruplayıp vumaas değerlerini topluyoruz agg kulan
    calculated_vumaas_for_customer = customer_vm_df.groupby("id").agg({"vumaas": "sum"})
    calculated_vumaas_for_customer = calculated_vumaas_for_customer.rename_axis("customer_id").reset_index()
    calculated_vumaas_for_customer.rename(columns={"vumaas": "vumaas_count"}, inplace=True)

    print("=== Sonuç ===")
    print(calculated_vumaas_for_customer)

    return calculated_vumaas_for_customer

def insert_vumaas_to_database(vumaas_df):
    product_usage_table = "kr_product_usage"

    query_product_usage = f"""
    SELECT *
    FROM {product_usage_table}
    """
    kr_product_usage_df = pd.read_sql(query_product_usage, db_instance)

    Session = sessionmaker(bind=db_instance)
    session = Session()

    try:
        for index, row in vumaas_df.iterrows():
            customer_id = row["customer_id"]
            vumaas_count = row["vumaas_count"]

            session.execute(
                text(f"""
                UPDATE {product_usage_table}
                SET vumaassize = :vumaas_count
                WHERE customer_id = :customer_id
                """),
                {"vumaas_count": vumaas_count, "customer_id": customer_id}
            )

        rows_to_zero = kr_product_usage_df[~kr_product_usage_df["customer_id"].isin(vumaas_df["customer_id"])]

        for index, row in rows_to_zero.iterrows():
            customer_id = row["customer_id"]
            session.execute(
                text(f"""
                UPDATE {product_usage_table}
                SET vumaassize = 0
                WHERE customer_id = :customer_id
                """),
                {"customer_id": customer_id}
            )
        session.commit()
        print("İşlem başarıyla tamamlandı.")

    except Exception as e:
        session.rollback()
        print("İşlem sırasında hata oluştu:", e)

    finally:
        session.close()


if __name__ == "__main__":
    LogProcess.create_logger_settings(log_prefix=os.path.basename(__file__).split(".")[0], script_dir=os.path.dirname(os.path.realpath(__file__)))
    db_instance = PostgresConnection().get_db_instance()
    logging.info("------ Rapid7 Discovery işlemleri Başlatılıyor ------")
    vumaas_df = compare_and_recognize_vumaas()
    insert_vumaas_to_database(vumaas_df)

    PostgresConnection().close_db_instance()