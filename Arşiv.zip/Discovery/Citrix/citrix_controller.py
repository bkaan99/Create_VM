from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[2]))
from Discovery.utils.PostgresConnection import PostgresConnection
from Discovery.utils.LogProcess import LogProcess
import requests
import pandas as pd
import urllib3
import logging
import os
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

VERIFY_SSL = False

HEADERS = {
    "Content-Type": "application/json"
}

# Citrix ADC bağlantı bilgileri
CREDENTIALS = [
    {
        "url": "https://10.198.221.90/nitro/v1/config",
        "username": "P02025.otomasyon",
        "password": "ykcxrn3pyzKewfbyt"
    },
    {
        "url": "https://10.198.221.91/nitro/v1/config",
        "username": "P02025.otomasyon",
        "password": "ykcxrn3pyzKewfbyt"
    },
    {
        "url": "https://172.28.32.57/nitro/v1/config",
        "username": "P02025.otomasyon",
        "password": "GAJoUwKmEQ62tFUMi"
    },
    {
        "url": "https://172.28.32.56/nitro/v1/config",
        "username": "P02025.otomasyon",
        "password": "GAJoUwKmEQ62tFUMi"
    },
    {
        "url": "https://10.100.12.121/nitro/v1/config",
        "username": "P02025.otomasyon",
        "password": "2P3fhDuk95JGVAPsw"
    },
    {
        "url": "https://10.100.12.120/nitro/v1/config",
        "username": "P02025.otomasyon",
        "password": "2P3fhDuk95JGVAPsw"
    }
]

def fetch_vlans(base_url, username, password):
    """VLAN bilgilerini çeker."""
    url = f"{base_url}/vlan"
    try:
        response = requests.get(url, headers=HEADERS, auth=(username, password), verify=VERIFY_SSL)
        if response.status_code == 200:
            return response.json().get("vlan", [])
        else:
            print(f"VLAN bilgisi alınamadı: {response.status_code}, {response.text}")
            return []
    except Exception as e:
        print(f"VLAN bilgisi alınırken hata oluştu: {e}")
        return []

def extract_vlan_data(vlan_data):
    """VLAN verisinden sadece id ve alias alanlarını çıkarır."""
    extracted_data = []
    for vlan in vlan_data:
        vlan_id = vlan.get("id")
        #alias = vlan.get("alias", "N/A")
        extracted_data.append({"citrix_vlan_id": vlan_id})
    return extracted_data

def gather_all_vlans(credentials):
    """Tüm cihazlardan VLAN verilerini toplar ve birleştirir."""
    all_vlans = []
    for credential in credentials:
        base_url = credential["url"]
        username = credential["username"]
        password = credential["password"]

        print(f"{base_url} için VLAN bilgisi alınıyor...")
        vlans = fetch_vlans(base_url, username, password)
        extracted = extract_vlan_data(vlans)
        all_vlans.extend(extracted)
    return all_vlans

def create_vlan_dataframe():
    """VLAN verilerini bir DataFrame'e dönüştürür ve benzersiz olanları döndürür."""
    all_vlans = gather_all_vlans(CREDENTIALS)
    vlan_df = pd.DataFrame(all_vlans)
    unique_vlan_df = vlan_df.drop_duplicates()
    print(unique_vlan_df)
    return unique_vlan_df

def compare_lbaas_data_two_dataframe():
    unique_vlan_df = create_vlan_dataframe()
    vm_vlan_id = get_vm_vlan_in_vmlist_for_customer()
    # vlanname_and_vlanid_df içreisindeki vlanid değerlerinden unique_vlan_df içerisinde olanları yeni bir kolon açıp lbaas adında bir kolon ile işaretle
    merged_df = pd.merge(unique_vlan_df, vm_vlan_id, left_on="citrix_vlan_id", right_on="vlanid", how="left")
    # var olan kolonları 1 ve 0 olarak işaretleyerek yeni bir kolon açıyoruz
    merged_df['lbaas'] = merged_df['vlanid'].apply(lambda x: 1 if pd.notna(x) else 0)
    merged_df.rename(columns={'id': 'customer_id'}, inplace=True)
    merged_df.drop(columns=['citrix_vlan_id'], inplace=True)
    merged_df.dropna(subset=['vlanid'], inplace=True)
    merged_df['customer_id'].unique()
    merged_df.drop(columns=['vlanid'], inplace=True)
    print(merged_df)

    return merged_df

def get_vm_vlan_in_vmlist_for_customer():
    kr_customer = "kr_customers"
    kr_resource_account_mapping = "kr_resource_account_mapping"
    kr_vm_list = "kr_vm_list"
    query_vm_ip_for_customer =f"""
            SELECT kc.id, kvl.vlanid
            FROM {kr_customer} kc 
            JOIN {kr_resource_account_mapping} kram 
            ON kc.accountid = kram.accountid 
            JOIN {kr_vm_list} kvl 
            ON kram.resourcepoolname = kvl.resource_pool 
            """

    try:
        pd_vm_ip_for_customer = pd.read_sql_query(query_vm_ip_for_customer, db_instance)
        return pd_vm_ip_for_customer
    except Exception as e:
        print("Veritabanından IP Adresleri Çekilirken Hata Oluştu:", e)
        exit(1)

def create_connection_database():
    try:
        engineForPostgres = create_engine('postgresql+psycopg2://postgres:Cekino.123!@10.14.45.69:7100/karcin_pfms')
        return engineForPostgres
    except Exception as e:
        print("Postgres Bağlantı Hatası:", e)
        exit(1)

def upsert_lbaas_product_usage():
    citrix_customer_df = compare_lbaas_data_two_dataframe()
    logging.info("Citrix Customer Dataframe Oluşturuldu.")
    product_usage_table = "kr_product_usage"

    query_product_usage = f"""
        SELECT customer_id FROM {product_usage_table}
        WHERE is_deleted = False
        """

    try:
        pd_product_usage = pd.read_sql_query(query_product_usage, db_instance)
        logging.info("Product Usage Tablosu okundu Dataframe olarak alındı.")
    except Exception as e:
        logging.error("Product Usage Tablosu Okunurken Hata Oluştu:", e)
        exit(1)


    last_df = pd.merge(pd_product_usage, citrix_customer_df, on="customer_id", how="left")
    last_df['lbaas'] = last_df['lbaas'].fillna(0)
    last_df.rename(columns={'lbaas': 'lbaassize'}, inplace=True)

    logging.info("Product Usage ve Citrix Customer Dataframe'leri birleştirildi.")

    Session = sessionmaker(bind=db_instance)
    session = Session()

    logging.info("Postgres session oluşturuldu.")

    try:
        for index, row in last_df.iterrows():
            customer_id = row["customer_id"]
            lbaassize = row["lbaassize"]

            session.execute(
                text(f"""
                UPDATE {product_usage_table}
                SET lbaassize = :lbaassize
                WHERE customer_id = :customer_id
                """),
                {"lbaassize": lbaassize, "customer_id": customer_id}
            )
        session.commit()
        logging.info(f"Product Usage Güncellendi.")
    except Exception as e:
        logging.error(f"Product Usage Güncellenirken Hata Oluştu: {e}")
        session.rollback()

    finally:
        session.close()
        logging.info("Postgres session kapatıldı.")

    logging.info("İşlem Tamamlandı.")

if __name__ == "__main__":
    LogProcess.create_logger_settings(log_prefix=os.path.basename(__file__).split(".")[0], script_dir=os.path.dirname(os.path.realpath(__file__)))
    db_instance = PostgresConnection().get_db_instance()
    upsert_lbaas_product_usage()
    PostgresConnection().close_db_instance()