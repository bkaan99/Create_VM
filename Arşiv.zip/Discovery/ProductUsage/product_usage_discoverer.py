from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[2]))
import datetime
import logging
import os
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
import pandas as pd
from Discovery.utils.PostgresConnection import PostgresConnection
from Discovery.utils.LogProcess import LogProcess

def customers_table_data_getter():
    customers_table_name = "kr_customers"
    logging.info(f"{customers_table_name} tablosundan veri çekiliyor.")
    query = f"""
    SELECT kc.id, kc.accountid 
    FROM {customers_table_name} kc
    WHERE kc.is_deleted = FALSE
    """
    kr_customer_table_df = pd.read_sql(query, engineForPostgres)
    kr_customer_table_df.rename(columns={'id': 'customer_id', 'accountid': 'account_id'}, inplace=True)
    logging.info(f"{customers_table_name} tablosundan veri çekme işlemi başarılı.")
    return kr_customer_table_df

def get_resourcepool_names_for_account_id():
    # İlk veriyi al
    kr_customer_table_df = customers_table_data_getter()
    account_ids = kr_customer_table_df['account_id'].tolist()

    resource_table_name = "kr_resource_account_mapping"
    account_ids_str = ','.join([f"'{account_id}'" for account_id in account_ids])
    logging.info(f"{resource_table_name} tablosundan veri çekiliyor.")
    query = f"""
    SELECT ram.accountid, ram.resourcepoolname 
    FROM {resource_table_name} ram
    WHERE ram.accountid IN ({account_ids_str})
    """
    resource_pool_df = pd.read_sql(query, engineForPostgres)
    # resource_pool_df içerisinde olmayan account_id'leri göster
    missing_account_ids = set(account_ids) - set(resource_pool_df['accountid'].tolist())
    logging.info(f"{resource_table_name} tablosundan veri çekme işlemi başarılı.")
    return resource_pool_df, account_ids, missing_account_ids

def get_vm_data_for_resourcepool():
    resource_pool_df, account_ids, missing_account_ids = get_resourcepool_names_for_account_id()
    resourcepoolnames = resource_pool_df['resourcepoolname'].tolist()

    vm_table_name = "kr_vm_list"
    resourcepoolnames_str = ','.join([f"'{name}'" for name in resourcepoolnames])
    query = f"""
    SELECT 
        vml.resource_pool, 
            SUM(CAST(vml.cpu AS NUMERIC)) AS total_cpu,
            SUM(CAST(vml.disksize AS NUMERIC)) AS total_disksize,
            SUM(CAST(vml.draassize AS NUMERIC)) AS total_draassize,
            SUM(CAST(vml.ramsizegb AS NUMERIC)) AS total_ramsizegb,
            SUM(CAST(vml.antivirus AS NUMERIC)) AS total_antivirus
    FROM {vm_table_name} vml
    WHERE vml.resource_pool IN ({resourcepoolnames_str})
    GROUP BY vml.resource_pool
    """
    logging.info(f"{vm_table_name} tablosundan veri çekiliyor.")
    vm_data_df = pd.read_sql(query, engineForPostgres)
    logging.info(f"{vm_table_name} tablosundan veri çekme işlemi başarılı.")
    return vm_data_df, resource_pool_df

def aggregate_vm_data_by_account():
    """Verileri hesapladık ve VM'lerin total verilerini elde ettik. Şimdi account_id başına bu verileri toplamamız gerekiyor."""
    kr_customer_table_df = customers_table_data_getter()
    vm_data_df, resource_pool_df = get_vm_data_for_resourcepool()
    merged_df = pd.merge(resource_pool_df, vm_data_df, left_on='resourcepoolname', right_on='resource_pool', how='left')

    aggregated_df = merged_df.groupby('accountid').agg({
        'total_cpu': 'sum',
        'total_disksize': 'sum',
        'total_draassize': 'sum',
        'total_ramsizegb': 'sum',
        'total_antivirus': 'sum'
    }).reset_index()

    aggregated_df.rename(columns={
        'total_cpu': 'cpusize',
        'total_disksize': 'disksize',
        'total_draassize': 'draassize',
        'total_ramsizegb': 'ramsize',
        'accountid': 'account_id',
        'total_antivirus': 'antivirus'
    }, inplace=True)
    logging.info("VM verileri hesaplandı ve account_id başına toplandı.")

    # Convert draassize from GB to TB
    aggregated_df['draassize'] = aggregated_df['draassize'] / 1024

    aggregated_df = pd.merge(kr_customer_table_df, aggregated_df, on='account_id', how='left')
    aggregated_df.fillna(0, inplace=True)
    aggregated_df['is_deleted'] = False
    aggregated_df['createdate'] = datetime.datetime.now()

    current_datetime = pd.Timestamp.now().replace(hour=0, minute=0, second=0, microsecond=0)
    aggregated_df['updatedate'] = current_datetime
    aggregated_df['updateday'] = current_datetime.day
    aggregated_df['updatemonth'] = current_datetime.month
    aggregated_df['updateyear'] = current_datetime.year
    aggregated_df['version'] = 1
    aggregated_df.drop(columns=['account_id'], inplace=True)

    return aggregated_df

def upsert_aggregated_vm_data():
    aggregated_vm_data_df = aggregate_vm_data_by_account()
    logging.info("-----------------Product Usage Tablosu İşlemleri-----------------")

    product_usage_table = "kr_product_usage"
    query = f"""
    SELECT * 
    FROM 
    {product_usage_table}
    """
    logging.info(f"{product_usage_table} tablosundan veri çekiliyor.")
    existing_kr_product_usage_df = pd.read_sql(query, engineForPostgres)
    logging.info(f"{product_usage_table} tablosundan veri çekme işlemi başarılı.")
    existing_customer_ids = set(existing_kr_product_usage_df['customer_id'].tolist())

    to_insert = aggregated_vm_data_df[~aggregated_vm_data_df['customer_id'].isin(existing_customer_ids)]
    to_update = aggregated_vm_data_df[aggregated_vm_data_df['customer_id'].isin(existing_customer_ids)]

    to_soft_delete = existing_customer_ids - set(to_update['customer_id'].tolist())
    logging.info("Verilerin güncellenmesi ve eklenmesi işlemi başlatılıyor.")

    if not to_insert.empty:
        to_insert.to_sql(product_usage_table, engineForPostgres, if_exists='append', index=False)
        # kaç tane veri eklendiğini logla
        logging.info(f"{len(to_insert)} adet veri eklendi.")
        logging.info(f"{product_usage_table} tablosuna veri ekleme işlemi başarılı.")

    if not to_update.empty:
        with engineForPostgres.connect() as connection:
            for _, row in to_update.iterrows():
                sql = text(f"""
                UPDATE {product_usage_table}
                SET 
                    cpusize = :cpusize,
                    disksize = :disksize,
                    draassize = :draassize,
                    ramsize = :ramsize,
                    is_deleted = :is_deleted,
                    updatedate = :updatedate,
                    updateday = :updateday,
                    updatemonth = :updatemonth,
                    updateyear = :updateyear,
                    version = :version,
                    antivirus = :antivirus
                WHERE customer_id = :customer_id
                """)
                connection.execute(sql, {
                    'cpusize': row['cpusize'],
                    'disksize': row['disksize'],
                    'draassize': row['draassize'],
                    'ramsize': row['ramsize'],
                    'is_deleted': row['is_deleted'],
                    'updatedate': row['updatedate'],
                    'updateday': row['updateday'],
                    'updatemonth': row['updatemonth'],
                    'updateyear': row['updateyear'],
                    'version': row['version'],
                    'customer_id': row['customer_id'],
                    'antivirus': row['antivirus']
                    })
            connection.commit()
            connection.close()
            logging.info(f"{len(to_update)} adet veri güncellendi.")
            logging.info(f"{product_usage_table} tablosunda veri güncelleme işlemi başarılı.")

    if to_soft_delete:
        with engineForPostgres.connect() as connection:
            for customer_id in to_soft_delete:
                sql = text(f"""
                UPDATE {product_usage_table}
                SET 
                    is_deleted = TRUE,
                    updatedate = :updatedate,
                    updateday = :updateday,
                    updatemonth = :updatemonth,
                    updateyear = :updateyear,
                    version = :version
                WHERE customer_id = :customer_id
                """)
                connection.execute(sql, {
                    'updatedate': datetime.datetime.now(),
                    'updateday': datetime.datetime.now().day,
                    'updatemonth': datetime.datetime.now().month,
                    'updateyear': datetime.datetime.now().year,
                    'version': 1,
                    'customer_id': customer_id
                })
            connection.commit()
            connection.close()
            logging.info(f"{len(to_soft_delete)} adet veri silindi.")
            logging.info(f"{product_usage_table} tablosunda veri silme işlemi başarılı.")

    logging.info("Product Usage tablosu işlemleri başarıyla tamamlandı.")

def upsert_product_usage_history():
    logging.info("-----------------Product Usage History Tablosu İşlemleri-----------------")
    TO_TABLE_NAME = "kr_product_usage_history"
    kr_product_usage_table = "kr_product_usage"

    query_current_date = f"""SELECT CURRENT_DATE"""
    current_date = pd.read_sql(query_current_date, engineForPostgres)
    current_date_day = current_date['current_date'][0].day
    current_date_month = current_date['current_date'][0].month
    current_date_year = current_date['current_date'][0].year

    query_product_usage = f"""
    SELECT *
    FROM {kr_product_usage_table}
    WHERE is_deleted = FALSE
    AND updateday = {current_date_day}
    AND updatemonth = {current_date_month}
    AND updateyear = {current_date_year}
    """
    kr_product_usage_df = pd.read_sql(query_product_usage, engineForPostgres)
    kr_product_usage_df.drop(columns=['id', 'createdate'], inplace=True)

    # kr_product_usage_history tablosundan veri çek

    query_product_usage_history = f"""
    SELECT *
    FROM {TO_TABLE_NAME}
    WHERE updateday = {current_date_day}
    AND updatemonth = {current_date_month}
    AND updateyear = {current_date_year}
    """
    kr_product_usage_history_df = pd.read_sql(query_product_usage_history, engineForPostgres)
    logging.info(f"{TO_TABLE_NAME} tablosundan veri çekme işlemi başarılı.")

    existing_customer_ids_history = set(kr_product_usage_history_df['customer_id'].tolist())
    to_insert = kr_product_usage_df[~kr_product_usage_df['customer_id'].isin(existing_customer_ids_history)]
    to_insert['createdate'] = datetime.datetime.now()
    to_update = kr_product_usage_df[kr_product_usage_df['customer_id'].isin(existing_customer_ids_history)]

    to_delete = existing_customer_ids_history - set(to_update['customer_id'].tolist())

    logging.info("Verilerin güncellenmesi ve eklenmesi işlemi başlatılıyor.")

    if not to_insert.empty:
        to_insert.to_sql(TO_TABLE_NAME, engineForPostgres, if_exists='append', index=False)
        logging.info(f"{len(to_insert)} adet veri eklendi.")
        logging.info(f"{TO_TABLE_NAME} tablosuna veri ekleme işlemi başarılı.")

    if not to_update.empty:
        with engineForPostgres.connect() as connection:
            for _, row in to_update.iterrows():
                sql = text(f"""
                UPDATE {TO_TABLE_NAME}
                SET 
                    bandwidthsize = :bandwidthsize,
                    cpusize = :cpusize,
                    disksize = :disksize,
                    draassize = :draassize,
                    ramsize = :ramsize,
                    is_deleted = :is_deleted,
                    updatedate = :updatedate,
                    updateday = :updateday,
                    updatemonth = :updatemonth,
                    updateyear = :updateyear,
                    version = :version,
                    sslvpnsize = :sslvpnsize,
                    s2svpnsize = :s2svpnsize,
                    fwaassize = :fwaassize,
                    fi_fwaassize = :fi_fwaassize,
                    bandwidthsize2 = :bandwidthsize2,
                    bandwidthsize3 = :bandwidthsize3,
                    antivirus = :antivirus,
                    baassize = :baassize,
                    vumaassize = :vumaassize,
                    lbaassize = :lbaassize
                WHERE customer_id = :customer_id
                AND updateday = {current_date_day}
                AND updatemonth = {current_date_month}
                AND updateyear = {current_date_year}
                """)
                connection.execute(sql, {
                    'bandwidthsize': row['bandwidthsize'],
                    'cpusize': row['cpusize'],
                    'disksize': row['disksize'],
                    'draassize': row['draassize'],
                    'ramsize': row['ramsize'],
                    'is_deleted': row['is_deleted'],
                    'updatedate': row['updatedate'],
                    'updateday': row['updateday'],
                    'updatemonth': row['updatemonth'],
                    'updateyear': row['updateyear'],
                    'version': row['version'],
                    'customer_id': row['customer_id'],
                    'sslvpnsize': row['sslvpnsize'],
                    's2svpnsize': row['s2svpnsize'],
                    'fwaassize': row['fwaassize'],
                    'fi_fwaassize': row['fi_fwaassize'],
                    'bandwidthsize2': row['bandwidthsize2'],
                    'bandwidthsize3': row['bandwidthsize3'],
                    'antivirus': row['antivirus'],
                    'baassize': row['baassize'],
                    'vumaassize': row['vumaassize'],
                    'lbaassize': row['lbaassize']
                })
            connection.commit()
            connection.close()
            logging.info(f"{len(to_update)} adet veri güncellendi.")
            logging.info(f"{TO_TABLE_NAME} tablosunda veri güncelleme işlemi başarılı.")

    if to_delete:
        with engineForPostgres.connect() as connection:
            for customer_id in to_delete:
                sql = text(f"""
                UPDATE {TO_TABLE_NAME}
                SET 
                    is_deleted = TRUE,
                    updatedate = :updatedate,
                    updateday = :updateday,
                    updatemonth = :updatemonth,
                    updateyear = :updateyear,
                    version = :version
                WHERE customer_id = :customer_id
                AND updateday = {current_date_day}
                AND updatemonth = {current_date_month}
                AND updateyear = {current_date_year}
                """)
                connection.execute(sql, {
                    'updatedate': datetime.datetime.now(),
                    'updateday': datetime.datetime.now().day,
                    'updatemonth': datetime.datetime.now().month,
                    'updateyear': datetime.datetime.now().year,
                    'version': 1,
                    'customer_id': customer_id
                })
            connection.commit()
            connection.close()
            logging.info(f"{len(to_delete)} adet veri silindi.")
            logging.info(f"{TO_TABLE_NAME} tablosunda veri silme işlemi başarılı.")

    logging.info("Product Usage History tablosu işlemleri başarıyla tamamlandı.")

def upsert_and_calculate_baas_size_product_usage():
    logging.info("-----------------Product Usage Baas Ekleme İşlemleri-----------------")

    mtree_table_name = "kr_mtree_backup"

    query_mtree = f"""
    SELECT customer_id, postlocalcompressionsizetb
    FROM {mtree_table_name}
    WHERE customer_id IS NOT NULL
    """
    mtree_df = pd.read_sql(query_mtree, engineForPostgres)
    mtree_df['postlocalcompressionsizetb'] = pd.to_numeric(mtree_df['postlocalcompressionsizetb'], errors='coerce')

    product_usage_baas_column_df = mtree_df.groupby('customer_id').agg({
        'postlocalcompressionsizetb': 'sum'
    }).reset_index()

    logging.info("Mtree Backup tablosundan veri çekme işlemi başarılı.")

    product_usage_table = "kr_product_usage"
    query_product_usage = f"""
    SELECT *
    FROM {product_usage_table}
    """
    kr_product_usage_df = pd.read_sql(query_product_usage, engineForPostgres)

    product_usage_baas_column_df = product_usage_baas_column_df.merge(
        kr_product_usage_df[['customer_id', 'disksize']],
        on='customer_id',
        how='left'
    )
    logging.info("Product Usage tablosundan veri çekme işlemi başarılı.")

    # Verilerin float olmasını sağla
    product_usage_baas_column_df['postlocalcompressionsizetb'] = product_usage_baas_column_df['postlocalcompressionsizetb'].astype(float)
    product_usage_baas_column_df['disksize'] = pd.to_numeric(product_usage_baas_column_df['disksize'], errors='coerce').astype(float)

    product_usage_baas_column_df['adjusted_baassize'] = (
            product_usage_baas_column_df['postlocalcompressionsizetb'] -
            (product_usage_baas_column_df['disksize'] * 0.01 * 7 / 1024)
    )

    logging.info("Baas size hesaplandı.")

    # adjusted_baassize negatif olanları 0 yap
    product_usage_baas_column_df.loc[product_usage_baas_column_df['adjusted_baassize'] < 0, 'adjusted_baassize'] = 0

    Session = sessionmaker(bind=engineForPostgres)
    session = Session()

    try:
        for _, row in product_usage_baas_column_df.iterrows():
            customer_id = row['customer_id']
            baassize = row['adjusted_baassize']

            session.execute(
                text(f"""
                UPDATE {product_usage_table}
                SET 
                    baassize = :baassize
                WHERE customer_id = :customer_id
                """), {
                    'baassize': float(baassize),  # Float olarak gönder
                    'customer_id': customer_id
                }
            )

        logging.info("Product Usage tablosunda baas olan customers baassize verileri güncellendi.")

        # Olmayan customer_id'leri sıfırla
        rows_to_zero = set(kr_product_usage_df['customer_id']) - set(product_usage_baas_column_df['customer_id'])

        for customer_id in rows_to_zero:
            session.execute(
                text(f"""
                UPDATE {product_usage_table}
                SET 
                    baassize = 0
                WHERE customer_id = :customer_id
                """), {
                    'customer_id': customer_id
                }
            )
        session.commit()
        logging.info("Product Usage tablosuna baassize olmayan customer baas verileri sıfırlandı.")

    except Exception as e:
        session.rollback()
        logging.error(f"Product Usage tablosuna baassize verileri eklenirken hata oluştu. Hata: {str(e)}")
    finally:
        session.close()
        logging.info("Product Usage tablosuna baassize için işlemler tamamlandı.")


if __name__ == '__main__':
    print("Product Usage Discover işlemi başlatılıyor.")
    LogProcess.create_logger_settings(log_prefix=os.path.basename(__file__).split(".")[0], script_dir=os.path.dirname(os.path.realpath(__file__)))
    print("Logger ayarları yapıldı.")
    engineForPostgres = PostgresConnection().get_db_instance()
    print("PostgreSQL veritabanına bağlantı sağlandı.")
    upsert_aggregated_vm_data()
    upsert_and_calculate_baas_size_product_usage()
    upsert_product_usage_history()

    PostgresConnection().close_db_instance()

    logging.info("Product Usage Discover işlemi başarıyla tamamlandı.")