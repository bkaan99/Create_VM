from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[2]))
import datetime
import requests
import pandas as pd
from sqlalchemy import text
from sqlalchemy.orm import sessionmaker
import logging
import os
from Discovery.utils.PostgresConnection import PostgresConnection
from Discovery.utils.LogProcess import LogProcess

class GetAllCustomerAPIClient:
    BASE_URL = "http://10.14.45.69/pfms/rest/karcin-pfms/rest-api/"
    BEARER_TOKEN = (
        "Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIiwiY2xpZW50SWQiOiIiLCJuYmYiO"
        "jE3MzMyOTkyNDEsImlzcyI6IjEiLCJleHAiOjE3MzMyOTk4NDEsImlhdCI6MTczMzI5OTI"
        "0MSwianRpIjoiZGFkNDVkZTEtYTAzOS00NGJiLWI1YjMtMzI4YzM3MzUyODUxIn0.HTl6vr"
        "6XnrPO6RgDsRBS7DOVBjzhhX-FWWVDt5GVgM4"
    )
    COOKIE = f"access_token={BEARER_TOKEN}"
    HEADERS = {"Cookie": COOKIE}

    @staticmethod
    def get_all_customers_credentials():
        """Prepare request body for fetching all customers."""
        body = {
            "method": "getAllCustomers",
            "processor": "accountManager",
            "data": [
                {
                    "azureUserId": "superuser",
                    "limit": 99999,
                    "offset": 0,
                    "search": "",
                    "key": "",
                    "value": "",
                    "table": "allCustomers",
                }
            ],
        }
        return GetAllCustomerAPIClient.BASE_URL, body, GetAllCustomerAPIClient.HEADERS

    @classmethod
    def get_all_customers(cls):
        """Tüm müşteri verilerini API'den çeker."""
        url, body, headers = cls.get_all_customers_credentials()
        try:
            logging.info("Tüm müşteriler çekiliyor...")
            response = requests.post(url, json=body, headers=headers)

            if response.status_code == 200:
                logging.info("Tüm müşteriler başarıyla çekildi.")
                return response.json()
            else:
                logging.error(f"Response status code: {response.status_code}")
                return None

        except Exception as e:
            logging.error(f"get_all_customers fonksiyonunda bir hata oluştu: {e}")
            return None

    @classmethod
    def convert_dataframe_response_customer(cls):
        """API'den gelen müşteri verilerini DataFrame'e dönüştürür."""
        response = cls.get_all_customers()
        if response:
            customers = response["resultMap"]["data"]["rows"]
            df = pd.DataFrame(customers)
            logging.info("Müşteri verileri başarıyla DataFrame'e dönüştürüldü.")
            return df
        else:
            logging.error("Müşteri verileri DataFrame'e dönüştürülemedi.")
            return None

    @classmethod
    def distinct_customers_single_row(cls):
        """Filterlenmiş müşteri verilerini distinct hale getirir ve tek bir satırda döner."""
        customers = cls.convert_dataframe_response_customer()
        if customers is not None:
            logging.info("Müşteri verileri distinct hale getiriliyor...")
            customers_data = customers.drop_duplicates(subset=["customerId"])
            logging.info("Müşteri verileri başarıyla distinct hale getirildi.")
            customers_data = customers_data[
                ["customerId", "ghTourNumber", "customerName"]
            ]
            return customers_data
        else:
            logging.error("Müşteri verileri distinct hale getirilemedi.")
            return None


def getGeneralInformationDashboardDetail_credentials(dynamic_ghtur):
    url = "http://10.14.45.69/pfms/rest/karcin-pfms/rest-api/"

    body = {
        "method": "getGeneralInformationDashboardDetail",
        "processor": "accountManager",
        "data": [
            {
                "azureUserId": "superuser",
                "ghTur": dynamic_ghtur,
            }
        ]
    }

    bearer_token=("Bearer eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIiwiY2xpZW50SWQiOiIiLC"
                  "JuYmYiOjE3MzMyOTkyNDEsImlzcyI6IjEiLCJleHAiOjE3MzMyOTk4NDEsImlhd"
                  "CI6MTczMzI5OTI0MSwianRpIjoiZGFkNDVkZTEtYTAzOS00NGJiLWI1YjMtMzI4Y"
                  "zM3MzUyODUxIn0.HTl6vr6XnrPO6RgDsRBS7DOVBjzhhX-FWWVDt5GVgM4")

    cookie = f"access_token={bearer_token}"

    headers = {
        "Cookie": cookie
    }

    return url, body, headers

def getGeneralInformationDashboardDetail(customers_data):
    logging.info("General Information Dashboard Detail bilgileri çekiliyor ve her müşteri tek bir dataframe'de birleştiriliyor...")
    all_data = []  # Tüm df'leri biriktirmek için bir liste oluşturuyoruz.

    if customers_data is not None:
        lenght_customer = len(customers_data)
        count = 0
        for index, row in customers_data.iterrows():
            dynamic_ghtur = row['ghTourNumber']
            customer_id = row['customerId']
            customer_name = row['customerName']
            url, body, headers = getGeneralInformationDashboardDetail_credentials(dynamic_ghtur)

            try:
                response = requests.post(url, json=body, headers=headers)

                if response.status_code == 200:
                    response_json = response.json()

                    response_products = response_json['resultMap']['data']['rows']
                    df = pd.DataFrame(response_products)
                    df['customerId'] = customer_id
                    df['customerName'] = customer_name
                    df['ghTourNumber'] = dynamic_ghtur
                    all_data.append(df)

                    count += 1
                    print(f"{count}/{lenght_customer} - {dynamic_ghtur} - {customer_name}")


            except Exception as e:
                logging.error(f"getGeneralInformationDashboardDetail fonksiyonunda bir hata oluştu: {e}")
                print(e)

    # Listeyi tek bir DataFrame olarak birleştiriyoruz.
    if all_data:
        combined_df = pd.concat(all_data, ignore_index=True)
        logging.info("General Information Dashboard Detail bilgileri başarıyla çekildi ve birleştirildi.")
        return combined_df
    else:
        return None

def upsert_customer_calculate_usage_history(customers_data):
    logging.info("Customer Calculate Usage History tablosuna Upsert İşlemleri Başlatılıyor...")
    now_time = datetime.datetime.now()
    now_time_day = now_time.day
    now_time_month = now_time.month
    now_time_year = now_time.year
    update_date = now_time.replace(hour=0, minute=0, second=0, microsecond=0)
    logging.info(f"Tarih ve saat bilgileri alındı, {now_time} tarihinde işlem yapılacak.")

    combined_df = getGeneralInformationDashboardDetail(customers_data)
    combined_df = combined_df.rename(columns={'availableCapacity': 'availablecapacity',
                                              'quantity': 'totalcapacity',
                                              'usage': 'usagecapacity',
                                              'capacityUsage': 'usageratiovalue',
                                              'productName': 'productname',
                                              'customerId': 'customer_id'})
    combined_df = combined_df.drop(columns=['id', 'customerName', 'ghTourNumber'])
    true_column_names = ['availablecapacity', 'totalcapacity', 'usagecapacity', 'usageratiovalue', 'threshold',
                    'productname', 'customer_id']
    combined_df = combined_df[true_column_names]
    combined_df['createdate'] = now_time
    combined_df['is_deleted'] = False
    combined_df['updatedate'] = update_date
    combined_df['updateday'] = now_time_day
    combined_df['updatemonth'] = now_time_month
    combined_df['updateyear'] = now_time_year
    combined_df['version'] = 1
    logging.info("General Information Dashboard Detail bilgileri başarılı şekilde tablo kolonlarına uygun dönüştürüldü.")

    kr_customer_calculate_usage_history_table = "kr_customer_calculate_usage_history"
    query_kr_customer_calculate_usage_history = f"""
    SELECT * FROM {kr_customer_calculate_usage_history_table}
    WHERE is_deleted = False
    AND updateday = {now_time_day}
    AND updatemonth = {now_time_month}
    AND updateyear = {now_time_year}
    """
    kr_customer_calculate_usage_history = pd.read_sql(query_kr_customer_calculate_usage_history,
                                                      db_instance)

    logging.info("Customer Calculate Usage History tablosundan veriler çekildi ve kıyaslanıyor.")
    to_insert = combined_df[
        ~combined_df.set_index(['customer_id', 'productname']).index.isin(
            kr_customer_calculate_usage_history.set_index(['customer_id', 'productname']).index
        )
    ]
    logging.info(f"Eklenecek veriler belirlendi - {len(to_insert)} adet veri eklenecek.")

    to_update = combined_df[
        combined_df.set_index(['customer_id', 'productname']).index.isin(
            kr_customer_calculate_usage_history.set_index(['customer_id', 'productname']).index
        )
    ]
    logging.info(f"Güncellenecek veriler belirlendi - {len(to_update)} adet veri güncellenecek.")

    to_delete = kr_customer_calculate_usage_history[
        ~kr_customer_calculate_usage_history.set_index(['customer_id', 'productname']).index.isin(
            combined_df.set_index(['customer_id', 'productname']).index
        )
    ]
    logging.info(f"Silinecek veriler belirlendi - {len(to_delete)} adet veri silinecek.")

    if not to_insert.empty:
        to_insert.to_sql(kr_customer_calculate_usage_history_table, db_instance, if_exists='append', index=False)
        logging.info(f"{len(to_insert)} adet veri başarıyla eklendi.")

    Session = sessionmaker(bind=db_instance)
    session = Session()

    if not to_update.empty:
        try:
            for index, row in to_update.iterrows():
                sql = text(
                    f"""
                    UPDATE {kr_customer_calculate_usage_history_table}
                    SET availablecapacity = :availablecapacity,
                        totalcapacity = :totalcapacity,
                        usagecapacity = :usagecapacity,
                        usageratiovalue = :usageratiovalue,
                        threshold = :threshold,
                        productname = :productname,
                        updatedate = :updatedate,
                        updateday = :updateday,
                        updatemonth = :updatemonth,
                        updateyear = :updateyear,
                        is_deleted = False
                    WHERE customer_id = :customer_id
                    AND is_deleted = False
                    AND productname = :productname
                    AND updateday = :updateday
                    AND updatemonth = :updatemonth
                    AND updateyear = :updateyear
                    """
                )
                session.execute(sql, {
                    'customer_id': row['customer_id'],
                    'availablecapacity': row['availablecapacity'],
                    'totalcapacity': row['totalcapacity'],
                    'usagecapacity': row['usagecapacity'],
                    'usageratiovalue': row['usageratiovalue'],
                    'threshold': row['threshold'],
                    'productname': row['productname'],
                    'updatedate': row['updatedate'],
                    'updateday': row['updateday'],
                    'updatemonth': row['updatemonth'],
                    'updateyear': row['updateyear'],
                    'is_deleted': False
                })
            session.commit()
            logging.info(f"{len(to_update)} adet veri başarıyla güncellendi.")
        except Exception as e:
            logging.error(f"Veri güncelleme işlemi sırasında bir hata oluştu: {e}")
            session.rollback()

    if not to_delete.empty:
        try:
            for index, row in to_delete.iterrows():
                sql = text(
                    f"""
                    UPDATE {kr_customer_calculate_usage_history_table}
                    SET is_deleted = True
                    WHERE customer_id = :customer_id
                    """
                )
                session.execute(sql, {'customer_id': row['customer_id']})
            session.commit()
            logging.info(f"{len(to_delete)} adet veri başarıyla silindi.")
        except Exception as e:
            logging.error(f"Veri silme işlemi sırasında bir hata oluştu: {e}")
            session.rollback()

    session.close()
    logging.info("Customer Calculate Usage History tablosuna Upsert İşlemleri Tamamlandı.")

def alerts_process():
    logging.info("Alertler için işlem başlatılıyor...")
    now_time = datetime.datetime.now()
    now_time_day = now_time.day
    now_time_month = now_time.month
    now_time_year = now_time.year

    kr_customer_calculate_usage_history_table = "kr_customer_calculate_usage_history"
    query_kr_customer_calculate_usage_history = f"""
    SELECT * FROM {kr_customer_calculate_usage_history_table}
    WHERE is_deleted = False
    AND updateday = {now_time_day}
    AND updatemonth = {now_time_month}
    AND updateyear = {now_time_year}
    """
    kr_customer_calculate_usage_history = pd.read_sql(query_kr_customer_calculate_usage_history, db_instance)

    kr_customer_table = "kr_customers"
    query_kr_customer = f"""
    SELECT id, accountid 
    FROM {kr_customer_table}
    """
    kr_customer_df = pd.read_sql(query_kr_customer, db_instance)
    kr_customer_df = kr_customer_df.rename(columns={'id': 'customer_id'})

    # kr_customer_calculate_usage_history ve kr_customer tablolarını birleştiriyoruz
    kr_customer_calculate_usage_history_account_id_merged = pd.merge(kr_customer_calculate_usage_history,
                                                                     kr_customer_df, on='customer_id',
                                                                     how='left')
    # usageratiovalue sütununu threshold sütünündan büyük eşit olanları seçiyoruz bunlar bizim alarmlarımız olmuş oluyor.
    filtered_df = kr_customer_calculate_usage_history_account_id_merged[
        (kr_customer_calculate_usage_history_account_id_merged['usageratiovalue'] >=
         kr_customer_calculate_usage_history_account_id_merged['threshold']) &
        (kr_customer_calculate_usage_history_account_id_merged['threshold'] > 0)
        ]

    filtered_df.drop(columns=['createdate','id','updatedate','updateday','updatemonth','updateyear'],inplace=True)

    # Filtrelenmiş veriler için alert tablosunda uygun hale getirilme case'leri
    alerts_df = filtered_df.copy()
    alerts_df['capacityusage'] = alerts_df['usageratiovalue']
    def determine_alarm_status(row):
        if row['availablecapacity'] > 0:
            if row['usageratiovalue'] > 100:
                return 'red'
            else:
                return 'yellow'
        else:  # availablecapacity <= 0
            return 'purple'

    alerts_df['alarmstatus'] = alerts_df.apply(determine_alarm_status, axis=1)
    alerts_df['averagecapacity'] = alerts_df['usageratiovalue']

    #unit value
    threshold_table = "kr_threshold"
    query_threshold = f"""select distinct kt.dashboardproductname, kt.unit from {threshold_table} kt"""
    threshold_df = pd.read_sql(query_threshold, db_instance)
    threshold_df.dropna(inplace=True)
    #merge
    alerts_df = pd.merge(alerts_df, threshold_df, how='left', left_on='productname', right_on='dashboardproductname')
    alerts_df['datetriggered'] = now_time
    alerts_df['createdate'] = now_time
    alerts_df.rename(columns={'unit':'unitname', 'customer_id':'customerid'}, inplace=True)
    alerts_df.drop(columns=['dashboardproductname','threshold', 'usageratiovalue'], inplace=True)


    #Upsert işlemi
    kr_alerts_table = "kr_alerts"
    query_kr_alerts = f"""
    SELECT * FROM {kr_alerts_table}
    WHERE is_deleted = False
    """

    kr_alerts = pd.read_sql(query_kr_alerts, db_instance)

    to_insert = alerts_df[
        ~alerts_df.set_index(['customerid', 'productname']).index.isin(
            kr_alerts.set_index(['customerid', 'productname']).index
        )
    ]

    to_update = alerts_df[
        alerts_df.set_index(['customerid', 'productname']).index.isin(
            kr_alerts.set_index(['customerid', 'productname']).index
        )
    ]

    to_delete = kr_alerts[
        ~kr_alerts.set_index(['customerid', 'productname']).index.isin(
            alerts_df.set_index(['customerid', 'productname']).index
        )
    ]

    if not to_insert.empty:
        to_insert.to_sql(kr_alerts_table, db_instance, if_exists='append', index=False)
        logging.info(f"{len(to_insert)} adet alert başarıyla eklendi.")

    Session = sessionmaker(bind=db_instance)
    session = Session()

    if not to_update.empty:
        try:
            for index, row in to_update.iterrows():
                sql = text(
                    f"""
                    UPDATE {kr_alerts_table}
                    SET availablecapacity = :availablecapacity,
                        totalcapacity = :totalcapacity,
                        usagecapacity = :usagecapacity,
                        capacityusage = :capacityusage,
                        alarmstatus = :alarmstatus,
                        averagecapacity = :averagecapacity,
                        unitname = :unitname,
                        createdate = :createdate
                    WHERE customerid = :customerid
                    AND is_deleted = False
                    AND productname = :productname"""
                )
                session.execute(sql, {
                    'customerid': row['customerid'],
                    'availablecapacity': row['availablecapacity'],
                    'totalcapacity': row['totalcapacity'],
                    'usagecapacity': row['usagecapacity'],
                    'capacityusage': row['capacityusage'],
                    'alarmstatus': row['alarmstatus'],
                    'averagecapacity': row['averagecapacity'],
                    'unitname': row['unitname'],
                    'createdate': row['createdate'],
                    'productname': row['productname'],
                })
            session.commit()
            logging.info(f"{len(to_update)} adet alert başarıyla güncellendi.")
        except Exception as e:
            logging.error(f"Alert güncelleme işlemi sırasında bir hata oluştu: {e}")
            session.rollback()

        finally:
            session.close()

    if not to_delete.empty:
        try:
            for index, row in to_delete.iterrows():
                sql = text(
                    f"""
                    UPDATE {kr_alerts_table}
                    SET is_deleted = True
                    WHERE customerid = :customerid
                    AND productname = :productname
                    """
                )
                session.execute(sql, {'customerid': row['customerid'], 'productname': row['productname']})
            session.commit()
            logging.info(f"{len(to_delete)} adet alert başarıyla silindi.")
        except Exception as e:
            logging.error(f"Alert silme işlemi sırasında bir hata oluştu: {e}")
            session.rollback()

        finally:
            session.close()

    logging.info("Alertler için işlemler tamamlandı.")


if __name__ == "__main__":
    LogProcess.create_logger_settings(log_prefix=os.path.basename(__file__).split(".")[0], script_dir=os.path.dirname(os.path.realpath(__file__)))
    db_instance = PostgresConnection().get_db_instance()
    customers_data = GetAllCustomerAPIClient.distinct_customers_single_row()
    upsert_customer_calculate_usage_history(customers_data)
    alerts_process()
    PostgresConnection().close_db_instance()
    logging.info("Tüm Customer History And Alert İşlemleri Bitirildi.")